BLIPSMITH text blip pack

WHAT'S IN HERE
  blip_01..06.wav  Six takes of the same voice. Play a random one per letter
                   so the dialogue doesn't sound like a machine gun.
  line_demo.wav    The whole sample line typed out, for reference.
  params.json      The exact settings, if you want to rebuild the voice.

FORMAT: 44.1 kHz, 16-bit, mono WAV. Works as-is in Godot, Unity, GameMaker,
LOVE2D, Unreal and every engine that loads WAV.

HOW GAMES USUALLY USE THESE
  1. Every time your text box reveals a character, play one blip.
  2. Skip spaces and punctuation, or it gets noisy.
  3. Playing one blip every 2nd or 3rd character sounds calmer and is what
     most commercial RPGs actually do.
  4. Randomise pitch slightly (+/- 5%) on playback for extra life.
  5. Cut off the previous blip when a new one starts, so they don't stack.

OUTPUT TERMS
Use, modify, share, or sell these generated sounds in personal or commercial
projects, including games and sound packs. No attribution or royalties are
required. Blipsmith's authors claim no rights in your generated audio.
The app's MIT license notice requirements do not apply to these sounds.

Made with Blipsmith.
