using System.Diagnostics;

namespace DualOntologyWorldEngine.Core;

/// <summary>Opt-in synchronous wall timings. Nested scopes overlap and are not additive CPU samples.</summary>
public static class CorePerformance
{
    [ThreadStatic] private static Action<string, double>? _listener;
    public static IDisposable Subscribe(Action<string, double> listener)
    {
        ArgumentNullException.ThrowIfNull(listener);
        var previous = _listener;
        _listener = listener;
        return new Subscription(previous, listener, Environment.CurrentManagedThreadId);
    }
    private sealed class Subscription(Action<string, double>? previous, Action<string, double> current, int thread) : IDisposable
    {
        private bool disposed;
        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            if (Environment.CurrentManagedThreadId == thread && ReferenceEquals(_listener, current)) _listener = previous;
        }
    }
    public static Scope Begin(string stage)
        => _listener is { } listener ? new(stage, listener, Stopwatch.GetTimestamp()) : default;
    public struct Scope : IDisposable
    {
        private Action<string, double>? _callback;
        private readonly string? _stage;
        private readonly long _started;
        internal Scope(string stage, Action<string, double> callback, long started)
            => (_stage, _callback, _started) = (stage, callback, started);
        public void Dispose()
        {
            var callback = _callback;
            _callback = null;
            if (callback is null) return;
            var elapsed = Stopwatch.GetElapsedTime(_started).TotalMilliseconds;
            try { callback(_stage!, elapsed); }
            catch { /* A diagnostic listener must never change execution or feedback. */ }
        }
    }
}
