using System.Collections.Immutable;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;

namespace DualOntologyWorldEngine.Core;

public enum SubjectiveActionKindV1 { Observe, Open, Travel, Assert, Present, Test, Commit, Withdraw, Wait, Acknowledge, Hide, Destroy, Edit }
public sealed record SubjectiveAgentMotivesV1(int Revisit = 1, int Information = 1, int Argument = 1);
public enum SubjectivePreferenceConditionV1 { Always, New, Untried }
public sealed record SubjectiveOfferPreferenceV1(SubjectivePreferenceConditionV1 Condition, RuleMode Mode, int Weight, string Basis);
/// <summary>Acquired affordance. IDs identify a method and source, never a display label or current input token.</summary>
public sealed record SubjectiveOfferV1(string Id, string MethodId, string SourceId, SubjectiveActionKindV1 Kind)
{
    public ImmutableArray<SubjectProjectionId> Materials { get; init; } = [];
    public ImmutableArray<FrozenConditionV1> Claims { get; init; } = [];
    public string GroupId { get; init; } = "";
    public string ScopeId { get; init; } = "";
    public string Context { get; init; } = "";
    /// <summary>Optional acquired-material context, separate from approach or execution failure context.</summary>
    public string InformationContext { get; init; } = "";
    public int RuleScore { get; init; }
    public bool Forbidden { get; init; }
    public bool Selected { get; init; }
    public bool Novel { get; init; }
    public ImmutableArray<SubjectiveOfferPreferenceV1> Preferences { get; init; } = [];
    public bool Presentable { get; init; }
    public bool AcquiresInformation { get; init; }
    public bool RequiresEvidence { get; init; }
    public bool Frontier { get; init; }
    public bool KnownGround { get; init; } = true;
    public int Cost { get; init; }
    public double? Distance { get; init; }
    public string DestinationSourceId { get; init; } = "";
    public ImmutableArray<string> RuleBasis { get; init; } = [];
}
public sealed record SubjectiveAgentRequestV1(CognitionSnapshotV1 Snapshot, SubjectProjectionId Actor,
    ReasoningBudgetV1 Budget, ImmutableArray<SubjectiveOfferV1> Offers, SubjectiveAgentMotivesV1 Motives)
{
    public FrozenConditionV1? Goal { get; init; }
    /// <summary>Only these observed source/scope method sets are complete and replace previous acquired offers.</summary>
    public ImmutableArray<SubjectiveMethodScopeV1> CompleteMethodScopes { get; init; } = [];
    public ImmutableArray<SubjectProjectionId> PresentableMaterials { get; init; } = [];
}
public sealed record SubjectiveMethodScopeV1(string SourceId, string ScopeId);
public sealed record SubjectiveOfferAssessmentV1(SubjectiveOfferV1 Offer, int Score, bool Forbidden,
    ImmutableArray<string> Basis, ImmutableArray<SubjectiveProofV1> Arguments);
public sealed record SubjectiveAgentAssessmentV1(KnowledgeRevision Revision,
    ImmutableArray<SubjectiveOfferAssessmentV1> Offers, SubjectiveReasoningResultV1 Reasoning)
{
    public SubjectiveProofV1? GoalProof { get; init; }
}
public sealed record SubjectiveAgentChoiceV1(string? OfferId, SubjectiveAgentAssessmentV1 Assessment);
public sealed record SubjectiveAgentFeedbackV1(string ReceiptId, string MethodId, string Context,
    DecisionOutcomeV1 Outcome, bool AcquiredInformation = false, string InformationIdentity = "");

public sealed class SubjectiveAgentState
{
    public const int CurrentVersion = 1;
    public int Version { get; set; } = CurrentVersion;
    public SubjectProjectionId Actor { get; set; }
    public uint TieState { get; set; } = 0x9E3779B9;
    public DecisionMemoryV1 Memory { get; set; } = new(1, []);
    public ImmutableArray<string> Receipts { get; set; } = [];
    public ImmutableArray<string> InformationReceipts { get; set; } = [];
    public ImmutableArray<SubjectiveOfferV1> KnownMethods { get; set; } = [];
    public ImmutableArray<SubjectiveInformationBaselineV1> Information { get; set; } = [];
    public ImmutableArray<SubjectiveDeferredMethodV1> Deferred { get; set; } = [];
    public ImmutableArray<string> EditedGroups { get; set; } = [];
    public ImmutableArray<string> AcquiredSinceAssessment { get; set; } = [];
    public FrozenConditionV1? Statement { get; set; }
    public string StatementMethodId { get; set; } = "";
    public ImmutableArray<SubjectProjectionId> Evidence { get; set; } = [];
    public bool RequiresEvidence { get; set; }
    public SubjectiveAgentState() { }
    public SubjectiveAgentState(SubjectProjectionId actor, uint seed = 0x9E3779B9) { Actor = actor; TieState = seed == 0 ? 0x9E3779B9 : seed; }
    public byte[] Encode() => SubjectiveAgent.Encode(this);
    public static SubjectiveAgentState Decode(byte[] bytes) => SubjectiveAgent.Decode(bytes);
}
public sealed record SubjectiveInformationBaselineV1(string MethodId, ImmutableArray<SubjectiveProofV1> Proofs);
public sealed record SubjectiveDeferredMethodV1(string MethodId, FrozenConditionV1 Required);

public static class SubjectiveAgent
{
    private sealed class ConditionConverter : JsonConverter<FrozenConditionV1>
    {
        public override FrozenConditionV1 Read(ref Utf8JsonReader reader, Type type, JsonSerializerOptions options)
        {
            using var document = JsonDocument.ParseValue(ref reader);
            // Reuse the closed cognition AST parser without widening its schema.
            var wrapper = "{\"kind\":\"think\",\"fact\":" + document.RootElement.GetRawText() + "}";
            using var effect = CognitionCodec.Parse(Encoding.UTF8.GetBytes(wrapper));
            return ((FrozenEffectV1.Think)CognitionCodec.ReadEffect(effect.RootElement)).Fact;
        }
        public override void Write(Utf8JsonWriter writer, FrozenConditionV1 value, JsonSerializerOptions options)
            => CognitionCodec.Write(value)!.WriteTo(writer);
    }
    private static readonly JsonSerializerOptions Json = CreateJson();
    private static JsonSerializerOptions CreateJson()
    {
        var resolver = new DefaultJsonTypeInfoResolver();
        resolver.Modifiers.Add(info => { if (info.Kind == JsonTypeInfoKind.Object) foreach (var property in info.Properties) property.IsRequired = true; });
        var json = new JsonSerializerOptions { UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow, TypeInfoResolver = resolver, MaxDepth = 1024 };
        json.Converters.Add(new ConditionConverter()); return json;
    }
    private static bool Same(FrozenConditionV1 a, FrozenConditionV1 b) => Contract.Value(Ast.Equivalent(a, b));
    private static bool GoalMatches(FrozenConditionV1 goal, FrozenConditionV1 claim) => Same(goal, claim)
        || goal is FrozenConditionV1.Any alternatives && alternatives.Items.Any(option => GoalMatches(option, claim));
    public static byte[] Encode(SubjectiveAgentState state) { ValidateState(state); return JsonSerializer.SerializeToUtf8Bytes(state, Json); }
    public static SubjectiveAgentState Decode(byte[] bytes)
    {
        using var doc = CognitionCodec.Parse(bytes);
        var state = doc.RootElement.Deserialize<SubjectiveAgentState>(Json) ?? throw new InvalidDataException("subjective_agent_missing");
        ValidateState(state); return state;
    }
    private static void ValidateState(SubjectiveAgentState state)
    {
        if (state is null) throw new InvalidDataException("subjective_agent_state");
        Contract.Id(state.Actor, state.Actor.SubjectWorld, "agent.actor");
        if (state.Version != 1 || state.Receipts.IsDefault || state.InformationReceipts.IsDefault || state.KnownMethods.IsDefault || state.Information.IsDefault
            || state.Deferred.IsDefault || state.EditedGroups.IsDefault || state.Evidence.IsDefault || state.AcquiredSinceAssessment.IsDefault
            || state.Receipts.Length > 20000 || state.InformationReceipts.Length > 20000 || state.KnownMethods.Length > 20000 || state.Information.Length > 20000
            || state.Deferred.Length > 20000 || state.EditedGroups.Length > 20000 || state.AcquiredSinceAssessment.Length > 20000)
            throw new InvalidDataException("subjective_agent_state");
        _ = SubjectiveDecisionMemory.Restore(state.Memory);
        if (state.Receipts.Distinct(StringComparer.Ordinal).Count() != state.Receipts.Length
            || state.InformationReceipts.Distinct(StringComparer.Ordinal).Count() != state.InformationReceipts.Length)
            throw new InvalidDataException("subjective_agent_duplicate_receipt");
        if (state.KnownMethods.Select(o => (o.MethodId, o.Context)).Distinct().Count() != state.KnownMethods.Length
            || state.Information.Select(i => i.MethodId).Distinct(StringComparer.Ordinal).Count() != state.Information.Length
            || state.Deferred.Select(d => d.MethodId).Distinct(StringComparer.Ordinal).Count() != state.Deferred.Length
            || state.EditedGroups.Distinct(StringComparer.Ordinal).Count() != state.EditedGroups.Length
            || state.AcquiredSinceAssessment.Distinct(StringComparer.Ordinal).Count() != state.AcquiredSinceAssessment.Length)
            throw new InvalidDataException("subjective_agent_duplicate_state_entry");
        foreach (var id in state.Receipts.Concat(state.InformationReceipts).Concat(state.EditedGroups).Concat(state.AcquiredSinceAssessment)) Identity(id, "agent.identity");
        if (state.StatementMethodId is null || state.StatementMethodId.Length > 2048) throw new InvalidDataException("subjective_agent_statement_method");
        foreach (var method in state.KnownMethods)
        {
            ValidateOffer(method, state.Actor.SubjectWorld, method.Materials.ToHashSet());
            foreach (var claim in method.Claims) ValidateCondition(claim, state.Actor.SubjectWorld);
        }
        foreach (var baseline in state.Information)
        {
            Identity(baseline.MethodId, "agent.information.method"); Contract.Array(baseline.Proofs, "agent.information.proofs");
            if (baseline.Proofs.Length > 20000) throw new InvalidDataException("subjective_agent_proof_limit");
            foreach (var proof in baseline.Proofs)
            {
                ValidateCondition(proof.Proposition, state.Actor.SubjectWorld); Contract.Enum(proof.Value, "proof.value");
                Contract.Array(proof.Basis, "proof.basis"); Contract.Array(proof.Derivations, "proof.derivations"); Contract.Array(proof.Missing, "proof.missing");
                Contract.Array(proof.Steps, "proof.steps");
                if (proof.Basis.Length > 20000 || proof.Derivations.Length > 20000 || proof.Missing.Length > 20000 || proof.Steps.Length > 20000)
                    throw new InvalidDataException("subjective_agent_proof_limit");
                foreach (var step in proof.Steps) Text(step, "proof.step");
                foreach (var id in proof.Basis) Contract.Id(id, state.Actor.SubjectWorld, "proof.basis");
                foreach (var missing in proof.Missing) ValidateCondition(missing, state.Actor.SubjectWorld);
                foreach (var derivation in proof.Derivations)
                {
                    Contract.Id(derivation.Source, state.Actor.SubjectWorld, "proof.source"); ValidateCondition(derivation.Conclusion, state.Actor.SubjectWorld);
                    Contract.Array(derivation.Premises, "proof.premises"); foreach (var premise in derivation.Premises) ValidateCondition(premise, state.Actor.SubjectWorld);
                }
            }
        }
        foreach (var deferred in state.Deferred) { Identity(deferred.MethodId, "agent.deferred.method"); ValidateCondition(deferred.Required, state.Actor.SubjectWorld); }
        foreach (var id in state.Evidence) Contract.Id(id, state.Actor.SubjectWorld, "agent.evidence");
        if (state.Statement is not null) ValidateCondition(state.Statement, state.Actor.SubjectWorld);
    }
    public static bool Feedback(SubjectiveAgentState state, SubjectiveAgentFeedbackV1 feedback)
    {
        ValidateState(state);
        if (string.IsNullOrWhiteSpace(feedback.ReceiptId) || string.IsNullOrWhiteSpace(feedback.MethodId)) throw new ArgumentException("subjective_agent_feedback_identity");
        if (state.Receipts.Contains(feedback.ReceiptId, StringComparer.Ordinal)) return false;
        if (state.Receipts.Length >= 20000) throw new InvalidOperationException("subjective_agent_receipt_limit");
        if (feedback.InformationIdentity is null || feedback.InformationIdentity.Length > 1024)
            throw new ArgumentException("subjective_agent_information_identity");
        var isExperiment = state.KnownMethods.Any(o => o.MethodId == feedback.MethodId && o.Kind == SubjectiveActionKindV1.Test);
        var isNonInformational = state.KnownMethods.Any(o => o.MethodId == feedback.MethodId
            && o.Kind is not (SubjectiveActionKindV1.Observe or SubjectiveActionKindV1.Test));
        var semanticReceipt = feedback.InformationIdentity.Length == 0 ? ""
            : Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(feedback.InformationIdentity)));
        var newInformation = !isNonInformational && feedback.AcquiredInformation && feedback.Outcome == DecisionOutcomeV1.Succeeded
            && (semanticReceipt.Length > 0 ? !state.InformationReceipts.Contains(semanticReceipt, StringComparer.Ordinal) : !isExperiment);
        if (newInformation && semanticReceipt.Length > 0)
        {
            Identity(semanticReceipt, "agent.information_receipt");
            if (state.InformationReceipts.Length >= 20000) throw new InvalidOperationException("subjective_agent_information_receipt_limit");
            state.InformationReceipts = state.InformationReceipts.Add(semanticReceipt);
        }
        var memory = SubjectiveDecisionMemory.Restore(state.Memory);
        memory.Record(new(feedback.MethodId, feedback.Context), feedback.Outcome);
        state.Memory = memory.Capture(); state.Receipts = state.Receipts.Add(feedback.ReceiptId);
        if (newInformation && !state.AcquiredSinceAssessment.Contains(feedback.MethodId, StringComparer.Ordinal))
            state.AcquiredSinceAssessment = state.AcquiredSinceAssessment.Add(feedback.MethodId);
        if (newInformation && isExperiment)
        {
            var experimentSources = state.KnownMethods.Where(o => o.MethodId == feedback.MethodId && o.Kind == SubjectiveActionKindV1.Test)
                .Select(o => o.SourceId).ToHashSet(StringComparer.Ordinal);
            var completedGroups = state.KnownMethods.Where(o => o.Kind == SubjectiveActionKindV1.Edit && experimentSources.Contains(o.SourceId))
                .Select(o => o.GroupId).ToHashSet(StringComparer.Ordinal);
            state.EditedGroups = [..state.EditedGroups.Where(group => !completedGroups.Contains(group))];
        }
        return true;
    }

    public static SubjectiveAgentAssessmentV1 Assess(SubjectiveAgentRequestV1 request, SubjectiveAgentState state)
        => Assess(request, state, new SubjectiveReasoner(request.Snapshot, request.Actor, request.Budget));
    internal static SubjectiveAgentAssessmentV1 Assess(SubjectiveAgentRequestV1 request, SubjectiveAgentState state, SubjectRead.View view)
        => Assess(request, state, new SubjectiveReasoner(view, request.Actor, request.Budget));

    private static SubjectiveAgentAssessmentV1 Assess(SubjectiveAgentRequestV1 request, SubjectiveAgentState state, SubjectiveReasoner reasoner)
    {
        using var timing = CorePerformance.Begin("core.agent_assess");
        using (CorePerformance.Begin("core.agent_validate_state")) ValidateState(state);
        if (state.Actor != request.Actor) throw new InvalidOperationException("subjective_agent_actor_domain");
        Contract.Array(request.Offers, "offers"); Contract.Array(request.CompleteMethodScopes, "method_scopes");
        Contract.Array(request.PresentableMaterials, "presentable_materials");
        if (request.Offers.Length > 20000 || request.Offers.Select(o => o.Id).Distinct(StringComparer.Ordinal).Count() != request.Offers.Length)
            throw new ArgumentException("subjective_agent_offers");
        if (new[] { request.Motives.Revisit, request.Motives.Information, request.Motives.Argument }.Any(w => w is < 0 or > 1000000))
            throw new ArgumentOutOfRangeException(nameof(request));
        var nodes = request.Snapshot.Projections.ToDictionary(p => p.Id);
        var ids = nodes.Keys.ToHashSet();
        foreach (var id in request.PresentableMaterials)
        { Contract.Id(id, request.Snapshot.SubjectWorld, "presentable_material"); Contract.Require(ids.Contains(id), ContractErrorCode.InvalidReference, "presentable_material", "出示材料不在本人图。"); }
        foreach (var offer in request.Offers)
        {
            ValidateOffer(offer, request.Actor.SubjectWorld, ids);
            foreach (var claim in offer.Claims) reasoner.References(claim);
        }
        foreach (var scope in request.CompleteMethodScopes) Contract.Identity(scope.SourceId, "scope.source");
        if (request.CompleteMethodScopes.Length > 20000 || request.PresentableMaterials.Length > 20000
            || request.CompleteMethodScopes.Distinct().Count() != request.CompleteMethodScopes.Length)
            throw new ArgumentException("subjective_agent_method_scopes");
        var memory = SubjectiveDecisionMemory.Restore(state.Memory);
        var proofs = new List<SubjectiveProofV1>();
        SubjectiveProofV1 Prove(FrozenConditionV1 claim)
        {
            var existing = proofs.FirstOrDefault(p => Same(p.Proposition, claim));
            if (existing is not null) return existing;
            var proof = reasoner.ProveCached(claim); proofs.Add(proof); return proof;
        }
        bool Grounded(SubjectiveProofV1 proof) => proof is { Value: Truth.True, Complete: true, Hypothetical: false, Contradicted: false };
        bool Available(SubjectProjectionId id) => nodes.TryGetValue(id, out var node) && node.Existence == Truth.True;
        bool HasPresentableBasis(SubjectiveProofV1 proof) => proof.Basis.Any(id => Available(id)
            && (request.PresentableMaterials.Contains(id) || request.Offers.Any(o => o.Presentable && o.Materials.Contains(id))
                || state.KnownMethods.Any(o => o.Presentable && o.Materials.Contains(id))));
        ImmutableArray<FrozenConditionV1> Claims(SubjectiveOfferV1 offer) => offer.Claims.Length > 0 ? offer.Claims
            : [..offer.Materials.SelectMany(id => reasoner.Claims(id)).Distinct()];
        bool Relevant(FrozenConditionV1 query, SubjectiveProofV1? goal) => goal is not null
            && (GoalMatches(goal.Proposition, query) || goal.Missing.Any(missing => Same(missing, query)));

        // An explicit complete observed set replaces only its exact source/scope.
        // Partial views and leaving a source cannot withdraw remembered methods.
        var known = state.KnownMethods.Where(o => o.Materials.All(nodes.ContainsKey) && o.Claims.SelectMany(References).All(nodes.ContainsKey)
            && !request.CompleteMethodScopes.Any(s => s.SourceId == o.SourceId && s.ScopeId == o.ScopeId)).ToList();
        foreach (var offer in request.Offers.Where(o => o.Kind is not (SubjectiveActionKindV1.Travel or SubjectiveActionKindV1.Wait or SubjectiveActionKindV1.Acknowledge)))
        {
            known.RemoveAll(o => o.MethodId == offer.MethodId && o.Context == offer.Context);
            // Remember the acquired method, not transient rendering selections,
            // scores, route distances or verbose evaluation diagnostics.
            known.Add(offer with { Selected = false, RuleScore = 0, RuleBasis = [], Preferences = [], Cost = 0, Distance = null });
        }
        state.KnownMethods = [..known];
        state.Information = [..state.Information.Where(b => b.Proofs.All(p => References(p.Proposition).All(nodes.ContainsKey)
            && p.Basis.All(nodes.ContainsKey) && p.Missing.SelectMany(References).All(nodes.ContainsKey)
            && p.Derivations.All(d => nodes.ContainsKey(d.Source) && References(d.Conclusion).All(nodes.ContainsKey)
                && d.Premises.SelectMany(References).All(nodes.ContainsKey))))];
        state.Deferred = [..state.Deferred.Where(d => References(d.Required).All(nodes.ContainsKey))];
        if (state.KnownMethods.Length > 20000) throw new InvalidOperationException("subjective_agent_method_limit");
        if (request.Offers.Any(o => o.RequiresEvidence)) state.RequiresEvidence = true;
        if (state.Statement is not null)
            try { reasoner.References(state.Statement); }
            catch (CognitionContractException) { state.Statement = null; state.Evidence = []; }
        state.Evidence = [..state.Evidence.Where(Available)];
        var selected = request.Offers.FirstOrDefault(o => o.Kind == SubjectiveActionKindV1.Assert && o.Selected);
        if (selected is not null && Claims(selected) is { Length: 1 } selectedClaims)
        {
            if (state.Statement is null || !Same(state.Statement, selectedClaims[0])) state.Evidence = [];
            state.Statement = selectedClaims[0]; state.StatementMethodId = selected.MethodId;
        }
        var selectedEvidence = request.Offers.FirstOrDefault(o => o.Kind == SubjectiveActionKindV1.Present && o.Selected && o.Presentable);
        if (selectedEvidence is not null) state.Evidence = selectedEvidence.Materials;

        // Proof changes reopen just the affected method. Acquiring its own result
        // updates the baseline instead of immediately manufacturing another attempt.
        // The current goal gets the actor's budget before old, unrelated offers.
        SubjectiveProofV1 GoalProof(FrozenConditionV1 goal)
        {
            if (goal is not FrozenConditionV1.Any alternatives) return Prove(goal);
            // A public question's alternatives are queried at the actor's root
            // depth. The question envelope is not an extra inferential step.
            var options = alternatives.Items.Select(Prove).ToArray();
            var supported = options.Where(Grounded).ToArray();
            var denied = options.Length > 0 && options.All(p => p.Value == Truth.False && !p.Contradicted && p.Complete);
            return new(goal, supported.Length > 0 ? Truth.True : denied ? Truth.False : Truth.Unknown,
                supported.Length == 0 && options.Any(p => p.Contradicted), false,
                [..supported.SelectMany(p => p.Basis).Distinct()], ["public_question_alternatives"])
            { Complete = supported.Length > 0 || options.All(p => p.Complete),
                Derivations = [..supported.SelectMany(p => p.Derivations).Distinct()],
                Missing = supported.Length > 0 ? [] : [..options.SelectMany(p => p.Missing).Distinct()] };
        }
        var goalProof = request.Goal is null ? null : GoalProof(request.Goal);
        var baselines = state.Information.ToDictionary(b => b.MethodId, StringComparer.Ordinal);
        foreach (var method in state.KnownMethods.GroupBy(o => o.MethodId).Select(g => g.Last())
            .Where(o => request.Offers.Any(current => current.MethodId == o.MethodId)
                || Claims(o).Any(claim => Relevant(claim, goalProof)))
            .OrderByDescending(o => Claims(o).Any(claim => Relevant(claim, goalProof))))
        {
            var claims = Claims(method); if (claims.Length == 0) continue;
            var current = claims.Select(Prove).ToImmutableArray();
            if (current.Any(p => !p.Complete)) continue;
            if (baselines.TryGetValue(method.MethodId, out var previous) && !SameInformation(previous.Proofs, current)
                && !state.AcquiredSinceAssessment.Contains(method.MethodId, StringComparer.Ordinal))
                memory.ReconsiderAttempts(memory.Capture().Experiences.Where(e => e.Key.Method == method.MethodId).Select(e => e.Key));
            baselines[method.MethodId] = new(method.MethodId, current);
        }
        state.Information = [..baselines.Values]; state.AcquiredSinceAssessment = [];
        state.Memory = memory.Capture();
        bool Answerable() => goalProof is not null && Grounded(goalProof) && (!state.RequiresEvidence || HasPresentableBasis(goalProof));
        var statementProof = state.Statement is null ? null : Prove(state.Statement);
        bool EvidenceSupports(SubjectiveProofV1 proof, SubjectiveOfferV1 offer) => offer.Presentable
            && offer.Materials.Any(id => Available(id) && proof.Basis.Contains(id));
        bool SupportsStatement() => statementProof is not null && Grounded(statementProof)
            && (!state.RequiresEvidence || state.Evidence.Any(id => Available(id) && statementProof.Basis.Contains(id)));
        bool Deferred(SubjectiveOfferV1 offer) => state.Deferred.Where(d => d.MethodId == offer.MethodId)
            .Any(d => { var proof = Prove(d.Required); return !Grounded(proof) || state.RequiresEvidence && !HasPresentableBasis(proof); });

        // The hypothesis space is acquired from actual offered variables. No
        // objective model, hidden answer combinations or unconstrained expansion.
        var groups = request.Offers.Where(o => o.Kind == SubjectiveActionKindV1.Edit && o.GroupId.Length > 0)
            .GroupBy(o => o.GroupId).ToArray();
        var hypotheses = ImmutableArray.CreateBuilder<SubjectiveHypothesisV1>();
        void Combine(int at, ImmutableArray<FrozenConditionV1> assumptions, string identity)
        {
            // One acquired overflow candidate lets the shared reasoner report
            // hypothesis_budget while still evaluating only the role's limit.
            if (hypotheses.Count > request.Budget.Hypotheses) return;
            if (at == groups.Length) { if (assumptions.Length > 0) hypotheses.Add(new(identity, assumptions)); return; }
            foreach (var choice in groups[at])
                if (Claims(choice) is { Length: 1 } claims) Combine(at + 1, assumptions.Add(claims[0]), identity + "/" + choice.MethodId);
        }
        Combine(0, [], "hypothesis");
        var inquiries = request.Goal is null ? reasoner.KnownQueries.Take(16).ToImmutableArray()
            : goalProof is { Missing.Length: > 0 } ? goalProof.Missing
            : request.Goal is FrozenConditionV1.Any alternatives ? alternatives.Items : [request.Goal];
        var exploration = reasoner.ExploreCached(inquiries, hypotheses.ToImmutable());
        var result = ImmutableArray.CreateBuilder<SubjectiveOfferAssessmentV1>();
        var reweight = request.Motives.Revisit; var informationWeight = request.Motives.Information; var argumentWeight = request.Motives.Argument;
        var methodAttempts = memory.Capture().Experiences.GroupBy(e => e.Key.Method)
            .ToDictionary(g => g.Key, g => (int)Math.Min(g.Sum(e => (long)e.Attempts), 1000000), StringComparer.Ordinal);
        DecisionExperienceV1 Experience(SubjectiveOfferV1 offer)
        {
            var local = memory.Get(new(offer.MethodId, offer.Context));
            // Acquired-method novelty is stable across approaches. Only observed
            // failures/stalls depend on the particular execution context.
            return local with { Attempts = offer.InformationContext.Length > 0
                ? memory.Get(new(offer.MethodId, offer.InformationContext)).Attempts : methodAttempts.GetValueOrDefault(offer.MethodId) };
        }
        bool Untried(SubjectiveOfferV1 offer) => Experience(offer).Attempts == 0;
        bool SourceHasUntried(string source) => state.KnownMethods.Any(o => o.SourceId == source && !o.Forbidden
            && o.AcquiresInformation && (o.Kind is SubjectiveActionKindV1.Observe or SubjectiveActionKindV1.Test) && Untried(o));
        bool SourceRelevant(string source) => state.KnownMethods.Where(o => o.SourceId == source)
            .SelectMany(o => Claims(o)).Any(claim => Relevant(claim, goalProof));
        bool SourceReady(string source) => Answerable() && state.KnownMethods.Where(o => o.SourceId == source)
            .SelectMany(o => Claims(o)).Any(claim => request.Goal is not null && GoalMatches(request.Goal, claim) && Grounded(Prove(claim)));
        foreach (var offer in request.Offers)
        {
            var experience = Experience(offer);
            var why = offer.RuleBasis.ToBuilder(); var arguments = ImmutableArray.CreateBuilder<SubjectiveProofV1>();
            long ruleScore = offer.RuleScore; var forbidden = offer.Forbidden;
            var activePreferences = offer.Preferences.Where(p => p.Condition == SubjectivePreferenceConditionV1.Always
                || p.Condition == SubjectivePreferenceConditionV1.New && offer.Novel && Untried(offer)
                    && offer.Kind is not (SubjectiveActionKindV1.Withdraw or SubjectiveActionKindV1.Hide or SubjectiveActionKindV1.Destroy or SubjectiveActionKindV1.Edit)
                || p.Condition == SubjectivePreferenceConditionV1.Untried && Untried(offer)
                    && offer.Kind is not (SubjectiveActionKindV1.Withdraw or SubjectiveActionKindV1.Hide or SubjectiveActionKindV1.Destroy or SubjectiveActionKindV1.Edit)).ToArray();
            var permit = activePreferences.Where(p => p.Mode == RuleMode.Permit).Select(p => p.Weight).DefaultIfEmpty(-1).Max();
            foreach (var preference in activePreferences)
            {
                if (preference.Mode is RuleMode.Prefer or RuleMode.Require) ruleScore += preference.Weight;
                if (preference.Mode == RuleMode.Forbid && permit < preference.Weight) forbidden = true;
                why.Add(preference.Basis);
            }
            var learned = SubjectiveDecision.Evaluate(new((int)Math.Clamp(ruleScore, -100000000, 100000000), experience,
                request.Offers.Length > 1 && offer.Kind is not (SubjectiveActionKindV1.Withdraw or SubjectiveActionKindV1.Acknowledge) ? reweight : 0,
                Cost: offer.Cost, Forbidden: forbidden, NecessaryReturn: offer.Kind == SubjectiveActionKindV1.Travel,
                FailureWeight: reweight));
            long score = learned.Score; why.AddRange(learned.Basis);
            var destination = offer.DestinationSourceId.Length > 0 ? offer.DestinationSourceId : offer.SourceId;
            if (offer.DestinationSourceId.Length > 0 && offer.Kind is (SubjectiveActionKindV1.Open or SubjectiveActionKindV1.Travel))
            {
                if (SourceHasUntried(destination)) { score += informationWeight * 2L; why.Add("return_for_untried_observed_method"); }
                if (SourceReady(destination)) { score += argumentWeight * 3L; why.Add("return_with_personal_answer"); }
                else if (SourceRelevant(destination) && SourceHasUntried(destination)) { score += informationWeight * 3L; why.Add("seek_current_question_material"); }
                else if (goalProof is { Value: Truth.Unknown } && Untried(offer)
                    && !state.KnownMethods.Any(o => o.SourceId == destination && o.AcquiresInformation))
                { score += informationWeight * 2L; why.Add("examine_unexamined_for_open_question"); }
            }
            if (offer.Frontier && Untried(offer) && (offer.Kind is SubjectiveActionKindV1.Travel or SubjectiveActionKindV1.Open))
            { score += informationWeight + reweight; why.Add("edge_of_unseen"); }
            if (!offer.KnownGround && offer.Kind == SubjectiveActionKindV1.Travel && Untried(offer))
            { score += reweight; why.Add("unwalked_ground"); }
            if (offer.Kind == SubjectiveActionKindV1.Travel && offer.Distance is { } distance)
            {
                var routes = request.Offers.Where(o => o.Kind == SubjectiveActionKindV1.Travel && o.Distance is not null).Select(o => o.Distance!.Value).ToArray();
                if (SourceRelevant(destination) || SourceReady(destination) || SourceHasUntried(destination))
                    score += SubjectiveDecision.DirectionValue(distance, routes.Min(), routes.Max(), SourceReady(destination) ? argumentWeight : informationWeight);
            }
            if (offer.AcquiresInformation && Untried(offer) && (offer.Kind is SubjectiveActionKindV1.Observe or SubjectiveActionKindV1.Test))
            {
                foreach (var claim in Claims(offer))
                {
                    var proof = Prove(claim); arguments.Add(proof);
                    var value = SubjectiveDecision.InformationValue(proof, Relevant(claim, goalProof), informationWeight);
                    score += value; if (value > 0) why.Add("seek_unknown_acquired_proposition");
                }
                foreach (var inquiry in exploration.Inquiries.Where(q => q.Targets.Any(offer.Materials.Contains)))
                { score += informationWeight * (1L + Math.Min(inquiry.DiscriminatingPairs, 1000)); why.Add("expected_subjective_information"); }
                if (goalProof is { Value: Truth.Unknown } && Claims(offer).Length == 0)
                { score += informationWeight * 2L; why.Add("examine_unexamined_for_open_question"); }
            }
            if (offer.Kind is SubjectiveActionKindV1.Assert or SubjectiveActionKindV1.Edit)
            {
                foreach (var claim in Claims(offer))
                {
                    var proof = Prove(claim); arguments.Add(proof);
                    if (!proof.Complete || proof.Hypothetical) continue;
                    if (proof.Contradicted || proof.Value == Truth.False) score -= argumentWeight;
                    else if (Grounded(proof))
                    {
                        score += argumentWeight; why.Add("subjective_argument_supported");
                        if (request.Goal is not null && GoalMatches(request.Goal, claim)) score += argumentWeight * 2L;
                    }
                }
                if (offer.Kind == SubjectiveActionKindV1.Assert && request.Goal is not null
                    && !Claims(offer).Any(claim => GoalMatches(request.Goal, claim) && Grounded(Prove(claim)))) forbidden = true;
                if (offer.Kind == SubjectiveActionKindV1.Edit && state.EditedGroups.Contains(offer.GroupId, StringComparer.Ordinal)
                    && !offer.Selected && !Claims(offer).Any(claim => Grounded(Prove(claim)))) forbidden = true;
                if (offer.Kind == SubjectiveActionKindV1.Edit && !Claims(offer).Any(claim => Grounded(Prove(claim)))
                    && request.Offers.Any(other => other.Kind == SubjectiveActionKindV1.Edit && other.GroupId == offer.GroupId
                        && Claims(other).Any(claim => Grounded(Prove(claim))))) forbidden = true;
            }
            if (offer.Kind == SubjectiveActionKindV1.Present)
            {
                if (statementProof is not null) arguments.Add(statementProof);
                if (statementProof is not null && Grounded(statementProof) && EvidenceSupports(statementProof, offer))
                { score += argumentWeight * 3L; why.Add("subjective_argument_supported"); }
                else { forbidden = true; score -= argumentWeight; why.Add("evidence_does_not_support_statement"); }
            }
            if (offer.Kind == SubjectiveActionKindV1.Commit)
            {
                if (statementProof is not null) arguments.Add(statementProof);
                if (state.Statement is not null && !SupportsStatement() || state.Statement is null && (offer.RequiresEvidence || goalProof is { Value: Truth.Unknown }))
                { forbidden = true; why.Add("statement_missing_grounded_support"); }
                else if (state.Statement is not null && request.Goal is not null && !GoalMatches(request.Goal, state.Statement))
                { forbidden = true; why.Add("statement_not_current_question"); }
                else if (state.Statement is not null) { score += argumentWeight * 4L; why.Add("grounded_statement_ready"); }
            }
            if (offer.Kind == SubjectiveActionKindV1.Destroy) { score -= argumentWeight * 2L; why.Add("destroys_seen_material"); }
            if (Deferred(offer)) { score -= argumentWeight * 2L; why.Add("observed_answer_still_missing_support"); }
            if (offer.Selected) score -= argumentWeight * 4L;
            result.Add(new(offer, (int)Math.Clamp(score, -100000000L, 100000000L), forbidden, why.Distinct().ToImmutableArray(), arguments.ToImmutable()));
        }
        // Leaving an exhausted information source is a neutral transition.
        // A withdrawal cost applies only to abandoning an actual grounded
        // commitment that this execution port currently offers to submit.
        if (state.Statement is not null && SupportsStatement()
            && result.Any(a => a.Offer.Kind == SubjectiveActionKindV1.Commit && !a.Forbidden))
            for (var i = 0; i < result.Count; i++)
                if (result[i].Offer.Kind == SubjectiveActionKindV1.Withdraw)
                    result[i] = result[i] with {
                        Score = (int)Math.Clamp((long)result[i].Score - argumentWeight, -100000000L, 100000000L),
                        Basis = result[i].Basis.Add("withdraws_grounded_pending_statement")
                    };
        return new(request.Snapshot.Revision, result.ToImmutable(), exploration with { Expansions = reasoner.Expansions, StopReason = reasoner.StopReason }) { GoalProof = goalProof };
    }

    public static SubjectiveAgentChoiceV1 Decide(SubjectiveAgentRequestV1 request, SubjectiveAgentState state)
        => Choose(request, state, Assess(request, state));
    /// <summary>Resolve an explicitly selected acquired offer through the same
    /// availability and commitment policy, without changing a person's choice.</summary>
    public static SubjectiveAgentChoiceV1 Select(SubjectiveAgentRequestV1 request, SubjectiveAgentState state, string offerId)
    {
        Identity(offerId, "selection.offer");
        return Choose(request, state, Assess(request, state), offerId);
    }
    internal static SubjectiveAgentChoiceV1 Decide(SubjectiveAgentRequestV1 request, SubjectiveAgentState state, SubjectRead.View view)
        => Choose(request, state, Assess(request, state, view));
    private static SubjectiveAgentChoiceV1 Choose(SubjectiveAgentRequestV1 request, SubjectiveAgentState state, SubjectiveAgentAssessmentV1 assessment, string? selectedId = null)
    {
        var allowed = assessment.Offers.Where(o => !o.Forbidden).ToArray();
        if (allowed.Length == 0) return new(null, assessment);
        SubjectiveOfferV1 selected;
        if (selectedId is not null)
        {
            var explicitChoice = allowed.FirstOrDefault(o => o.Offer.Id == selectedId);
            if (explicitChoice is null) return new(null, assessment);
            selected = explicitChoice.Offer;
        }
        else
        {
            var best = allowed.Max(o => o.Score); var tied = allowed.Where(o => o.Score == best).ToArray();
            if (tied.Length > 1)
            { state.TieState ^= state.TieState << 13; state.TieState ^= state.TieState >> 17; state.TieState ^= state.TieState << 5; }
            selected = tied[(int)(state.TieState % (uint)tied.Length)].Offer;
        }
        if (selected.Kind == SubjectiveActionKindV1.Assert)
        {
            var claims = selected.Claims.Length > 0 ? selected.Claims
                : assessment.Offers.First(o => o.Offer.Id == selected.Id).Arguments.Select(p => p.Proposition).Distinct().ToImmutableArray();
            if (claims.Length == 1) { state.Statement = claims[0]; state.StatementMethodId = selected.MethodId; state.Evidence = []; }
        }
        if (selected.Kind == SubjectiveActionKindV1.Present) state.Evidence = selected.Materials;
        if (selected.Kind == SubjectiveActionKindV1.Edit && selected.GroupId.Length > 0 && !state.EditedGroups.Contains(selected.GroupId, StringComparer.Ordinal))
            state.EditedGroups = state.EditedGroups.Add(selected.GroupId);
        if (selected.Kind == SubjectiveActionKindV1.Withdraw && request.Goal is not null && assessment.GoalProof is { Value: Truth.Unknown })
            state.Deferred = state.Deferred.Where(d => d.MethodId != state.StatementMethodId).Append(new(state.StatementMethodId, request.Goal))
                .Where(d => d.MethodId.Length > 0).ToImmutableArray();
        if (selected.Kind is SubjectiveActionKindV1.Commit or SubjectiveActionKindV1.Withdraw)
        { state.Statement = null; state.StatementMethodId = ""; state.Evidence = []; state.EditedGroups = []; }
        return new(selected.Id, assessment);
    }
    private static bool SameInformation(ImmutableArray<SubjectiveProofV1> left, ImmutableArray<SubjectiveProofV1> right)
        => left.Length == right.Length && left.All(a => right.Any(b => Same(a.Proposition, b.Proposition)
            && a.Value == b.Value && a.Complete == b.Complete && a.Contradicted == b.Contradicted && a.Hypothetical == b.Hypothetical
            && a.Missing.Length == b.Missing.Length && a.Missing.All(x => b.Missing.Any(y => Same(x, y)))));
    private static void ValidateOffer(SubjectiveOfferV1 offer, Guid world, HashSet<SubjectProjectionId> nodes)
    {
        Identity(offer.Id, "offer.id"); Identity(offer.MethodId, "offer.method"); Identity(offer.SourceId, "offer.source");
        Contract.Enum(offer.Kind, "offer.kind"); Contract.Array(offer.Materials, "offer.materials"); Contract.Array(offer.Claims, "offer.claims");
        Contract.Array(offer.Preferences, "offer.preferences"); Contract.Array(offer.RuleBasis, "offer.basis");
        Contract.Text(offer.ScopeId, "offer.scope"); Contract.Text(offer.Context, "offer.context"); Contract.Text(offer.GroupId, "offer.group");
        Contract.Text(offer.InformationContext, "offer.information_context");
        Contract.Text(offer.DestinationSourceId, "offer.destination");
        if (offer.Context.Length > 2048 || offer.InformationContext.Length > 2048 || offer.GroupId.Length > 2048 || offer.ScopeId.Length > 2048 || offer.DestinationSourceId.Length > 2048
            || offer.Materials.Length > 20000 || offer.Claims.Length > 20000 || offer.Preferences.Length > 20000 || offer.RuleBasis.Length > 20000)
            throw new InvalidDataException("subjective_agent_offer_limit");
        Contract.Require(offer.Cost >= 0, ContractErrorCode.MalformedData, "offer.cost", "行动成本不能为负。");
        if (offer.Distance is { } distance) Contract.Number(distance, "offer.distance", true);
        foreach (var id in offer.Materials) { Contract.Id(id, world, "offer.material"); Contract.Require(nodes.Contains(id), ContractErrorCode.InvalidReference, "offer.material", "材料不在本人认知图。"); }
        foreach (var claim in offer.Claims) ValidateCondition(claim, world);
        foreach (var basis in offer.RuleBasis) Text(basis, "offer.basis.entry");
        foreach (var preference in offer.Preferences)
        { Contract.Enum(preference.Condition, "preference.condition"); Contract.Enum(preference.Mode, "preference.mode"); Text(preference.Basis, "preference.basis"); Contract.Require(preference.Weight is >= 0 and <= 1000000, ContractErrorCode.MalformedData, "preference.weight", "偏好权重超限。"); }
    }
    private static void Identity(string value, string path)
    { Contract.Identity(value, path); if (value.Length > 2048) throw new InvalidDataException("subjective_agent_identity_limit"); }
    private static void Text(string value, string path)
    { Contract.Text(value, path); if (value.Length > 2048) throw new InvalidDataException("subjective_agent_text_limit"); }
    private static void ValidateCondition(FrozenConditionV1 condition, Guid world)
    {
        _ = CognitionCodec.Write(condition) ?? throw new InvalidDataException("subjective_agent_condition");
        foreach (var id in References(condition)) Contract.Id(id, world, "agent.condition");
    }
    private static IEnumerable<SubjectProjectionId> References(FrozenConditionV1 condition)
    {
        IEnumerable<SubjectProjectionId> Noun(FrozenNounV1 noun) => noun is FrozenNounV1.Reference reference ? [reference.Target] : [];
        return condition switch {
            FrozenConditionV1.Exists c => Noun(c.Target), FrozenConditionV1.Tagged c => Noun(c.Target),
            FrozenConditionV1.Related c => Noun(c.Target).Concat(Noun(c.Other)), FrozenConditionV1.At c => Noun(c.Target).Concat(Noun(c.Space)),
            FrozenConditionV1.IsKind c => Noun(c.Target), FrozenConditionV1.Not c => References(c.Operand),
            FrozenConditionV1.All c => c.Items.SelectMany(References), FrozenConditionV1.Any c => c.Items.SelectMany(References),
            FrozenConditionV1.Constant => [], _ => throw new InvalidDataException("subjective_agent_condition")
        };
    }
}
