using System.Collections.Immutable;
using System.Text;
using DualOntologyWorldEngine.Core;

// Independent neutral public-contract checks; no story, host geometry or answer tables.
var failures = new List<string>();
void Check(bool value, string why) { if (!value) throw new InvalidOperationException(why); }
void Reject(Action action, string why) {
    try { action(); } catch (Exception e) when (e is ArgumentException or InvalidOperationException or InvalidDataException or CognitionContractException or System.Text.Json.JsonException) { return; }
    throw new InvalidOperationException(why);
}
void Run(string name, Action body) { try { body(); Console.WriteLine("PASS " + name); } catch (Exception e) { failures.Add(name); Console.WriteLine("FAIL " + name + "\n" + e); } }
SubjectiveAgentRequestV1 Request(Fixture f, params SubjectiveOfferV1[] offers) => new(f.Snapshot(), f.Actor.SubjectId!.Value, new(4, 256, 8), [..offers], new()) { Goal = f.Claim };
SubjectiveAgentState State(Fixture f) => new(f.Actor.SubjectId!.Value, 42);
DecisionExperienceV1 Experience(SubjectiveAgentState s, string method) => SubjectiveDecisionMemory.Restore(s.Memory).Get(new(method, ""));
string Scores(SubjectiveAgentAssessmentV1 a) => string.Join(";", a.Offers.Select(o => $"{o.Offer.Id}:{o.Score}:{o.Forbidden}:{string.Join(',',o.Basis)}"));

Run("equivalent_host_inputs_hidden_reality_and_subject_isolation", () => {
    var f = new Fixture(); var offer = f.Offer("observe", SubjectiveActionKindV1.Observe) with { AcquiresInformation = true };
    var a = State(f); var b = State(f); var request = Request(f, offer);
    Check(SubjectiveAgent.Decide(request, a).OfferId == SubjectiveAgent.Decide(request, b).OfferId, "Equal host-neutral inputs and seeds must select equally.");
    f.Hidden.Add(new StateProperty()).Values[new("neutral.hidden")] = 999;
    Check(Scores(SubjectiveAgent.Assess(request, a)) == Scores(SubjectiveAgent.Assess(request, b)), "Hidden reality must not affect the public subjective contract.");
    SubjectiveAgent.Feedback(a, new("receipt", "observe", "", DecisionOutcomeV1.Failed));
    Check(Experience(b, "observe").Failures == 0, "Feedback must remain in its own subject state.");
    var alien = new SubjectiveAgentState(new(Guid.NewGuid(), Guid.NewGuid()));
    Reject(() => SubjectiveAgent.Assess(request, alien), "A foreign actor state must be rejected.");
});
Run("real_feedback_receipt_idempotency_and_assessment_purity", () => {
    var f = new Fixture(); var s = State(f); var request = Request(f, f.Offer("observe", SubjectiveActionKindV1.Observe));
    SubjectiveAgent.Assess(request, s); SubjectiveAgent.Decide(request, s);
    Check(Experience(s, "observe").Attempts == 0, "Selection and assessment are not execution feedback.");
    foreach (var outcome in Enum.GetValues<DecisionOutcomeV1>()) {
        var feedback = new SubjectiveAgentFeedbackV1("receipt." + outcome, "observe", "", outcome);
        Check(SubjectiveAgent.Feedback(s, feedback) && !SubjectiveAgent.Feedback(s, feedback), "Duplicate execution receipt must be a no-op.");
    }
    Check(Experience(s, "observe") is { Attempts: 1, Successes: 1, Failures: 1, NoProgress: 1, Interruptions: 1 }, "Real outcomes must retain independent counters.");
});
Run("partial_and_complete_method_scope_lifecycle", () => {
    var f = new Fixture(); var s = State(f); var acquire = f.Offer("observe", SubjectiveActionKindV1.Observe) with { AcquiresInformation = true, ScopeId = "menu" };
    SubjectiveAgent.Assess(Request(f, acquire), s);
    SubjectiveAgent.Assess(Request(f), s);
    Check(s.KnownMethods.Any(o => o.MethodId == "observe"), "Leaving a menu must preserve acquired methods.");
    SubjectiveAgent.Assess(Request(f) with { CompleteMethodScopes = [new("source", "other")] }, s);
    Check(s.KnownMethods.Any(o => o.MethodId == "observe"), "Other complete scope cannot remove this method.");
    SubjectiveAgent.Assess(Request(f) with { CompleteMethodScopes = [new("source", "menu")] }, s);
    Check(!s.KnownMethods.Any(o => o.MethodId == "observe"), "An explicitly complete empty same scope must retire the method.");
});
Run("exhausted_source_no_unlimited_return_bonus", () => {
    var f = new Fixture(); var s = State(f); var acquire = f.Offer("observe", SubjectiveActionKindV1.Observe) with { AcquiresInformation = true };
    SubjectiveAgent.Assess(Request(f, acquire), s);
    SubjectiveAgent.Feedback(s, new("attempt", "observe", "", DecisionOutcomeV1.Attempted));
    var open = f.Offer("open", SubjectiveActionKindV1.Open);
    SubjectiveAgent.Feedback(s, new("open.attempt", "open", "", DecisionOutcomeV1.Attempted));
    var result = SubjectiveAgent.Assess(Request(f, open), s).Offers.Single();
    Check(!result.Basis.Contains("return_for_untried_observed_method") && !result.Basis.Contains("examine_unexamined_for_open_question"), "An exhausted observed source must not keep earning fresh-source bonuses.");
});
Run("non_acquisition_actions_cannot_manufacture_information", () => {
    foreach (var kind in new[] { SubjectiveActionKindV1.Open, SubjectiveActionKindV1.Edit, SubjectiveActionKindV1.Withdraw, SubjectiveActionKindV1.Destroy }) {
        var f = new Fixture(); var s = State(f); var offer = f.Offer("method", kind) with { AcquiresInformation = true };
        var before = f.Snapshot(); var result = SubjectiveAgent.Assess(Request(f, offer), s);
        Check(!result.Offers.Single().Basis.Contains("seek_unknown_acquired_proposition"), kind + " must not be treated as acquiring evidence.");
        Check(f.Snapshot().Revision == before.Revision && Experience(s, "method").Successes == 0, "Scoring cannot publish knowledge or success.");
    }
});
Run("own_result_keeps_attempts_related_external_material_reopens", () => {
    var f = new Fixture(); var s = State(f); var offer = f.Offer("observe", SubjectiveActionKindV1.Observe) with { AcquiresInformation = true };
    SubjectiveAgent.Assess(Request(f, offer), s);
    SubjectiveAgent.Feedback(s, new("attempt", "observe", "", DecisionOutcomeV1.Attempted));
    SubjectiveAgent.Feedback(s, new("success", "observe", "", DecisionOutcomeV1.Succeeded, true));
    f.SetKnown(1); SubjectiveAgent.Assess(Request(f, offer), s);
    Check(Experience(s, "observe") is { Attempts: 1, Successes: 1 }, "Its own acquired result must not immediately reopen the method.");
    f.SetKnown(0); SubjectiveAgent.Assess(Request(f, offer), s);
    Check(Experience(s, "observe") is { Attempts: 0, Successes: 1 }, "Changed relevant external information reopens attempts while preserving real outcomes.");
});
Run("commit_requires_complete_grounded_argument", () => {
    var f = new Fixture(); var s = State(f); var commit = f.Offer("commit", SubjectiveActionKindV1.Commit) with { Claims = [] };
    Check(SubjectiveAgent.Assess(Request(f, commit), s).Offers.Single().Forbidden, "An unanswered goal must not be committable before any statement is selected.");
    s.Statement = f.Claim;
    Check(SubjectiveAgent.Assess(Request(f, commit), s).Offers.Single().Forbidden, "Unknown selected statement cannot be submitted.");
    f.SetKnown(1);
    Check(!SubjectiveAgent.Assess(Request(f, commit), s).Offers.Single().Forbidden, "Complete grounded statement should become committable.");
    var conclusion = f.AddDerivedClaim(); s.Statement = conclusion;
    Check(SubjectiveAgent.Assess(Request(f, commit) with { Goal = conclusion, Budget = new(0, 1, 1) }, s).Offers.Single().Forbidden, "Exhausted proof budget cannot substitute for a complete argument.");
    Check(!SubjectiveAgent.Assess(Request(f, commit) with { Goal = conclusion, Budget = new(4, 256, 8) }, s).Offers.Single().Forbidden, "A restored sufficient budget must permit the complete derivation.");
});
Run("closed_state_restore_and_external_snapshot_validation", () => {
    var f = new Fixture(); var s = State(f); var offer = f.Offer("observe", SubjectiveActionKindV1.Observe);
    SubjectiveAgent.Assess(Request(f, offer), s);
    var restored = SubjectiveAgentState.Decode(s.Encode());
    Check(Scores(SubjectiveAgent.Assess(Request(f, offer), s)) == Scores(SubjectiveAgent.Assess(Request(f, offer), restored)), "Restore must preserve neutral assessment behavior.");
    var wire = Encoding.UTF8.GetString(s.Encode());
    Reject(() => SubjectiveAgentState.Decode(Encoding.UTF8.GetBytes(wire.Insert(1, "\"Unknown\":1,"))), "Unknown state fields must be rejected.");
    Reject(() => SubjectiveAgentState.Decode(Encoding.UTF8.GetBytes(wire.Insert(1, "\"Version\":1,"))), "Duplicate JSON keys must be rejected.");
    Reject(() => new SubjectiveAgentState().Encode(), "Empty actor handles must not be valid persistent state.");
    var malformed = SubjectiveAgentState.Decode(s.Encode());
    malformed.KnownMethods = [offer with { Kind = (SubjectiveActionKindV1)999 }];
    Reject(() => malformed.Encode(), "Closed persistent state must reject unknown action kinds.");
    var snapshot = f.Snapshot();
    Reject(() => SubjectiveAgent.Assess(Request(f, offer) with { Snapshot = snapshot with { Projections = snapshot.Projections.Add(snapshot.Projections[0]) } }, s), "Public snapshot path must still reject duplicate nodes.");
    Reject(() => SubjectiveAgent.Assess(Request(f, offer) with { Snapshot = snapshot with { ContractVersion = 999 } }, s), "Public snapshot path must still reject unsupported versions.");
});
Run("ctb_bulk_order_cancel_and_atomic_invalid_change", () => {
    var clock = new CTBSystem(); var log = new List<string>();
    var a = clock.Schedule(9, () => log.Add("a")); var b = clock.Schedule(4, () => log.Add("b")); var c = clock.Schedule(2, () => log.Add("c"));
    Check(clock.RescheduleMany([(a, 3), (b, 3), (c, 3)]), "All pending bulk deadlines should change together.");
    Reject(() => clock.RescheduleMany([(a, 1), (b, double.NaN)]), "Invalid bulk delay must be rejected.");
    Check(a.Due == 3 && b.Due == 3, "A late invalid item cannot partially apply earlier changes.");
    Check(clock.Cancel(b) && !clock.Cancel(b), "Cancellation must be idempotent.");
    Check(!clock.RescheduleMany([(a, 1), (b, 1)]) && a.Due == 3, "A canceled member invalidates the whole batch.");
    Check(clock.RunUntil(3) == 2 && string.Join(',',log) == "a,c", "Bulk equal deadlines retain insertion ordering and canceled work never activates.");
});
Console.WriteLine(failures.Count == 0 ? "SUBJECTIVE_AGENT_REGRESSION: PASS" : "SUBJECTIVE_AGENT_REGRESSION: FAIL " + string.Join(',', failures));
Environment.ExitCode = failures.Count == 0 ? 0 : 1;

sealed class Fixture {
    public SoulEssence Soul { get; } = new("neutral.subject");
    public Essence Hidden { get; } = new("neutral.hidden");
    public Projection Actor { get; }
    public Projection Material { get; }
    public FrozenConditionV1 Claim => new FrozenConditionV1.Tagged(new FrozenNounV1.Reference(Material.SubjectId!.Value), new("neutral.signal"), 1);
    public Fixture() {
        Actor = Observation.Observe(Soul, new("neutral.actor", ProjectionKind.Body) { Existence = Truth.True });
        Material = Observation.Observe(Soul, new("neutral.material", ProjectionKind.Object) { Existence = Truth.True });
    }
    public CognitionSnapshotV1 Snapshot() => Soul.World.CaptureSnapshot() is ContractResult<CognitionSnapshotV1>.Success success ? success.Value : throw new InvalidOperationException("Snapshot rejected");
    public void SetKnown(int value) => Observation.Observe(Soul, new(Material.Name, Material.Kind) { Target = Material, Tags = ImmutableDictionary<Tag,int?>.Empty.Add(new("neutral.signal"), value) });
    public FrozenConditionV1 AddDerivedClaim() {
        var fact = new Condition.Tagged(new Noun.Reference(Material), new("neutral.derived"), 1);
        Observation.Observe(Soul, new("neutral.derivation", ProjectionKind.Concept) { Existence = Truth.True, Rules = [new Rule(new Condition.Tagged(new Noun.Reference(Material), new("neutral.signal"), 1), RuleMode.Infer, new Effect.Think(fact), 1, Truth.True)] });
        return new FrozenConditionV1.Tagged(new FrozenNounV1.Reference(Material.SubjectId!.Value), new("neutral.derived"), 1);
    }
    public SubjectiveOfferV1 Offer(string id, SubjectiveActionKindV1 kind) => new(id,id,"source",kind) { Materials = [Material.SubjectId!.Value], Claims = [Claim] };
}
