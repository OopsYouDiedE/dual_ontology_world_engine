using System.Collections.Immutable;
using System.Security.Cryptography;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace DualOntologyWorldEngine.Core;

public enum DecisionOutcomeV1 { Attempted, Succeeded, Failed, NoProgress, Interrupted }
public sealed record DecisionExperienceKeyV1([property:JsonRequired] string Method, [property:JsonRequired] string Context = "");
public sealed record DecisionExperienceV1([property:JsonRequired] DecisionExperienceKeyV1 Key,
    [property:JsonRequired] int Attempts = 0, [property:JsonRequired] int Successes = 0,
    [property:JsonRequired] int Failures = 0, [property:JsonRequired] int NoProgress = 0, [property:JsonRequired] int Interruptions = 0);
public sealed record DecisionMemoryV1([property:JsonRequired] int Version, [property:JsonRequired] ImmutableArray<DecisionExperienceV1> Experiences);

/// <summary>One actor's observed input history. No world access, clock, geometry or UI semantics.</summary>
public sealed class SubjectiveDecisionMemory
{
    private readonly Dictionary<DecisionExperienceKeyV1, DecisionExperienceV1> _entries = [];
    public DecisionExperienceV1 Get(DecisionExperienceKeyV1 key) { Validate(key); return _entries.GetValueOrDefault(key) ?? new(key); }
    public DecisionExperienceV1 Record(DecisionExperienceKeyV1 key, DecisionOutcomeV1 outcome)
    {
        if (!Enum.IsDefined(outcome)) throw new ArgumentOutOfRangeException(nameof(outcome));
        var old = Get(key);
        int Next(int n) => Math.Min(n, 999999) + 1;
        var updated = outcome switch
        {
            DecisionOutcomeV1.Attempted => old with { Attempts = Next(old.Attempts) },
            DecisionOutcomeV1.Succeeded => old with { Successes = Next(old.Successes) },
            DecisionOutcomeV1.Failed => old with { Failures = Next(old.Failures) },
            DecisionOutcomeV1.NoProgress => old with { NoProgress = Next(old.NoProgress) },
            _ => old with { Interruptions = Next(old.Interruptions) }
        };
        if (!_entries.ContainsKey(key) && _entries.Count >= 20000) throw new InvalidOperationException("decision_memory_limit");
        _entries[key] = updated;
        return updated;
    }
    public DecisionMemoryV1 Capture() => new(1, [.._entries.Values.OrderBy(e => e.Key.Method, StringComparer.Ordinal).ThenBy(e => e.Key.Context, StringComparer.Ordinal)]);
    public static SubjectiveDecisionMemory Restore(DecisionMemoryV1 state)
    {
        if (state.Version != 1 || state.Experiences.IsDefault || state.Experiences.Length > 20000) throw new InvalidDataException("decision_memory_version_or_limit");
        var result = new SubjectiveDecisionMemory();
        foreach (var experience in state.Experiences)
        {
            Validate(experience);
            if (!result._entries.TryAdd(experience.Key, experience)) throw new InvalidDataException("decision_memory_entry");
        }
        return result;
    }
    public void ReconsiderAttempts(IEnumerable<DecisionExperienceKeyV1> keys)
    {
        // A new relevant observation permits another attempt; it does not erase
        // success, failure or interrupted execution. Hosts choose relevant contexts.
        foreach (var key in keys.ToArray())
            if (_entries.TryGetValue(key, out var old)) _entries[key] = old with { Attempts = 0 };
    }
    public byte[] Encode() => JsonSerializer.SerializeToUtf8Bytes(Capture());
    public static SubjectiveDecisionMemory Decode(byte[] bytes)
    {
        using var document = CognitionCodec.Parse(bytes);
        return Restore(document.RootElement.Deserialize<DecisionMemoryV1>(new JsonSerializerOptions { UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow })
            ?? throw new InvalidDataException("decision_memory_missing"));
    }
    private static void Validate(DecisionExperienceKeyV1 key)
    {
        if (key is null || string.IsNullOrWhiteSpace(key.Method) || key.Method.Length > 2048 || key.Context is null || key.Context.Length > 2048)
            throw new InvalidDataException("decision_experience_key");
    }
    internal static void Validate(DecisionExperienceV1 experience)
    {
        if (experience is null) throw new InvalidDataException("decision_memory_entry");
        Validate(experience.Key);
        if (new[] { experience.Attempts, experience.Successes, experience.Failures, experience.NoProgress, experience.Interruptions }.Any(n => n is < 0 or > 1000000))
            throw new InvalidDataException("decision_memory_entry");
    }
}

public sealed record DecisionScoreInputV1(int RuleScore, DecisionExperienceV1 Experience, int RevisitWeight = 1,
    int InformationValue = 0, int Cost = 0, bool NecessaryReturn = false, bool Forbidden = false, int? FailureWeight = null);
public sealed record DecisionScoreV1(int Score, bool Forbidden, ImmutableArray<string> Basis);

public static class SubjectiveDecision
{
    /// <summary>Compose subjective rule, expected information, effort and observed experience.</summary>
    public static DecisionScoreV1 Evaluate(DecisionScoreInputV1 input)
    {
        if (input.RevisitWeight is < 0 or > 1000000 || input.FailureWeight is < 0 or > 1000000 || input.Cost < 0) throw new ArgumentOutOfRangeException(nameof(input));
        SubjectiveDecisionMemory.Validate(input.Experience);
        var reasons = ImmutableArray.CreateBuilder<string>();
        long score = (long)input.RuleScore + input.InformationValue - input.Cost;
        var memory = input.Experience;
        if (memory.Attempts > 0 && input.RevisitWeight > 0)
        {
            score -= (long)Math.Min(memory.Attempts, input.NecessaryReturn ? 1 : 1000) * input.RevisitWeight;
            reasons.Add("revisit_without_new_accepted_material:" + memory.Attempts);
        }
        if (memory.Failures > 0 || memory.NoProgress > 0)
        {
            score -= (long)Math.Min((long)memory.Failures + memory.NoProgress, 1000) * Math.Max(1, input.FailureWeight ?? input.RevisitWeight) * 4;
            if (memory.Failures > 0) reasons.Add("observed_action_failed:" + memory.Failures);
            if (memory.NoProgress > 0) reasons.Add("observed_movement_stalled:" + memory.NoProgress);
        }
        if (input.InformationValue != 0) reasons.Add("expected_subjective_information");
        return new((int)Math.Clamp(score, -100000000L, 100000000L), input.Forbidden, reasons.ToImmutable());
    }
    public static int DirectionValue(double distance, double nearest, double farthest, int weight)
    {
        if (!double.IsFinite(distance) || !double.IsFinite(nearest) || !double.IsFinite(farthest) || weight < 0) throw new ArgumentOutOfRangeException(nameof(distance));
        // Scaling before subtraction keeps finite extreme inputs finite.
        var scale = Math.Max(1, Math.Max(Math.Abs(distance), Math.Max(Math.Abs(nearest), Math.Abs(farthest))));
        var ratio = (farthest / scale - distance / scale) / Math.Max(1 / scale, farthest / scale - nearest / scale);
        return (int)Math.Clamp(Math.Clamp(ratio, 0, 1) * weight * 2, 0, int.MaxValue);
    }
    public static bool ShouldReconsider(double currentScore, double proposedScore, bool interruptible)
        => interruptible && proposedScore > currentScore;
    public static int InformationValue(SubjectiveProofV1 proof, bool servesCurrentGoal, int weight)
    {
        if (weight is < 0 or > 1000000) throw new ArgumentOutOfRangeException(nameof(weight));
        return proof.Value == Truth.Unknown && !proof.Contradicted ? weight * (servesCurrentGoal ? 3 : 1) : 0;
    }
}

/// <summary>Live adapter for observed executions, stored in the actor's cognition and ordinary save graph.</summary>
public static class ActionLearning
{
    private static readonly Tag ExperienceTag = new("core.decision-experience.v1");
    private static readonly JsonSerializerOptions Json = new() { UnmappedMemberHandling = System.Text.Json.Serialization.JsonUnmappedMemberHandling.Disallow };
    private sealed class DecodedObservation
    {
        internal ObservationEvent? Observation;
        internal DecisionMemoryV1? State;
    }
    private static readonly ConditionalWeakTable<Projection, DecodedObservation> Decoded = new();
    private static DecisionMemoryV1 ReadNode(Projection node)
    {
        var observation = node.LastObservation ?? throw new InvalidDataException("decision_memory_missing");
        var cache = Decoded.GetOrCreateValue(node);
        if (!ReferenceEquals(cache.Observation, observation))
        {
            var parsed = SubjectiveDecisionMemory.Decode(Encoding.UTF8.GetBytes(observation.Details)).Capture();
            cache.State = parsed;
            cache.Observation = observation;
        }
        return cache.State!;
    }
    private static string Hash(string text) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
    private static Tag KeyTag(DecisionExperienceKeyV1 key) => new("core.decision-experience.key:" + Hash(JsonSerializer.Serialize(key)));
    private static string Method(ProjectionWorld world, Effect effect)
    {
        var frozen = CognitionAst.Freeze(effect, projection => world.Contains(projection)
            ? projection.SubjectId!.Value : throw new InvalidOperationException("action_learning_reference_domain"));
        return Hash(CognitionCodec.Write(frozen)!.ToJsonString());
    }
    /// <summary>Only the actor and referenced known objects affect retry context. Unrelated observations do not.</summary>
    public static string Context(ProjectionWorld world, Projection actor, Effect effect)
    {
        if (!world.Contains(actor)) throw new InvalidOperationException("action_learning_actor_domain");
        var refs = Ast.Nouns(effect).OfType<Noun.Reference>().Select(r => r.Projection).Append(actor).Distinct().ToArray();
        if (refs.Any(p => !world.Contains(p))) throw new InvalidOperationException("action_learning_reference_domain");
        // The actor's unrelated progress counters and preference tags are not
        // execution context. Only actor tags actually required by this method
        // or a normative permission condition can reopen the same action.
        var actorTags = new HashSet<Tag>();
        void CollectCondition(Condition condition)
        {
            switch (condition)
            {
                case Condition.Tagged tagged when new ActionContext(actor, Scene: actor.Parent).Resolve(tagged.Target) == actor: actorTags.Add(tagged.Tag); break;
                case Condition.Not negated: CollectCondition(negated.Operand); break;
                case Condition.All all: foreach (var part in all.Items) CollectCondition(part); break;
                case Condition.Any any: foreach (var part in any.Items) CollectCondition(part); break;
            }
        }
        void CollectEffect(Effect item)
        {
            switch (item)
            {
                case Effect.Require requirement: CollectCondition(requirement.Condition); break;
                case Effect.When conditional: CollectCondition(conditional.Condition); CollectEffect(conditional.Body); break;
                case Effect.Wait wait: if (wait.Until is { } until) CollectCondition(until); CollectEffect(wait.Body); break;
                case Effect.Sequence sequence: foreach (var part in sequence.Items) CollectEffect(part); break;
            }
        }
        CollectEffect(effect);
        foreach (var rule in world.Projections.SelectMany(p => p.Rules).Where(r => r.Mode is RuleMode.Forbid or RuleMode.Permit or RuleMode.Require))
            if (Ast.Equivalent(rule.Effect, effect)) CollectCondition(rule.Condition);
        return Hash(JsonSerializer.Serialize(refs.OrderBy(p => p.SubjectId!.Value.ToString(), StringComparer.Ordinal).Select(p => new {
            p.SubjectId, p.Existence, Parent = p.Parent?.SubjectId,
            Tags = p.Tags.Where(t => !ReferenceEquals(p, actor) || actorTags.Contains(t.Key))
                .OrderBy(t => t.Key.Name, StringComparer.Ordinal).Select(t => new { t.Key.Name, t.Value }),
            Relations = p.Relations.OrderBy(r => r.Relation.Name, StringComparer.Ordinal).ThenBy(r => r.Target.SubjectId!.Value.ToString(), StringComparer.Ordinal)
                .Select(r => new { r.Relation.Name, r.Target.SubjectId })
        })));
    }
    public static DecisionExperienceKeyV1 Key(ProjectionWorld world, Projection actor, Effect effect)
        => new(Method(world, effect), Context(world, actor, effect));
    private static SubjectiveDecisionMemory Read(ProjectionWorld world, Projection actor)
    {
        if (!world.Contains(actor)) throw new InvalidOperationException("action_learning_actor_domain");
        if (SubjectiveAgentStorage.HasState(world, actor)) return SubjectiveDecisionMemory.Restore(LoadState(world, actor).Memory);
        return ReadLegacy(world, actor);
    }
    private static SubjectiveDecisionMemory ReadLegacy(ProjectionWorld world, Projection actor)
    {
        var entries = world.Projections.Where(p => p.Tags.GetValueOrDefault(ExperienceTag) == 1 && p.Relations.Contains((Relations.Subject, actor)))
            .SelectMany(p => ReadNode(p).Experiences).ToImmutableArray();
        return SubjectiveDecisionMemory.Restore(new(1, entries));
    }
    public static DecisionMemoryV1 Capture(ProjectionWorld world, Projection actor)
    {
        lock (world.Gate) return Read(world, actor).Capture();
    }
    public static void Observe(SoulEssence soul, Projection actor, DecisionExperienceKeyV1 key, DecisionOutcomeV1 outcome, double time = 0,
        SubjectiveAgentState? state = null, string? receiptId = null, bool acquiredInformation = false, string informationIdentity = "")
    {
        lock (soul.World.Gate)
        {
            if (state is not null || receiptId is not null)
            {
                var agent = state ?? LoadState(soul.World, actor);
                if (agent.Actor != actor.SubjectId!.Value) throw new InvalidOperationException("subjective_agent_actor_domain");
                SubjectiveAgent.Feedback(agent, new(receiptId ?? Guid.NewGuid().ToString("D"), key.Method, key.Context, outcome, acquiredInformation, informationIdentity));
                SaveState(soul.World, actor, agent, time); return;
            }
            ObserveLocked(soul, actor, key, outcome, time);
        }
    }
    private static void ObserveLocked(SoulEssence soul, Projection actor, DecisionExperienceKeyV1 key, DecisionOutcomeV1 outcome, double time)
    {
        if (!soul.World.Contains(actor)) throw new InvalidOperationException("action_learning_actor_domain");
        if (SubjectiveAgentStorage.HasState(soul.World, actor))
        {
            var agent = LoadState(soul.World, actor);
            SubjectiveAgent.Feedback(agent, new(Guid.NewGuid().ToString("D"), key.Method, key.Context, outcome));
            SaveState(soul.World, actor, agent, time); return;
        }
        var marker = KeyTag(key);
        var nodes = soul.World.Projections.Where(p => p.Tags.GetValueOrDefault(ExperienceTag) == 1 && p.Relations.Contains((Relations.Subject, actor))).ToArray();
        var node = nodes.FirstOrDefault(p => p.Tags.GetValueOrDefault(marker) == 1);
        if (node is null && nodes.Length >= 20000) throw new InvalidOperationException("decision_memory_limit");
        var state = node is null ? new SubjectiveDecisionMemory() : SubjectiveDecisionMemory.Restore(ReadNode(node));
        state.Record(key, outcome);
        Observation.Observe(soul, new ObservationInput("core.decision-experience", ProjectionKind.Concept)
        {
            Target = node, Source = ObservationSource.Introspection, Existence = Truth.True, Time = time,
            Tags = ImmutableDictionary<Tag, int?>.Empty.Add(ExperienceTag, 1).Add(marker, 1), AddRelations = [(Relations.Subject, actor)],
            Details = JsonSerializer.Serialize(state.Capture(), Json)
        });
    }
    public static IReadOnlyList<DecisionAssessment> Assess(ProjectionWorld world, Projection actor, ReasoningBudgetV1? budget = null,
        SubjectiveAgentState? state = null, Func<DecisionAssessment, bool>? eligible = null, SubjectiveAgentMotivesV1? motives = null)
    {
        // Rule evaluation, retry context and learning must see one published version.
        lock (world.Gate)
        {
            var (view, raw, request, agent) = PrepareAgent(world, actor, budget, state, eligible, motives);
            var assessment = SubjectiveAgent.Assess(request, agent, view);
            return Map(raw, assessment);
        }
    }
    public static DecisionAssessment? Decide(ProjectionWorld world, Projection actor, ReasoningBudgetV1? budget = null,
        SubjectiveAgentState? state = null, Func<DecisionAssessment, bool>? eligible = null, SubjectiveAgentMotivesV1? motives = null)
    {
        lock (world.Gate)
        {
            var (view, raw, request, agent) = PrepareAgent(world, actor, budget, state, eligible, motives);
            var choice = SubjectiveAgent.Decide(request, agent, view);
            if (state is null) SaveState(world, actor, agent);
            return choice.OfferId is null ? null : Map(raw, choice.Assessment)
                .First(a => Method(world, a.Decision.Effect) == choice.OfferId);
        }
    }
    private static IReadOnlyList<DecisionAssessment> Map(IReadOnlyList<DecisionAssessment> raw, SubjectiveAgentAssessmentV1 assessment)
        => raw.Select((a, index) => {
            var scored = assessment.Offers[index];
            return a with { Decision = a.Decision with { Score = scored.Score }, Forbidden = scored.Forbidden, Reasons = scored.Basis };
        }).OrderBy(a => a.Forbidden).ThenByDescending(a => a.Decision.Score).ToArray();
    private static (SubjectRead.View View, IReadOnlyList<DecisionAssessment> Raw, SubjectiveAgentRequestV1 Request, SubjectiveAgentState State)
        PrepareAgent(ProjectionWorld world, Projection actor, ReasoningBudgetV1? budget, SubjectiveAgentState? state, Func<DecisionAssessment, bool>? eligible, SubjectiveAgentMotivesV1? motives)
    {
        using var timing = CorePerformance.Begin("core.prepare_agent");
        var view = SubjectRead.Capture(world);
        var raw = DecisionSystem.Assess(view, actor).Where(a => eligible?.Invoke(a) ?? true).ToArray();
        var agent = state ?? LoadState(world, actor);
        var offers = raw.Select(a => EffectOffer(world, actor, a)).ToImmutableArray();
        var weight = raw.Select(a => (int)Math.Clamp(Math.Abs((long)a.Decision.Score), 1, 1000000)).DefaultIfEmpty(1).Max();
        return (view, raw, new(view.Snapshot, actor.SubjectId!.Value, budget ?? new(), offers, motives ?? new(weight, 1, 1)) {
            CompleteMethodScopes = [..agent.KnownMethods.Where(o => o.ScopeId == "core.effects").Select(o => new SubjectiveMethodScopeV1(o.SourceId, o.ScopeId))
                .Concat(offers.Select(o => new SubjectiveMethodScopeV1(o.SourceId, o.ScopeId))).Distinct()]
        }, agent);
    }
    /// <summary>Pure conversion of an acquired actual effect. Hosts may supply
    /// their stable port/source identities; they cannot manufacture information
    /// gathering for an effect with no inspection operation.</summary>
    public static SubjectiveOfferV1 EffectOffer(ProjectionWorld world, Projection actor, DecisionAssessment assessment,
        string? id = null, string? sourceId = null, string scopeId = "core.effects")
    {
        lock (world.Gate)
        {
            var key = Key(world, actor, assessment.Decision.Effect);
            if (!world.Contains(assessment.Decision.Basis)) throw new InvalidOperationException("action_learning_basis_domain");
            var material = Ast.Nouns(assessment.Decision.Effect).OfType<Noun.Reference>().Select(r => r.Projection)
                .Where(p => !ReferenceEquals(p, actor)).Distinct().Select(p => p.SubjectId!.Value).ToImmutableArray();
            return new(id ?? key.Method, key.Method, sourceId ?? assessment.Decision.Basis.SubjectId!.Value.ToString(), ActionKind(assessment.Decision.Effect)) {
                Context = key.Context, InformationContext = key.Context, ScopeId = scopeId, Materials = material,
                RuleScore = assessment.Decision.Score, Forbidden = assessment.Forbidden,
                Claims = assessment.Decision.Effect is Effect.Say { Claim: { } claim }
                    ? [CognitionAst.Freeze(claim, p => p.SubjectId!.Value)] : [],
                AcquiresInformation = HasInspection(assessment.Decision.Effect), RuleBasis = [..assessment.Reasons]
            };
        }
    }
    private static SubjectiveActionKindV1 ActionKind(Effect effect) => effect switch {
        Effect.Act { Operation: ActionOp.Inspect } => SubjectiveActionKindV1.Observe,
        Effect.Act { Operation: ActionOp.Travel } => SubjectiveActionKindV1.Travel,
        Effect.Act { Operation: ActionOp.Destroy } => SubjectiveActionKindV1.Destroy,
        Effect.Say => SubjectiveActionKindV1.Assert,
        Effect.Wait wait => ActionKind(wait.Body),
        Effect.When conditional => ActionKind(conditional.Body),
        Effect.Sequence sequence => sequence.Items.Select(ActionKind).FirstOrDefault(k => k != SubjectiveActionKindV1.Test, SubjectiveActionKindV1.Test),
        _ => SubjectiveActionKindV1.Test
    };
    public static SubjectiveAgentState LoadState(ProjectionWorld world, Projection actor)
    {
        lock (world.Gate)
        {
            if (!world.Contains(actor)) throw new InvalidOperationException("action_learning_actor_domain");
            var result = SubjectiveAgentStorage.Load(world, actor, ReadLegacy(world, actor).Capture());
            if (result.Actor != actor.SubjectId!.Value) throw new InvalidDataException("subjective_agent_actor_domain");
            return result;
        }
    }
    public static void SaveState(ProjectionWorld world, Projection actor, SubjectiveAgentState state, double time = 0)
    {
        lock (world.Gate)
        {
            if (!world.Contains(actor) || state.Actor != actor.SubjectId!.Value) throw new InvalidOperationException("subjective_agent_actor_domain");
            SubjectiveAgentStorage.Save(world, actor, state, time);
        }
    }
    private static bool HasInspection(Effect effect) => effect switch {
        Effect.Act { Operation: ActionOp.Inspect } => true,
        Effect.Sequence sequence => sequence.Items.Any(HasInspection),
        Effect.Wait wait => HasInspection(wait.Body),
        Effect.When conditional => HasInspection(conditional.Body),
        _ => false
    };
}
