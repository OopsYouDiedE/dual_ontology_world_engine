using System.Collections.Immutable;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace DualOntologyWorldEngine.Core;

/// <summary>Persistent keyed fragments; unchanged entries never become new observations.</summary>
internal static class SubjectiveAgentStorage
{
    private static readonly Tag FragmentTag = new("core.subjective-agent.fragment.v1");
    private static readonly Tag LegacyTag = new("core.subjective-agent.v1");
    private const int ReceiptChunkSize = 32;
    private static readonly JsonSerializerOptions NodeJson = new() { MaxDepth = 1024 };
    private static readonly JsonDocumentOptions NodeDocument = new() { MaxDepth = 1024 };
    private static readonly string[] Collections = ["KnownMethods", "Information", "Deferred", "EditedGroups", "AcquiredSinceAssessment", "InformationReceipts", "Receipts"];
    private sealed record Fragment(Projection? Node, string Kind, string Key, int Order, JsonNode Payload, string Details);
    private static string Marker(string kind, string key) => "core.subjective-agent.fragment.key:" +
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(new JsonArray(kind, key).ToJsonString())));
    private static IEnumerable<Projection> Nodes(ProjectionWorld world, Projection actor, Tag tag)
        => world.Projections.Where(p => p.Tags.GetValueOrDefault(tag) == 1 && p.Relations.Contains((Relations.Subject, actor)));
    internal static bool HasState(ProjectionWorld world, Projection actor)
    {
        lock (world.Gate) return Nodes(world, actor, FragmentTag).Any() || Nodes(world, actor, LegacyTag).Any(p => p.Existence == Truth.True);
    }
    private static InvalidDataException Invalid() => new("subjective_agent_fragment_invalid");
    private static Fragment Read(Projection node, Projection actor)
    {
        if (node.Existence is not (Truth.True or Truth.False)) throw Invalid();
        var details = node.LastObservation?.Details ?? throw Invalid();
        using var parsed = CognitionCodec.Parse(Encoding.UTF8.GetBytes(details));
        var wrapper = JsonNode.Parse(parsed.RootElement.GetRawText(), documentOptions: NodeDocument) as JsonObject ?? throw Invalid();
        if (wrapper.Count != 7 || !new[] { "Format", "Version", "Actor", "Kind", "Key", "Order", "Payload" }.All(wrapper.ContainsKey)
            || wrapper["Format"]?.GetValue<string>() != "subjective-agent-fragment" || wrapper["Version"]?.GetValue<int>() != 1
            || !JsonNode.DeepEquals(wrapper["Actor"], JsonNode.Parse(System.Text.Json.JsonSerializer.Serialize(actor.SubjectId!.Value)))) throw Invalid();
        var kind = wrapper["Kind"]?.GetValue<string>() ?? throw Invalid();
        var key = wrapper["Key"]?.GetValue<string>() ?? throw Invalid();
        var order = wrapper["Order"]?.GetValue<int>() ?? throw Invalid();
        var orderedKind = kind.StartsWith("Order.", StringComparison.Ordinal) ? kind[6..] : "";
        if (order < 0 || order > 20000 || kind is not ("Meta" or "Memory") && !Collections.Contains(kind)
                && orderedKind != "Memory" && !Collections.Where(k => k != "Receipts").Contains(orderedKind)
            || node.Tags.GetValueOrDefault(new Tag(Marker(kind, key))) != 1) throw Invalid();
        return new(node, kind, key, order, wrapper["Payload"]?.DeepClone() ?? throw Invalid(), details);
    }
    private static Dictionary<(string Kind, string Key), Fragment> ReadAll(ProjectionWorld world, Projection actor)
    {
        using var timing = CorePerformance.Begin("core.agent_storage_read_fragments");
        var result = new Dictionary<(string, string), Fragment>();
        foreach (var node in Nodes(world, actor, FragmentTag))
        {
            var fragment = Read(node, actor);
            if (!result.TryAdd((fragment.Kind, fragment.Key), fragment)) throw Invalid();
        }
        return result;
    }
    private static string Key(string kind, JsonNode payload) => kind switch
    {
        "Memory" => new JsonArray(payload["Key"]?["Method"]?.GetValue<string>(), payload["Key"]?["Context"]?.GetValue<string>()).ToJsonString(),
        "KnownMethods" => new JsonArray(payload["MethodId"]?.GetValue<string>(), payload["Context"]?.GetValue<string>()).ToJsonString(),
        "Information" or "Deferred" => payload["MethodId"]?.GetValue<string>() ?? throw Invalid(),
        "EditedGroups" or "AcquiredSinceAssessment" or "InformationReceipts" => payload.GetValue<string>(),
        _ => throw Invalid()
    };
    private static JsonArray Ordered(Fragment[] all, string kind, int count)
    {
        var entries = all.Where(f => f.Kind == kind).ToDictionary(f => f.Key, StringComparer.Ordinal);
        var orders = all.Where(f => f.Kind == "Order." + kind).ToArray();
        if (entries.Count != count || orders.Length != count || orders.Any(f => f.Order != 0 || !entries.ContainsKey(f.Key))) throw Invalid();
        var ordered = orders.Select(f => (Fragment: entries[f.Key], Position: f.Payload.GetValue<int>())).OrderBy(p => p.Position).ToArray();
        if (!ordered.Select(p => p.Position).SequenceEqual(Enumerable.Range(0, count)) || entries.Values.Any(f => f.Order != 0)) throw Invalid();
        return new JsonArray(ordered.Select(p => p.Fragment.Payload.DeepClone()).ToArray());
    }
    internal static SubjectiveAgentState Load(ProjectionWorld world, Projection actor, DecisionMemoryV1 legacyMemory)
    {
        using var timing = CorePerformance.Begin("core.agent_storage_load");
        lock (world.Gate)
        {
            if (!world.Contains(actor)) throw new InvalidOperationException("subjective_agent_actor_domain");
            var fragments = ReadAll(world, actor);
            var all = fragments.Values.Where(f => f.Node!.Existence == Truth.True).ToArray();
            SubjectiveAgentState result;
            if (all.Length == 0)
            {
                if (fragments.Count > 0) throw Invalid();
                var legacy = Nodes(world, actor, LegacyTag).Where(p => p.Existence == Truth.True).ToArray();
                if (legacy.Length > 1) throw Invalid();
                result = legacy.Length == 0 ? new(actor.SubjectId!.Value) : SubjectiveAgentState.Decode(Encoding.UTF8.GetBytes(legacy[0].LastObservation?.Details ?? throw Invalid()));
            }
            else
            {
                var metas = all.Where(f => f.Kind == "Meta").ToArray();
                if (metas.Length != 1 || metas[0].Key != "state" || metas[0].Order != 0) throw Invalid();
                var meta = metas[0].Payload as JsonObject ?? throw Invalid();
                if (meta.Count != 3 || !new[] { "Root", "Counts", "MemoryVersion" }.All(meta.ContainsKey)) throw Invalid();
                var root = meta["Root"]?.DeepClone() as JsonObject ?? throw Invalid();
                if (root.Count != 7 || !new[] { "Version", "Actor", "TieState", "Statement", "StatementMethodId", "Evidence", "RequiresEvidence" }.All(root.ContainsKey)) throw Invalid();
                var counts = meta["Counts"] as JsonObject ?? throw Invalid();
                if (counts.Count != Collections.Length + 1 || !Collections.Append("Memory").All(counts.ContainsKey)) throw Invalid();
                int Count(string kind) { var n = counts[kind]?.GetValue<int>() ?? throw Invalid(); if (n is < 0 or > 20000) throw Invalid(); return n; }
                root["Memory"] = new JsonObject { ["Version"] = meta["MemoryVersion"]!.DeepClone(), ["Experiences"] = Ordered(all, "Memory", Count("Memory")) };
                foreach (var kind in Collections.Where(k => k != "Receipts")) root[kind] = Ordered(all, kind, Count(kind));
                var receiptCount = Count("Receipts");
                var chunks = all.Where(f => f.Kind == "Receipts").OrderBy(f => f.Order).ToArray();
                if (chunks.Length != (receiptCount + ReceiptChunkSize - 1) / ReceiptChunkSize) throw Invalid();
                var receipts = new JsonArray();
                for (var i = 0; i < chunks.Length; i++)
                {
                    var chunk = chunks[i]; var values = chunk.Payload as JsonArray ?? throw Invalid();
                    if (chunk.Order != i || chunk.Key != i.ToString(System.Globalization.CultureInfo.InvariantCulture)
                        || values.Count != Math.Min(ReceiptChunkSize, receiptCount - i * ReceiptChunkSize)) throw Invalid();
                    foreach (var value in values) receipts.Add(value?.DeepClone() ?? throw Invalid());
                }
                root["Receipts"] = receipts;
                foreach (var fragment in all.Where(f => f.Kind is not ("Meta" or "Receipts") && !f.Kind.StartsWith("Order.", StringComparison.Ordinal)))
                    if (fragment.Key != Key(fragment.Kind, fragment.Payload)) throw Invalid();
                result = SubjectiveAgentState.Decode(Encoding.UTF8.GetBytes(root.ToJsonString(NodeJson)));
            }
            if (result.Actor != actor.SubjectId!.Value) throw Invalid();
            // Upgraded keyed entries replace legacy entries, without counting an old experience twice.
            var merged = legacyMemory.Experiences.ToDictionary(e => e.Key);
            foreach (var entry in result.Memory.Experiences) merged[entry.Key] = entry;
            result.Memory = SubjectiveDecisionMemory.Restore(new(1, [..merged.Values])).Capture();
            _ = result.Encode();
            return result;
        }
    }
    internal static void Save(ProjectionWorld world, Projection actor, SubjectiveAgentState state, double time)
    {
        using var timing = CorePerformance.Begin("core.agent_storage_save");
        lock (world.Gate)
        {
            if (!world.Contains(actor) || state.Actor != actor.SubjectId!.Value) throw new InvalidOperationException("subjective_agent_actor_domain");
            JsonObject root;
            using (CorePerformance.Begin("core.agent_storage_encode"))
                root = JsonNode.Parse(state.Encode(), documentOptions: NodeDocument) as JsonObject ?? throw Invalid();
            var existing = ReadAll(world, actor);
            var oldReceipts = existing.Values.Where(f => f.Kind == "Receipts" && f.Node!.Existence == Truth.True)
                .OrderBy(f => f.Order).SelectMany(f => f.Payload as JsonArray ?? throw Invalid()).ToArray();
            var newReceipts = root["Receipts"] as JsonArray ?? throw Invalid();
            var informationReceipts = root["InformationReceipts"] as JsonArray ?? throw Invalid();
            var retainedInformation = informationReceipts.Select(value => value?.GetValue<string>() ?? throw Invalid()).ToHashSet(StringComparer.Ordinal);
            if (existing.Values.Any(f => f.Kind == "InformationReceipts" && f.Node!.Existence == Truth.True
                && !retainedInformation.Contains(f.Payload.GetValue<string>())))
                throw new InvalidOperationException("subjective_agent_information_receipts_rewritten");
            if (newReceipts.Count < oldReceipts.Length || oldReceipts.Where((value, i) => !JsonNode.DeepEquals(value, newReceipts[i])).Any())
                throw new InvalidOperationException("subjective_agent_receipt_rewrite");
            var wanted = new Dictionary<(string Kind, string Key), Fragment>();
            void Add(string kind, string key, int order, JsonNode payload)
            {
                var wrapper = new JsonObject { ["Format"] = "subjective-agent-fragment", ["Version"] = 1,
                    ["Actor"] = root["Actor"]!.DeepClone(), ["Kind"] = kind, ["Key"] = key, ["Order"] = order, ["Payload"] = payload.DeepClone() };
                if (!wanted.TryAdd((kind, key), new(null, kind, key, order, payload.DeepClone(), wrapper.ToJsonString(NodeJson)))) throw Invalid();
            }
            void AddEntry(string kind, JsonNode payload, int position)
            {
                var key = Key(kind, payload);
                Add(kind, key, 0, payload);
                Add("Order." + kind, key, 0, JsonValue.Create(position)!);
            }
            var counts = new JsonObject();
            var memory = root["Memory"] as JsonObject ?? throw Invalid();
            var experiences = memory["Experiences"] as JsonArray ?? throw Invalid();
            counts["Memory"] = experiences.Count;
            for (var i = 0; i < experiences.Count; i++) AddEntry("Memory", experiences[i]!, i);
            foreach (var kind in Collections)
            {
                var values = root[kind] as JsonArray ?? throw Invalid(); counts[kind] = values.Count;
                if (kind == "Receipts")
                    for (var i = 0; i * ReceiptChunkSize < values.Count; i++)
                        Add(kind, i.ToString(System.Globalization.CultureInfo.InvariantCulture), i,
                            new JsonArray(values.Skip(i * ReceiptChunkSize).Take(ReceiptChunkSize).Select(v => v!.DeepClone()).ToArray()));
                else for (var i = 0; i < values.Count; i++) AddEntry(kind, values[i]!, i);
            }
            var scalar = root.DeepClone() as JsonObject ?? throw Invalid();
            scalar.Remove("Memory"); foreach (var kind in Collections) scalar.Remove(kind);
            Add("Meta", "state", 0, new JsonObject { ["Root"] = scalar, ["Counts"] = counts, ["MemoryVersion"] = memory["Version"]!.DeepClone() });
            var changes = new List<ObservationInput>();
            foreach (var entry in wanted.Values)
            {
                existing.TryGetValue((entry.Kind, entry.Key), out var previous);
                if (previous?.Node?.Existence == Truth.True && previous.Details == entry.Details) continue;
                changes.Add(new("core.subjective-agent.fragment", ProjectionKind.Concept) { Target = previous?.Node,
                    Source = ObservationSource.Introspection, Time = time, Existence = Truth.True,
                    Tags = ImmutableDictionary<Tag, int?>.Empty.Add(FragmentTag, 1).Add(new(Marker(entry.Kind, entry.Key)), 1),
                    AddRelations = [(Relations.Subject, actor)], Details = entry.Details });
            }
            foreach (var entry in existing.Values.Where(f => f.Node!.Existence == Truth.True && !wanted.ContainsKey((f.Kind, f.Key))))
                changes.Add(new(entry.Node!.Name, entry.Node.Kind) { Target = entry.Node, Source = ObservationSource.Introspection, Time = time, Existence = Truth.False, Details = entry.Details });
            foreach (var legacy in Nodes(world, actor, LegacyTag).Where(p => p.Existence == Truth.True))
                changes.Add(new(legacy.Name, legacy.Kind) { Target = legacy, Source = ObservationSource.Introspection, Time = time, Existence = Truth.False });
            if (changes.Count > 0)
                using (CorePerformance.Begin("core.agent_storage_publish")) Observation.ApplyBatch(world, changes);
        }
    }
}
