using DualOntologyWorldEngine.Story;

// Fixture input begins only after the public decision is returned. Its next
// observation supplies the completion result; selection itself stays unexecuted.
internal static class NeutralExecutionLifecycle
{
    public static PlayerDecision ExecuteDecision(this SubjectivePlayerController controller,
        PublicPlayerObservation observation, PlayerCognition cognition)
    {
        var decision = controller.Decide(observation, cognition);
        if (decision.Token is { } token) controller.StartExecution(token);
        return decision;
    }
}
