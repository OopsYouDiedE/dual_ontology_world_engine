# 复用既有现场操作和对白。步骤是真实执行合同；结果行只在完成后交付。
主体命题锚定
    {"boots_fit":"detective","lens_mine":"detective","me":"detective","recalled_bolt":"detective","recalled_trust":"detective","hand_not_mine":"detective","recalled_copper":"huo","recalled_names":"shen","recalled_su_voice":"su","recalled_su_open":"su"}

主体操作
    [
        {
            "id": "test:E1",
            "source": "E1",
            "kind": "test",
            "label": "拔闩推门",
            "mode": "touch_sequence",
            "participant": "self",
            "requires_all": [
                "E1"
            ],
            "steps": [
                {
                    "op": "set",
                    "target": "E1",
                    "tag": "内闩",
                    "value": 0
                },
                {
                    "op": "inspect",
                    "target": "E1"
                },
                {
                    "op": "set",
                    "target": "E1",
                    "tag": "内闩",
                    "value": 1
                }
            ],
            "outcome_lines": [
                "exp_E1.002"
            ],
            "open_outcome_lines": [
                "exp_E1.open.001"
            ],
            "boundary": true
        },
        {
            "id": "test:E2",
            "source": "E2",
            "kind": "test",
            "label": "把木楔塞回门缝试试",
            "mode": "compare",
            "participant": "self",
            "requires_all": [
                "E2"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E2"
                },
                {
                    "op": "compare",
                    "target": "E2"
                }
            ],
            "outcome_lines": [
                "exp_E2.002"
            ]
        },
        {
            "id": "test:E3:detective",
            "source": "E3",
            "kind": "test",
            "label": "比对鞋底",
            "mode": "compare",
            "participant": "detective",
            "match": true,
            "requires_all": [
                "E3"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E3"
                },
                {
                    "op": "compare",
                    "target": "self"
                }
            ],
            "outcome_lines": [
                "exp_E3.002"
            ],
            "requires_consent": true,
            "self_first": true
        },
        {
            "id": "test:E3:huo",
            "source": "E3",
            "kind": "test",
            "label": "比对鞋底",
            "mode": "compare",
            "participant": "huo",
            "match": false,
            "requires_all": [
                "E3"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E3"
                },
                {
                    "op": "compare",
                    "target": "self"
                }
            ],
            "outcome_lines": [
                "sole_huo.002"
            ],
            "requires_consent": true,
            "self_first": true
        },
        {
            "id": "test:E3:shen",
            "source": "E3",
            "kind": "test",
            "label": "比对鞋底",
            "mode": "compare",
            "participant": "shen",
            "match": false,
            "requires_all": [
                "E3"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E3"
                },
                {
                    "op": "compare",
                    "target": "self"
                }
            ],
            "outcome_lines": [
                "sole_shen.002"
            ],
            "requires_consent": true,
            "self_first": true
        },
        {
            "id": "test:E3:su",
            "source": "E3",
            "kind": "test",
            "label": "比对鞋底",
            "mode": "compare",
            "participant": "su",
            "match": false,
            "requires_all": [
                "E3"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E3"
                },
                {
                    "op": "compare",
                    "target": "self"
                }
            ],
            "outcome_lines": [
                "sole_su.002"
            ],
            "requires_consent": true,
            "self_first": true
        },
        {
            "id": "test:E11:detective",
            "source": "E11",
            "kind": "test",
            "label": "比对手掌",
            "mode": "compare",
            "participant": "detective",
            "requires_consent": true,
            "self_first": true,
            "requires_all": [
                "E11"
            ],
            "group_required": [
                "detective",
                "huo",
                "shen",
                "su"
            ],
            "match": false,
            "steps": [
                {
                    "op": "compare",
                    "target": "detective"
                }
            ],
            "outcome_lines": [
                "help_E11_detective.002"
            ]
        },
        {
            "id": "test:E11:huo",
            "source": "E11",
            "kind": "test",
            "label": "比对手掌",
            "mode": "compare",
            "participant": "huo",
            "requires_consent": true,
            "self_first": true,
            "requires_all": [
                "E11"
            ],
            "group_required": [
                "detective",
                "huo",
                "shen",
                "su"
            ],
            "match": false,
            "steps": [
                {
                    "op": "compare",
                    "target": "huo"
                }
            ],
            "outcome_lines": [
                "help_E11_huo.002"
            ]
        },
        {
            "id": "test:E11:shen",
            "source": "E11",
            "kind": "test",
            "label": "比对手掌",
            "mode": "compare",
            "participant": "shen",
            "requires_consent": true,
            "self_first": true,
            "requires_all": [
                "E11"
            ],
            "group_required": [
                "detective",
                "huo",
                "shen",
                "su"
            ],
            "match": false,
            "steps": [
                {
                    "op": "compare",
                    "target": "shen"
                }
            ],
            "outcome_lines": [
                "help_E11_shen.002"
            ]
        },
        {
            "id": "test:E11:su",
            "source": "E11",
            "kind": "test",
            "label": "比对手掌",
            "mode": "compare",
            "participant": "su",
            "requires_consent": true,
            "self_first": true,
            "requires_all": [
                "E11"
            ],
            "group_required": [
                "detective",
                "huo",
                "shen",
                "su"
            ],
            "match": false,
            "steps": [
                {
                    "op": "compare",
                    "target": "su"
                }
            ],
            "outcome_lines": [
                "help_E11_su.002"
            ]
        },
        {
            "id": "help:E4",
            "source": "E4",
            "kind": "help",
            "label": "请人看看",
            "mode": "help",
            "participant": "shen",
            "requires_consent": true,
            "requires_all": [
                "E4"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E4"
                },
                {
                    "op": "utter",
                    "target": "shen"
                }
            ],
            "outcome_lines": [
                "help_E4.002",
                "help_E4.003",
                "help_E4.004"
            ]
        },
        {
            "id": "help:E5",
            "source": "E5",
            "kind": "help",
            "label": "请人看看",
            "mode": "help",
            "participant": "su",
            "requires_consent": true,
            "requires_all": [
                "E5"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E5"
                },
                {
                    "op": "compare",
                    "target": "E5"
                },
                {
                    "op": "utter",
                    "target": "su"
                }
            ],
            "outcome_lines": [
                "help_E5.004",
                "help_E5.005"
            ]
        },
        {
            "id": "help:E6",
            "source": "E6",
            "kind": "help",
            "label": "请人看看",
            "mode": "help",
            "participant": "su",
            "requires_consent": true,
            "requires_all": [
                "E6"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E6"
                },
                {
                    "op": "utter",
                    "target": "su"
                }
            ],
            "outcome_lines": [
                "help_E6.001",
                "help_E6.002",
                "help_E6.003",
                "help_E6.004"
            ]
        },
        {
            "id": "help:E7",
            "source": "E7",
            "kind": "help",
            "label": "请人看看",
            "mode": "help",
            "participant": "huo",
            "requires_consent": true,
            "requires_all": [
                "E7"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E7"
                },
                {
                    "op": "utter",
                    "target": "huo"
                }
            ],
            "outcome_lines": [
                "help_E7.001",
                "help_E7.002",
                "help_E7.003",
                "help_E7.004",
                "help_E7.005",
                "help_E7.006"
            ]
        },
        {
            "id": "help:E9",
            "source": "E9",
            "kind": "help",
            "label": "请人看看",
            "mode": "help",
            "participant": "shen",
            "requires_consent": true,
            "requires_all": [
                "E9"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E9"
                },
                {
                    "op": "utter",
                    "target": "shen"
                }
            ],
            "outcome_lines": [
                "help_E9.002",
                "help_E9.003",
                "help_E9.004"
            ]
        },
        {
            "id": "help:E10",
            "source": "E10",
            "kind": "help",
            "label": "请人看看",
            "mode": "help",
            "participant": "shen",
            "requires_consent": true,
            "requires_all": [
                "E10"
            ],
            "steps": [
                {
                    "op": "inspect",
                    "target": "E10"
                },
                {
                    "op": "utter",
                    "target": "shen"
                }
            ],
            "outcome_lines": [
                "help_E10.002",
                "help_E10.003",
                "help_E10.004"
            ]
        },
        {
            "id": "recall:E1",
            "source": "E1",
            "kind": "recall",
            "label": "回想",
            "mode": "recall",
            "actors": [
                "detective"
            ],
            "participant": "self",
            "requires_all": [
                "E1"
            ],
            "memory_propositions": [
                "recalled_bolt",
                "recalled_trust"
            ],
            "reliability": 85,
            "steps": [
                {
                    "op": "recall",
                    "target": "E1"
                }
            ],
            "outcome_lines": [
                "recall_detective.002"
            ]
        },
        {
            "id": "test:E8",
            "source": "E8",
            "kind": "test",
            "label": "声路试验",
            "mode": "sound",
            "participant": "self",
            "requires_all": [
                "E8"
            ],
            "contrary_propositions": [
                [
                    "slate_marks",
                    "score_partial"
                ],
                [
                    "slate_marks",
                    "frame_hollow",
                    "recalled_su_voice"
                ]
            ],
            "sentence_propositions": {
                "0": [
                    "slate_code"
                ],
                "1": [
                    "recalled_su_voice"
                ],
                "2": [
                    "recalled_copper"
                ]
            },
            "steps": [
                {
                    "op": "sound",
                    "target": "E8"
                }
            ],
            "outcome_lines": [
                "sound_test.003"
            ],
            "participant_outcome_lines": {
                "detective": "sound_test.003",
                "huo": "sound_test.004",
                "shen": "sound_test.005",
                "su": "sound_test.006"
            },
            "heard_propositions": [
                "sound_trial"
            ],
            "heard_requires": [
                "full",
                "tail"
            ],
            "hearing_rule": {
                "proposition": "heads_lost",
                "requires_known_sentence": true,
                "heard": "tail"
            }
        },
        {
            "id": "recall:E5",
            "source": "E5",
            "kind": "recall",
            "label": "回想",
            "mode": "recall",
            "actors": [
                "su"
            ],
            "participant": "self",
            "requires_all": [
                "E5"
            ],
            "memory_propositions": [
                "recalled_su_voice",
                "recalled_su_open"
            ],
            "reliability": 85,
            "steps": [
                {
                    "op": "recall",
                    "target": "E5"
                }
            ],
            "outcome_lines": [
                "recall_su.002",
                "recall_su.003"
            ]
        },
        {
            "id": "recall:E7",
            "source": "E7",
            "kind": "recall",
            "label": "回想",
            "mode": "recall",
            "actors": [
                "huo"
            ],
            "participant": "self",
            "requires_all": [
                "E7"
            ],
            "memory_propositions": [
                "recalled_copper"
            ],
            "reliability": 85,
            "steps": [
                {
                    "op": "recall",
                    "target": "E7"
                }
            ],
            "outcome_lines": [
                "recall_huo.003"
            ]
        },
        {
            "id": "recall:E10",
            "source": "E10",
            "kind": "recall",
            "label": "回想",
            "mode": "recall",
            "actors": [
                "shen"
            ],
            "participant": "self",
            "requires_all": [
                "E10"
            ],
            "memory_propositions": [
                "recalled_names"
            ],
            "reliability": 85,
            "steps": [
                {
                    "op": "recall",
                    "target": "E10"
                }
            ],
            "outcome_lines": [
                "recall_shen.003"
            ]
        }
    ]
