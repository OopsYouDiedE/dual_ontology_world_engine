extends Node
## AI 坐上玩家席位：只读这名角色本人看得到的候选与本人认知，由引擎按其 .story
## 操控规则选出动作，再经正式界面与现场把动作做出来。宿主不替角色挑选、不注入状态、
## 不快进时钟；任何角色都可以用同一套席位。
signal stopped(reason: String, summary: Dictionary)
signal recorded(kind: String, value: Variant)

const PilotNavigation := preload("res://scenes/Host/PilotNavigation.gd")
const ManuscriptPanel := preload("res://scenes/UI/Panels/Manuscript/ReplayManuscript.tscn")
const MOVE_KEYS := {"W": KEY_W, "A": KEY_A, "S": KEY_S, "D": KEY_D}
const TICK := 0.1
const KEY_MOVE_SECONDS := 0.35

## 每句台词停留的秒数；也是菜单等选项落下前的停顿。
var line_seconds := 0.6
var before_action := Callable()
var host: Node
var engine: Node
var stopping := false
var _run_label := ""
var _acting := false
var performance_phase := "idle"
var _reply_token := ""
var _reply: Dictionary = {}
var _pressed: Array[int] = []
var _last_decision: Dictionary = {}
var _decision_turn := 0
var _interaction_token := ""
var _interaction_site := ""
var _interaction_map := ""
var _last_gate := "-"
var _spaces: Dictionary = {}
var _places: Dictionary = {}
var _routes: Dictionary = {}
var _source_ids: Dictionary = {}

func _source_id(identity: String) -> String:
	if not _source_ids.has(identity): _source_ids[identity] = "observed:" + identity.sha256_text()
	return str(_source_ids[identity])

func attach(main: Node) -> void:
	host = main
	engine = main.engine
	var shared_panel := ManuscriptPanel.instantiate()
	_run_label = shared_panel.get_node("LeftPage/Scroll/Column/Actions/RunPlayback").text
	shared_panel.free()

func start() -> void:
	_loop()

func last_decision() -> Dictionary:
	return _last_decision

# ------------------------------------------------------------------ loop ---

func _loop() -> void:
	while not stopping:
		await get_tree().create_timer(TICK).timeout
		if stopping or not is_instance_valid(host): return
		var gate := _gate()
		if gate != _last_gate:
			_last_gate = gate
			recorded.emit("seat_wait", {"gate": gate})
		if gate != "":
			performance_phase = gate
			continue
		performance_phase = "observe"
		var observation_began := Time.get_ticks_usec()
		var observation: Dictionary = _observe()
		recorded.emit("timing", {"stage": "observe", "ms": (Time.get_ticks_usec() - observation_began) / 1000.0})
		if stopping: return
		if bool(observation.get("Complete", false)):
			stop("story_complete")
			return
		if observation.get("Candidates", []).is_empty():
			# Stage walks, fades and timed scenes still owe real acknowledgements; only an idle,
			# controllable field without any candidate is a gap in what the seat can do.
			if _field_idle():
				stop("candidate_missing")
				return
			continue
		performance_phase = "decision"
		var decision: Dictionary = JSON.parse_string(engine.AgentDecideJson())
		decision["GameTime"] = JSON.parse_string(engine.AgentTimeJson())
		_last_decision = decision
		_decision_turn = int(observation.get("Turn", 0))
		recorded.emit("decision", decision)
		if decision.get("Token") == null:
			stop(str(decision.get("Reason", "agent_cannot_assess")))
			return
		_acting = true
		performance_phase = "capture"
		if before_action.is_valid(): await before_action.call(observation, decision)
		if stopping: return
		performance_phase = "action"
		await _act(str(decision.Token))
		performance_phase = "idle"
		_acting = false

## 席位此刻为什么还不能决定（空串表示可以）；记入轨迹，卡住时据此查原因。
func _gate() -> String:
	if _acting: return "acting"
	if not _pressed.is_empty(): return "keys_held"
	if not host.settled(): return "host_draining"
	if not engine.AgentEnabled(): return "seat_not_bound"
	return ""

func _observe() -> Dictionary:
	var field: Node = host.field
	var ui: Node = host.ui
	if is_instance_valid(field) and field.player != null:
		# Opaque coordinate-frame identity; source map IDs remain in the host.
		var map_key: String = field.adapter.map_key()
		if not _spaces.has(map_key): _spaces[map_key] = "space:%d" % (_spaces.size() + 1)
		var located: String = engine.AgentLocatePublicRegion(_spaces[map_key], field.player.position.x, field.player.position.y, str(field.adapter.entered_room(field.player.position)))
		if located != "":
			stop(located)
			return {}
	var panel := _open_panel()
	if panel != "":
		var code: String = engine.AgentObservePanel(panel, _run_label)
		if code != "": stop(code)
	elif _field_idle():
		_finish_interaction(false)
		var code: String = engine.AgentObserveField(_field_offers(field, ui.snapshot))
		if code != "": stop(code)
	var observation: Dictionary = JSON.parse_string(engine.AgentObservationJson())
	if is_instance_valid(field) and field.player != null:
		observation["Position"] = [field.player.position.x, field.player.position.y]
	recorded.emit("observation", observation)
	return observation

func _open_panel() -> String:
	var ui: Node = host.ui
	if not is_instance_valid(ui): return ""
	match str(ui.modal_kind):
		"notebook": return "notebook"
		"replay": return "manuscript"
		"map": return "campus"
	return ""

func _field_idle() -> bool:
	var field: Node = host.field
	return is_instance_valid(field) and is_instance_valid(host.ui) and not host.ui.is_busy() and field.field_active() \
		and field.player_controlled() and field.click_path.is_empty() and not field.player.travelling

# --------------------------------------------------------------- acting ---

## 把选中的候选按它代表的普通输入做出来，再交回同一个 token。
func _current_input(token: String) -> Dictionary:
	var input: Dictionary = JSON.parse_string(engine.AgentCandidateInputJson(token))
	if input.has("boundary"):
		if str(input.boundary) == "unknown_consumed_or_expired_token" and token == str(_last_decision.get("Token", "")):
			var current: Dictionary = JSON.parse_string(engine.AgentObservationJson())
			if int(current.get("Turn", 0)) > _decision_turn and not current.get("Candidates", []).is_empty():
				if _interaction_token == token: _finish_interaction(false)
				else: engine.AgentInteractionFeedback(token, false)
				recorded.emit("superseded_action", {"token": token, "decision_turn": _decision_turn,
					"current_turn": current.get("Turn"), "reason": "visible_candidates_changed"})
				return {}
		stop(str(input.boundary))
		return {}
	return input

func _submit_current(token: String) -> void:
	# A delayed public presentation may replace an input while it is being read.
	# Leave the stale input unexecuted and let the next ordinary observation decide.
	if _current_input(token).is_empty(): return
	engine.AgentExecutionStarted(token)
	host.submit_token(token)

func take_field_reply(input: Dictionary) -> void:
	if _interaction_token != "" and str(input.get("kind", "")) == "interact" \
		and str(input.get("site", "")) == _interaction_site and str(input.get("map", "")) == _interaction_map:
		_finish_interaction(true)

func _finish_interaction(reached: bool) -> void:
	if _interaction_token == "": return
	var token := _interaction_token
	_interaction_token = ""
	_interaction_site = ""
	_interaction_map = ""
	var accepted: bool = engine.AgentInteractionFeedback(token, reached)
	recorded.emit("interaction_feedback", {"token": token, "reached": reached, "accepted": accepted})

func _act(token: String) -> void:
	var input := _current_input(token)
	if input.is_empty():
		return
	recorded.emit("act", {"kind": str(input.get("kind", "")), "token": token})
	var ui: Node = host.ui
	var kind := str(input.get("kind", ""))
	if kind == "field_action" and str(input.get("action", "")) == "interact":
		_finish_interaction(false)
		_interaction_token = token
		_interaction_site = str(input.get("site", ""))
		_interaction_map = str(host.field.adapter.map_key())
	if is_instance_valid(ui) and ui.dialogue.active and (not is_instance_valid(ui.modal_root) or str(input.get("presentation_id", "")) != str(ui._modal_event.get("presentation_id", ""))):
		if kind == "presented":
			# 一句一句读完台词；对白框读完时自己交回的回执就是这次选择。
			_reply_token = token
			_reply = {}
			while not stopping and _reply.is_empty() and ui.dialogue.active:
				await _wait_simulation(line_seconds * 0.5, "reading")
				if is_instance_valid(ui): ui.dialogue.advance()
			_reply_token = ""
			if stopping: return
			_submit_current(token)
			return
		# 台词带选项：读到出现选项为止，再落下这一项。
		while not stopping and ui.dialogue.active and not ui.dialogue_choices_shown():
			await _wait_simulation(line_seconds * 0.5, "reading")
			if is_instance_valid(ui): ui.dialogue.advance()
		if stopping: return
		await _wait_simulation(line_seconds, "reading")
		ui.release_dialogue()
		_submit_current(token)
		return
	match kind:
		"form_field", "form_tab":
			if is_instance_valid(ui): ui.show_form_choice(input)
			await _wait_simulation(line_seconds * 0.5, "reading")
		"select", "form", "navigate", "card", "travel":
			# 与界面自己的按钮一致：落下选项时合上当前弹窗。
			await _wait_simulation(line_seconds, "reading")
			if is_instance_valid(ui): ui.close_modal()
		"replay", "replay_vars":
			await _wait_simulation(line_seconds * 0.5, "reading")
	_submit_current(token)

## 对白框读完的回执：属于正在读的那一项就收下，其余界面输入一律不代替角色做决定。
func take_ui_reply(reply: Dictionary) -> bool:
	if _reply_token == "" or str(reply.get("kind", "")) != "presented": return false
	_reply = reply
	return true

## 引擎回显的现场动作：用正式现场的寻路、碰撞与键盘输入真实走一遍。
func perform_field(input: Dictionary) -> void:
	var field: Node = host.field
	if not is_instance_valid(field): return
	match str(input.get("action", "")):
		"interact": field._approach(str(input.site))
		"move":
			if input.has("entry_point"): await _enter_visible(input)
			elif input.has("goal_point"): await _walk_source(input)
			elif input.has("keys"): await _keyboard_move(input.keys)
			else: field._route_click(Vector2(float(input.point[0]), float(input.point[1])))
		"wait": await _wait_simulation(1.0, "deliberate_wait")

func _walk_source(input: Dictionary) -> void:
	var field: Node = host.field
	var map_key := str(field.adapter.map_key())
	var goal := Vector2(float(input.goal_point[0]), float(input.goal_point[1]))
	var reach := float(input.goal_reach)
	var source := str(input.goal_source_id)
	# Waypoints are geometry progress within the selected source intention.
	# They do not cause another semantic decision or an investigation receipt.
	for leg in range(64):
		if stopping or not field.player_controlled() or str(field.adapter.map_key()) != map_key: return
		if is_instance_valid(host.ui.modal_root) or host.ui.dialogue.active: return
		if field.player.position.distance_to(goal) <= reach + 6.0: return
		var known := PilotNavigation.remember_grid(field, _routes.get(map_key))
		_routes[map_key] = known
		var offers := PilotNavigation.approaches(field, {source: {"point": goal, "reach": reach, "source_id": source}}, known)
		if offers.is_empty(): return
		var waypoint: Array = offers[0].input.point
		var start: Vector2 = field.player.position
		field._route_click(Vector2(float(waypoint[0]), float(waypoint[1])))
		await get_tree().physics_frame
		var elapsed := 0.0
		while not stopping and (not field.click_path.is_empty() or field.player.travelling):
			await get_tree().physics_frame
			elapsed += get_physics_process_delta_time()
			if elapsed > 4.0 or not field.player_controlled(): return
		if start.distance_to(field.player.position) < 8.0: return

func _enter_visible(input: Dictionary) -> void:
	var field: Node = host.field
	var target := Vector2(float(input.entry_point[0]), float(input.entry_point[1]))
	var start_room := str(field.adapter.entered_room(field.player.position))
	var start: Vector2 = field.player.position
	var last: Vector2 = start
	var elapsed := 0.0
	var stalled := 0.0
	var settled := 0.0
	var bound := start.distance_to(target) / maxf(1.0, float(field.player.speed)) + 1.0
	# Keep the selected destination side through this real input execution.
	# New observations may not reverse it at the door centre.
	while not stopping and elapsed < bound:
		await get_tree().physics_frame
		if not is_instance_valid(field) or field.player == null: break
		var delta := get_physics_process_delta_time()
		elapsed += delta
		var current: Vector2 = field.player.position
		var entered := str(field.adapter.entered_room(current))
		var crossed := entered != "" and entered != start_room
		var near := current.distance_to(target) <= 12.0
		settled = settled + delta if crossed and near else 0.0
		if (not bool(input.entry_crossing) and near) or settled >= 0.15: break
		stalled = stalled + delta if current.distance_to(last) < 0.1 else 0.0
		if stalled >= 0.4: break
		last = current
		_release_keys()
		var heading := target - current
		if absf(heading.x) < 8.0: heading.x = 0.0
		if absf(heading.y) < 8.0: heading.y = 0.0
		if near: continue
		for key in PilotNavigation.step_input(heading).keys:
			var code: int = MOVE_KEYS[str(key)]
			_pressed.append(code)
			Input.parse_input_event(_key(code, true))
		Input.flush_buffered_events()
	_release_keys()
	recorded.emit("entry_move", {"start_position": [start.x, start.y], "end_position": [field.player.position.x, field.player.position.y], "target": input.entry_point})

func _keyboard_move(keys: Array) -> void:
	var field: Node = host.field
	var start: Vector2 = field.player.position
	# Start at a physics boundary; scaled simulation time and the offered
	# displacement describe the same action at every test speed.
	await get_tree().physics_frame
	if stopping: return
	for key in keys:
		var code: int = MOVE_KEYS[str(key)]
		_pressed.append(code)
		Input.parse_input_event(_key(code, true))
	Input.flush_buffered_events()
	var elapsed := 0.0
	while not stopping and elapsed < KEY_MOVE_SECONDS:
		await get_tree().physics_frame
		elapsed += get_physics_process_delta_time()
	_release_keys()
	if is_instance_valid(field) and field.player != null:
		recorded.emit("keyboard_move", {"keys": keys, "start_position": [start.x, start.y], "end_position": [field.player.position.x, field.player.position.y]})

func _release_keys() -> void:
	for code in _pressed: Input.parse_input_event(_key(code, false))
	Input.flush_buffered_events()
	_pressed.clear()

static func _key(code: int, pressed: bool) -> InputEventKey:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = pressed
	return event

func stop(reason: String) -> void:
	if stopping: return
	stopping = true
	_finish_interaction(false)
	engine.AgentInteractionFeedback(str(_last_decision.get("Token", "")), false)
	_release_keys()
	var summary := {"reason": reason, "time": JSON.parse_string(engine.AgentTimeJson()), "selections": engine.AgentSelections(), "last_reasoning": _last_decision}
	var field: Node = host.field if is_instance_valid(host) else null
	if is_instance_valid(field) and field.player != null:
		summary["visible_position"] = [field.player.position.x, field.player.position.y]
	engine.CloseAgent()
	stopped.emit(reason, summary)

# --------------------------------------------------------------- offers ---

## 现场此刻对这名角色公开的输入：视线内的调查点、走得到的短步、键盘方向、等待与面板快捷键。
func _field_offers(field: Node, snapshot: Dictionary) -> Array:
	var offers := []
	var space: String = field.adapter.map_key()
	if not _places.has(space): _places[space] = {}
	var remembered: Dictionary = _places[space]
	var visible_sources := {}
	var known: AStarGrid2D = PilotNavigation.remember_grid(field, _routes.get(space))
	_routes[space] = known
	for id in field.sites:
		if not field.site_visible(id): continue
		var point: Vector2 = field.site_point(id)
		var label: String = str(field.sites[id].title)
		var source_id := str(field.sites[id].get("source_id", ""))
		if source_id == "": source_id = _source_id(space + ":site:" + str(id))
		visible_sources[source_id] = true
		remembered[source_id] = {"point": point, "reach": float(field.sites[id].reach), "label": label, "source_id": source_id}
		offers.append({"label": str(field.sites[id].title), "kind": "interact", "new": field.site_is_new(id), "location": [point.x, point.y],
			"source_id": source_id, "method_id": source_id + ":contact", "effect_kind": "Open",
			"travel_distance": PilotNavigation.travel_distance(field, point, float(field.sites[id].reach), known),
			"input": {"kind": "field_action", "action": "interact", "site": id}})
	for entrance in field.player_visible_entrances():
		var source_id := _source_id(space + ":entrance:" + str(entrance.identity))
		visible_sources[source_id] = true
		remembered[source_id] = {"point": entrance.point, "reach": 16.0, "label": entrance.label,
			"source_id": source_id, "frontier": true, "source_state": "open" if bool(entrance.open) else "closed"}
		# A closed visible leaf still permits an ordinary approach attempt.
		# Only the public open state offers a crossing; hidden access rules
		# are never consulted when constructing these inputs.
		var point: Vector2 = entrance.crossing if bool(entrance.open) else entrance.point
		# A crossing is an ordinary keyboard attempt toward the other side;
		# its unseen landing collision is resolved by the live field.
		var heading: Vector2 = point - field.player.position
		var input := PilotNavigation.step_input(heading)
		input["entry_point"] = [point.x, point.y]
		input["entry_crossing"] = bool(entrance.open)
		offers.append({"label": entrance.label, "kind": "move", "new": false,
			"source_state": "open" if bool(entrance.open) else "closed",
			"source_id": source_id, "method_id": source_id + (":cross" if bool(entrance.open) else ":approach"), "destination_source_id": source_id,
			"effect_kind": "Travel" if bool(entrance.open) else "Open", "purpose": "frontier", "known_ground": false,
			"location": [point.x, point.y], "input": input})
	for source_id in remembered.keys():
		if not visible_sources.has(source_id) and field.in_sight(remembered[source_id].point): remembered.erase(source_id)
	offers.append_array(PilotNavigation.approaches(field, remembered, known))
	offers.append_array(PilotNavigation.offers(field, known))
	# Keyboard walking is a public input even when its landing room is unseen; the field resolves it.
	for keys in [["W"], ["S"], ["A"], ["D"], ["W", "A"], ["W", "D"], ["S", "A"], ["S", "D"]]:
		# Offered direction for scoring; actual position is observed separately after execution.
		var heading := Vector2.ZERO
		for key in keys: heading += {"W": Vector2.UP, "S": Vector2.DOWN, "A": Vector2.LEFT, "D": Vector2.RIGHT}[key]
		var aim: Vector2 = field.player.position + heading.normalized() * float(field.player.speed) * KEY_MOVE_SECONDS
		offers.append({"label": "%s %d,%d" % ["+".join(keys), field.player.position.x, field.player.position.y], "kind": "move", "new": false, "location": [aim.x, aim.y], "input": {"kind": "field_action", "action": "move", "keys": keys}})
	# Frontier offers may also use ordinary keyboard input. Their scored
	# endpoint must describe that input, not the unrelated clicked edge point.
	for offer in offers:
		if not offer.input.has("keys") or offer.input.has("entry_point"): continue
		var direction := Vector2.ZERO
		for key in offer.input.keys: direction += {"W": Vector2.UP, "S": Vector2.DOWN, "A": Vector2.LEFT, "D": Vector2.RIGHT}[key]
		var endpoint: Vector2 = field.player.position + direction.normalized() * float(field.player.speed) * KEY_MOVE_SECONDS
		offer.location = [endpoint.x, endpoint.y]
	for offer in offers:
		if offer.kind != "move" or not offer.has("location"): continue
		var endpoint := Vector2(float(offer.location[0]), float(offer.location[1]))
		var cell := Vector2i((endpoint / known.cell_size).floor())
		# A public visibility observation or a previously observed walkable
		# cell is enough. Never inspect unseen collision geometry here.
		offer.known_ground = field.in_sight(endpoint) or (known.region.has_point(cell) and not known.is_point_solid(cell))
	var source_button: Dictionary = host.ui.room_source_button_offer()
	if not source_button.is_empty(): offers.append(source_button)
	var controls: Dictionary = snapshot.get("controls", {})
	if bool(controls.get("wait", false)):
		offers.append({"label": "T", "kind": "wait", "new": false, "input": {"kind": "action", "act": {"cmd": "stay"}}})
	else:
		offers.append({"label": "", "kind": "wait", "new": false, "input": {"kind": "field_action", "action": "wait"}})
	for shortcut in [{"key": "Tab", "panel": "notebook"}, {"key": "R", "panel": "manuscript"}, {"key": "M", "panel": "campus"}]:
		if bool(controls.get(shortcut.panel, false)):
			offers.append({"label": shortcut.key, "kind": "menu", "purpose": "panel", "new": false, "input": {"kind": "player_panel", "panel": shortcut.panel}})
	return offers

## A scaled presentation delay is wall-clock waiting, not CPU work.
func _wait_simulation(seconds: float, reason: String) -> void:
	var began := Time.get_ticks_usec()
	var previous := performance_phase
	performance_phase = reason
	var expected_ms := seconds / Engine.time_scale * 1000.0
	await get_tree().create_timer(seconds).timeout
	performance_phase = previous
	recorded.emit("timing", {"stage": reason, "ms": (Time.get_ticks_usec() - began) / 1000.0, "expected_ms": expected_ms})
