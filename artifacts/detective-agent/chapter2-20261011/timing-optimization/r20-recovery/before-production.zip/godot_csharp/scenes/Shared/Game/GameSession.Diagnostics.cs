using System.Text.Json;
using DualOntologyWorldEngine.Awakening;

namespace DualOntologyWorldEngine.Gameplay;

public sealed partial class GameSession
{
    /// <summary>Test-only incremental execution audit. Never passed to candidate ports or controllers.</summary>
    public string TakeChapter1DiagnosticsJson()
        => _session is Chapter1Session chapter
            ? JsonSerializer.Serialize(chapter.TakeExecutionDiagnostics())
            : JsonSerializer.Serialize(new { diagnostic = "chapter1_execution", version = 1, available = false });
}
