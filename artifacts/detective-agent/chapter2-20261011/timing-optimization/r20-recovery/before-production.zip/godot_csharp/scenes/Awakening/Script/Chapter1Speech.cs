using System.Collections.Immutable;
using System.Text.Json;
using DualOntologyWorldEngine.Core;
using DualOntologyWorldEngine.Story;

namespace DualOntologyWorldEngine.Awakening;

/// <summary>
/// 话题回应：说话人用推理器读自己的认知得出把握，再按言语规则（对听者的信任、是否牵连自己、说话习惯）
/// 选行为，最后取 story 里写给此人或“任何人”的台词（总纲 §六 第二期）。只读本人认知，不读真相与剧情进度。
/// </summary>
public sealed partial class AwakeningContentSession
{
    private static readonly string[] Companions = ["huo", "shen", "su"];

    private JsonElement Topic(string topic) => Content.RootElement.GetProperty("TOPICS").TryGetProperty(topic, out var t) ? t
        : throw new InvalidDataException("Unknown topic: " + topic);

    private static SubjectiveProofV1? TopicProof(MorningWorld world, string actor, JsonElement topic)
    {
        var claim = world.ChapterClaim(actor, topic.GetProperty("question").GetString()!, topic.GetProperty("option").GetString()!);
        if (claim is null) return null;
        var cognition = world.CaptureActorCognition(actor);
        return new SubjectiveReasoner(cognition.Snapshot, cognition.Actor, world.ActorReasoningBudget(actor)).Prove(claim);
    }

    private static double ProofCredence(SubjectiveProofV1? proof) => proof is { Complete: true, Contradicted: false, Hypothetical: false }
        ? proof.Value == Truth.True ? 1 : proof.Value == Truth.False ? 0 : 0.5 : 0.5;

    /// <summary>侦探自己想到第六问（重演被拒或细看过两件相熟旁证）即记入他的认知。</summary>
    private void SyncConception(MorningWorld world)
    {
        var variable = Content.RootElement.GetProperty("VARIABLES").EnumerateArray().First(v => v.GetProperty("key").GetString() == "V6");
        var concept = "awakening:" + variable.GetProperty("question").GetString();
        if (V6Open && !world.Knows(Person.Detective, concept)) world.Conceive(Person.Detective, concept);
    }

    /// <summary>此人对话题命题的把握（0—100），由推理器读其本人认知得出。</summary>
    public int Credence(MorningWorld world, string who, string topic)
    {
        SyncConception(world);
        return (int)Math.Round(100 * ProofCredence(TopicProof(world, who, Topic(topic))));
    }

    /// <summary>此人回答侦探这个话题时选的言语行为，返回 story 里对应的回应键。依据记入会话以供审读。</summary>
    public string SpeechKey(MorningWorld world, string who, string topic)
    {
        SyncConception(world);
        var data = Topic(topic);
        var person = PersonOf(who);
        var proof = TopicProof(world, who, data);
        var credence = ProofCredence(proof);
        var trust = world.TrustIn(person, Person.Detective);
        var implicated = data.GetProperty("implicates").EnumerateArray().Any(p => p.GetString() == who);
        var responses = data.GetProperty("responses");
        bool Written(string key) => responses.TryGetProperty(who, out var own) && own.TryGetProperty(key, out _)
            || responses.TryGetProperty("any", out var any) && any.TryGetProperty(key, out _);
        string? KeyOf(SpeechAct act, Stance stance) => ResponseCatalog.Select(Chapter1Data.Root.GetProperty("EXPRESSION"), "speech", name => name switch
        {
            "act" => act.ToString(), "stance" => stance.ToString(), "speaker" => who, "listener" => "detective",
            "written" => null,
            _ when name.StartsWith("written:", StringComparison.Ordinal) => Written(name[8..]),
            _ when name.StartsWith("known:", StringComparison.Ordinal) => world.Knows(person, name[6..]),
            _ => null,
        })?.Text;
        var available = SpeechPolicy.Assess(credence, trust, Persona.Speech(person), implicated)
            .Where(c => KeyOf(c.Act, c.Stance) is not null).ToArray();
        var cognition = world.CaptureActorCognition(who);
        var offers = available.Select(c => new SubjectiveOfferV1(c.Act + ":" + c.Stance,
            "speech:" + topic + ":" + KeyOf(c.Act, c.Stance), "speaker:" + who, SubjectiveActionKindV1.Acknowledge)
        {
            Context = "listener:detective", RuleScore = (int)c.Score,
            RuleBasis = [..c.Reasons.Select(Chapter1Expression.SpeechReason)]
        }).ToImmutableArray();
        // Expression evaluation is a read-only preview, not an execution or tie draw.
        var assessed = SubjectiveAgent.Assess(new(cognition.Snapshot, cognition.Actor,
            world.ActorReasoningBudget(who), offers, new()), world.ActorAgency(who));
        var preview = assessed.Offers.FirstOrDefault(o => !o.Forbidden);
        var choice = preview is null ? null : available.First(c => c.Act + ":" + c.Stance == preview.Offer.Id);
        if (choice is null) { Session.Set("speech", who + ":" + topic, "none"); return "none"; }
        var key = KeyOf(choice.Act, choice.Stance)!;
        Session.Set("speech", who + ":" + topic,
            $"{key}；把握 {credence:0.00}；信任 {trust}；{string.Join("，", choice.Reasons.Select(Chapter1Expression.SpeechReason))}；依据：{string.Join("；", proof?.Steps ?? [])}");
        return key;
    }

    private sealed record SpeechDelivery(string Actor, string Method, string Receipt);
    private readonly Dictionary<string, List<SpeechDelivery>> _speechDeliveries = new(StringComparer.Ordinal);

    public void BeginSpeechDelivery(MorningWorld world, string deliveryId, IReadOnlyList<InteractionLine> lines)
    {
        if (!_speechDeliveries.TryGetValue(deliveryId, out var pending))
            _speechDeliveries.Add(deliveryId, pending = []);
        foreach (var topic in Content.RootElement.GetProperty("TOPICS").EnumerateObject())
        foreach (var author in topic.Value.GetProperty("responses").EnumerateObject())
        foreach (var response in author.Value.EnumerateObject())
        {
            var ids = response.Value.EnumerateArray().Where(i => i.TryGetProperty("line_id", out _))
                .Select(i => i.GetProperty("line_id").GetString()).ToHashSet();
            var delivered = lines.Where(l => ids.Contains(l.LineId)).ToArray();
            if (delivered.Length == 0) continue;
            var actor = author.Name;
            if (actor == "any")
            {
                var speakers = delivered.Select(l => l.Speaker).Distinct().ToArray();
                if (speakers.Length != 1) continue;
                actor = Content.RootElement.GetProperty("PERSON_NAMES").EnumerateObject()
                    .Where(p => p.Value.GetString() == speakers[0]).Select(p => p.Name).FirstOrDefault() ?? "";
            }
            if (!world.MorningActors.Contains(actor)) continue;
            var method = "speech:" + topic.Name + ":" + response.Name;
            if (pending.Any(p => p.Actor == actor && p.Method == method)) continue;
            var receipt = deliveryId + ":" + actor + ":" + method;
            SubjectiveAgent.Feedback(world.ActorAgency(actor), new(receipt + ":started", method,
                "listener:detective", DecisionOutcomeV1.Attempted));
            pending.Add(new(actor, method, receipt));
        }
    }

    public void EndSpeechDelivery(MorningWorld world, string deliveryId, bool completed)
    {
        if (!_speechDeliveries.Remove(deliveryId, out var pending)) return;
        foreach (var delivery in pending)
            SubjectiveAgent.Feedback(world.ActorAgency(delivery.Actor), new(delivery.Receipt + ":finished",
                delivery.Method, "listener:detective", completed ? DecisionOutcomeV1.Succeeded : DecisionOutcomeV1.Interrupted));
    }

    /// <summary>
    /// 侦探重演昨夜：同处一室的同伴看见他在重演；吻合时侦探把这组认定当作自己推出的，
    /// 被召来目睹收尾的三位同伴各自按对侦探的信任折算这组认定。
    /// </summary>
    public void WitnessReplay(MorningWorld world, NightVariables variables, bool fullMatch)
    {
        var here = Session.CharacterRooms.GetValueOrDefault("detective");
        foreach (var who in Companions)
            if (fullMatch || here is not null && Session.CharacterRooms.GetValueOrDefault(who) == here)
                world.Witness(PersonOf(who), Chapter1Data.Text("认知·正在重演"));
        if (!fullMatch) return;
        var claims = AwakeningCase.Claims(variables).ToArray();
        world.Hear(Person.Detective, Person.Detective, claims);
        foreach (var who in Companions)
        {
            world.Witness(PersonOf(who), Chapter1Data.Text("认知·重演吻合"));
            world.Hear(PersonOf(who), Person.Detective, claims);
        }
    }

    /// <summary>检视时同场且宿主确认可见的同伴也看见了这件东西；纯逻辑调用沿用同场抽象。</summary>
    private void ShareExamination(MorningWorld world, string id, IReadOnlySet<string>? visiblePeople)
    {
        var here = Session.CharacterRooms.GetValueOrDefault("detective");
        if (here is null) return;
        foreach (var who in Companions)
            if (Session.CharacterRooms.GetValueOrDefault(who) == here && (visiblePeople is null || visiblePeople.Contains(who)))
                world.Examine(PersonOf(who), id);
    }
}
