using System.Collections.Immutable;
using System.Text.Json;
using DualOntologyWorldEngine.Core;
using DualOntologyWorldEngine.Story;

namespace DualOntologyWorldEngine.Awakening;

public sealed partial class MorningWorld
{
    public sealed record MorningOperationHeader(string Id,string Source,string Kind,string Participant,int Sentence,string OfferId);
    public sealed record MorningOperationLine(string Id,string Text,string Speaker);
    public sealed record MorningOperationReceipt(string Actor,string Id,string Source,string Kind,string Participant,int Sentence,string Presentation,IReadOnlyList<HeardAt> Heard,string Executor,string Outcome="succeeded",RecallMemory? Memory=null,IReadOnlyList<MorningOperationLine>? Lines=null,string InformationIdentity="",bool AcquiredInformation=false)
    { public string Recipient => Actor; public IReadOnlyList<MorningOperationLine> OutcomeLines => Lines ?? []; }
    private readonly List<MorningOperationReceipt> _actualOperationReceipts=[];
    public IReadOnlyList<MorningOperationReceipt> ActualOperationReceipts => _actualOperationReceipts.ToArray();
    public event Action<MorningOperationReceipt>? OperationCompleted;
    public string ActorIdentity(string actor) => "world:person."+RequiredActor(actor).Key;
    public IReadOnlyList<MorningOperationHeader> ActorOperationOffers(string actor) => PrepareMorningOffers(RequiredActor(actor))
        .Where(w=>w.MainOperation.Length>0 && !w.MainOperation.StartsWith("accept:",StringComparison.Ordinal)).Select(w=>
        {
            var id=w.MainOperation.StartsWith("request:",StringComparison.Ordinal) ? w.MainOperation["request:".Length..] : w.MainOperation;
            var split=id.Split('@',2);var op=Operation(split[0])!.Value;
            return new MorningOperationHeader(split[0],OpString(op,"source"),OpString(op,"kind"),ActorIdentity(OpString(op,"participant","self")=="self" ? actor : OpString(op,"participant")),
                split.Length==2 ? int.Parse(split[1]) : -1,w.MainOperation);
        }).ToArray();
    public string? TryPublicOperation(string actor,string kind,string source,string participant,int sentence=-1) => ActorOperationOffers(actor)
        .FirstOrDefault(o=>o.Kind==kind && o.Source==source && o.Participant==ActorIdentity(participant) && o.Sentence==sentence)?.OfferId;
    private readonly Dictionary<string,string> _completedOperationInformation = new(StringComparer.Ordinal);
    private string OperationInformationIdentity(string actor) => _completedOperationInformation.GetValueOrDefault(RequiredActor(actor).Actor,"");
    private static string ActualInformationIdentity(string method,object result) => "result:" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
        System.Text.Encoding.UTF8.GetBytes(method+"\n"+JsonSerializer.Serialize(result))));
    private static readonly Tag OperationDone = new("OperationCompleted");
    private static IEnumerable<JsonElement> Operations => Chapter1Data.Root.TryGetProperty("MAIN_OPERATIONS", out var ops) ? ops.EnumerateArray() : [];
    private static string OpString(JsonElement op, string key, string fallback = "") => op.TryGetProperty(key, out var value) ? value.GetString()! : fallback;
    private static string[] OpStrings(JsonElement op, string key) => op.TryGetProperty(key, out var values) ? values.EnumerateArray().Select(v => v.GetString()!).ToArray() : [];
    private static Tag DoneOperation(string id) => new("main.operation.done:" + id);
    private static JsonElement? Operation(string id) => Operations.Where(o => OpString(o,"id") == id).Select(o => (JsonElement?)o).SingleOrDefault();
    private bool OperationAllowed(DailyPerson person, JsonElement op)
    {
        var actors = OpStrings(op,"actors");
        if (actors.Length > 0 && !actors.Contains(person.Actor)) return false;
        if (person.Self.Tags.GetValueOrDefault(DoneOperation(OpString(op,"id"))) == 1) return false;
        if (!OpStrings(op,"requires_all").All(k => MainMaterial(person,k) is not null)) return false;
        var any = OpStrings(op,"requires_any");
        return any.Length == 0 || any.Any(k => MainMaterial(person,k) is not null);
    }
    private bool PersonallyEstablished(DailyPerson person,string proposition)
    {
        if(MainProposition(person,proposition) is not {} claim) return false;
        var snapshot=MorningContract(person.Soul.World.CaptureSnapshot());
        var proof=new SubjectiveReasoner(snapshot,person.Self.SubjectId!.Value,ActorReasoningBudget(person.Actor)).Prove(claim);
        return proof is {Value:Truth.True,Complete:true,Contradicted:false,Hypothetical:false};
    }
    private IEnumerable<int> KnownOperationSentences(DailyPerson person,JsonElement op)
    {
        if(!op.GetProperty("contrary_propositions").EnumerateArray().Any(group=>group.EnumerateArray().All(p=>PersonallyEstablished(person,p.GetString()!)))) yield break;
        foreach(var entry in op.GetProperty("sentence_propositions").EnumerateObject())
            if(entry.Value.EnumerateArray().All(p=>PersonallyEstablished(person,p.GetString()!))) yield return int.Parse(entry.Name);
    }
    private Projection? OperationRequest(DailyPerson helper,string requester,string operation) => helper.Soul.World.Projections.FirstOrDefault(p =>
        p.KnownTerms.Any(t => t.TermId.Value == "operation.request:" + requester + ":" + operation));
    private void RecordOperationRequest(DailyPerson requester, DailyPerson helper, JsonElement operation)
    {
        var id = OpString(operation,"id");
        if (OperationRequest(helper,requester.Key,id) is not null) return;
        Observation.Observe(helper.Soul,new(OpString(operation,"label"),ProjectionKind.Concept)
        {
            Source=ObservationSource.Testimony,Existence=Truth.True,Time=_dailySession.CTB.Now,
            KnownTerms=[new(new("operation.request:"+requester.Key+":"+id),id,OpString(operation,"label")),
                new(new("operation.requester:"+requester.Key),requester.Key,requester.Self.Name),
                new(new("operation.id:"+id),id,OpString(operation,"label"))]
        });
    }
    private bool SameOperationPlace(DailyPerson person,DailyPerson other) => ReferenceEquals(person.Body.Get<SpatialProperty>()?.Space,other.Body.Get<SpatialProperty>()?.Space);
    private bool BuildOperationEffect(DailyPerson person, JsonElement op, out Effect effect, int sentence = -1)
    {
        effect = new Effect.Set(person.Self,OperationDone,1);
        var effects = new List<Effect>();
        foreach (var step in op.GetProperty("steps").EnumerateArray())
        {
            if(OpString(step,"op")=="utter") continue;
            var targetKey=OpString(step,"target",OpString(op,"source"));
            var targetPerson=_dailyPeople.Values.FirstOrDefault(p=>p.Actor==targetKey || p.Key==targetKey);
            var target=_evidence.TryGetValue(targetKey,out var body) ? _runtime.KnownProjection(person.Soul,body)
                : targetKey=="self" ? person.Self
                : targetPerson is not null ? _runtime.KnownProjection(person.Soul,targetPerson.Body) : null;
            if(target is null) return false;
            switch(OpString(step,"op"))
            {
                case "set": effects.Add(new Effect.Set(target,new Tag(OpString(step,"tag")),step.GetProperty("value").GetInt32())); break;
                case "compare":
                    var participant=OpString(op,"participant","self");
                    var compared=participant=="self" ? person : RequiredActor(participant);
                    var reference=_runtime.KnownProjection(person.Soul,compared.Body);
                    if(reference is null || reference.Parent!=person.Self.Parent) return false;
                    effects.Add(new Effect.Act(ActionOp.Inspect,target));
                    effects.Add(new Effect.Act(ActionOp.Inspect,reference));
                    break;
                case "inspect": case "recall": case "sound": effects.Add(new Effect.Act(ActionOp.Inspect,target)); break;
                case "utter": break;
                default: return false;
            }
        }
        if(OpString(op,"mode")!="sound") effects.Add(new Effect.Set(person.Self,DoneOperation(OpString(op,"id")),1));
        effect=new Effect.Sequence(effects.ToImmutableArray());
        return true;
    }
    private void AddMainOperationCandidates(DailyPerson person,string room,List<MorningWork> candidates)
    {
        foreach(var op in Operations)
        {
            var source=OpString(op,"source");
            if(!_evidence.TryGetValue(source,out var body) || _runtime.KnownProjection(person.Soul,body) is not { } known
                || !ReferenceEquals(known.Parent,person.Self.Parent) || !OperationAllowed(person,op)) continue;
            var participant=OpString(op,"participant","self");
            var helper=participant=="self" ? person : RequiredActor(participant);
            var helperView=ReferenceEquals(person,helper) ? person.Self : _runtime.KnownProjection(person.Soul,helper.Body);
            if(helperView is null || helperView.Parent!=person.Self.Parent) continue;
            var id=OpString(op,"id");
            if(op.TryGetProperty("self_first",out var first) && first.GetBoolean() && !ReferenceEquals(person,helper)
                && person.Self.Tags.GetValueOrDefault(new Tag("main.comparison:"+source+":"+person.Actor))!=1) continue;
            var consent=op.TryGetProperty("requires_consent",out var require) && require.GetBoolean() && !ReferenceEquals(person,helper);
            if(consent)
            {
                if(person.Self.Tags.GetValueOrDefault(new Tag("operation.request.sent:"+helper.Key+":"+id))==1) continue;
                var receiver=_runtime.KnownProjection(person.Soul,helper.Body);
                if(receiver is null) continue;
                Add("request:"+id,new Effect.Say(receiver,OpString(op,"label")),SubjectiveActionKindV1.Observe);
            }
            else if(OpString(op,"mode")=="sound")
            {
                foreach(var sentence in KnownOperationSentences(person,op))
                    if(BuildOperationEffect(person,op,out var soundEffect,sentence)) Add(id+"@"+sentence,soundEffect,SubjectiveActionKindV1.Test);
            }
            else if(BuildOperationEffect(person,op,out var effect)) Add(id,effect,SubjectiveActionKindV1.Test);
            void Add(string method,Effect effect,SubjectiveActionKindV1 kind) => candidates.Add(new(
                new(method,method,MainSourceId(source),kind){ScopeId="main.sources",Materials=[known.SubjectId!.Value],AcquiresInformation=true,Cost=1,Context=room},
                new(room,source,"operation",OpString(op,"label"),1,1,[]),effect,MainEvidence:source,MainOperation:method));
        }
        foreach(var request in person.Soul.World.Projections.Where(p=>p.KnownTerms.Any(t=>t.TermId.Value.StartsWith("operation.id:",StringComparison.Ordinal))))
        {
            var id=request.KnownTerms.First(t=>t.TermId.Value.StartsWith("operation.id:",StringComparison.Ordinal)).TermId.Value["operation.id:".Length..];
            var requesterKey=request.KnownTerms.First(t=>t.TermId.Value.StartsWith("operation.requester:",StringComparison.Ordinal)).TermId.Value["operation.requester:".Length..];
            var requester=RequiredActor(requesterKey);
            if(Operation(id) is not {} op || _runtime.KnownProjection(person.Soul,requester.Body) is not {} requesterView
                || requesterView.Parent!=person.Self.Parent || request.Tags.GetValueOrDefault(OperationDone)==1
                || !BuildOperationEffect(person,op,out var effect)) continue;
            var method="accept:"+requesterKey+":"+id;
            candidates.Add(new(new(method,method,MainSourceId(OpString(op,"source")),SubjectiveActionKindV1.Test)
                {ScopeId="main.sources",Materials=[request.SubjectId!.Value],AcquiresInformation=true,Cost=1,Context=room},
                new(room,OpString(op,"source"),"operation",OpString(op,"label"),1,1,[]),effect,MainEvidence:OpString(op,"source"),MainOperation:method));
        }
    }
    private bool CompleteMainOperation(DailyPerson person,out bool information)
    {
        var id=person.Work!.MainOperation;
        information=false;
        if(id.StartsWith("request:",StringComparison.Ordinal))
        {
            if(Operation(id["request:".Length..]) is not {} requested) return false;
            var helper=RequiredActor(OpString(requested,"participant"));
            if(!SameOperationPlace(person,helper)) return false;
            RecordOperationRequest(person,helper,requested);
            Observation.Observe(person.Soul,new(person.Self.Name,person.Self.Kind){Target=person.Self,Source=ObservationSource.Introspection,Time=_dailySession.CTB.Now,
                Tags=ImmutableDictionary<Tag,int?>.Empty.Add(new Tag("operation.request.sent:"+helper.Key+":"+OpString(requested,"id")),1)});
            _actualOperationReceipts.Add(new(ActorIdentity(person.Actor),OpString(requested,"id"),OpString(requested,"source"),OpString(requested,"kind"),ActorIdentity(helper.Actor),-1,"",[],ActorIdentity(person.Actor),"requested"));
            return true;
        }
        var recipient=person;
        if(id.StartsWith("accept:",StringComparison.Ordinal))
        {
            var pieces=id["accept:".Length..].Split(':',2);
            recipient=RequiredActor(pieces[0]);id=pieces[1];
            if(!SameOperationPlace(person,recipient)) return false;
        }
        var succeeded=CompleteActorOperation(person.Actor,id,recipient.Actor,person.Execution!,out information);
        if(succeeded && !ReferenceEquals(person,recipient) && OperationRequest(person,recipient.Key,id) is {} request)
            Observation.Observe(person.Soul,new(request.Name,request.Kind){Target=request,Source=ObservationSource.Introspection,Time=_dailySession.CTB.Now,
                Tags=ImmutableDictionary<Tag,int?>.Empty.Add(OperationDone,1)});
        return succeeded;
    }
    public bool TryActorOperationEffect(string actor,string id,out Effect effect)
    {
        var person=RequiredActor(actor);effect=new Effect.Set(person.Self,OperationDone,1);
        var split=id.Split('@',2);var operationId=split[0];
        var sentence=split.Length==2 ? int.Parse(split[1]) : -1;
        return Operation(operationId) is {} op && OperationAllowed(person,op)
            && (OpString(op,"participant","self")=="self" || OpString(op,"participant")==person.Actor)
            && (OpString(op,"mode")!="sound" || KnownOperationSentences(person,op).Contains(sentence))
            && BuildOperationEffect(person,op,out effect,sentence);
    }
    public bool CompleteActorOperation(string actor,string id,string recipientActor,ActionExecution execution,out bool information)
    {
        information=false;
        var person=RequiredActor(actor);var recipient=RequiredActor(recipientActor);
        _completedOperationInformation[person.Actor]="";
        if(execution.Status!=ExecutionStatus.Completed || execution.Result is not {Succeeded:true}
            || !ReferenceEquals(execution.Intent.Actor,person.Self)) return false;
        var receiptTag=new Tag("operation.receipt:"+execution.Id.Value);
        if(person.Self.Tags.GetValueOrDefault(receiptTag)==1) return false;
        var split=id.Split('@',2);id=split[0];
        var sentence=split.Length==2 ? int.Parse(split[1]) : -1;
        if(Operation(id) is not {} op || !SameOperationPlace(person,recipient)) return false;
        var participant=OpString(op,"participant","self");
        if(participant!="self" && participant!=person.Actor) return false;
        if(!ReferenceEquals(person,recipient) && OperationRequest(person,recipient.Key,id) is null) return false;
        if(OpString(op,"mode")!="sound" && person.Self.Tags.GetValueOrDefault(DoneOperation(id))!=1) return false;
        var source=OpString(op,"source");
        if(!_evidence.TryGetValue(source,out var entity) || _runtime.KnownProjection(person.Soul,entity) is not {} target
            || !new ActionRuntime(_runtime).CanInspect(person.Soul,person.Self,target)) return false;
        if(!BuildOperationEffect(person,op,out var expected,sentence) || !Ast.Equivalent(expected,execution.Intent.Changes)) return false;
        var kind=OpString(op,"kind");
        IReadOnlyList<HeardAt> deliveredSound=[];
        RecallMemory? completedMemory=null;
        var informationIdentity="";
        var deliveredLines=new List<MorningOperationLine>();
        if(kind=="recall")
        {
            information=CompleteActorRecall(actor,source);
            if(!information) return false;
            completedMemory=Memories.First(m=>m.Evidence==source);
            informationIdentity=ActualInformationIdentity(id,new { Source=source,Memory=completedMemory.Fragment });
            foreach(var lineId in OpStrings(op,"outcome_lines"))
            {
                var line=Chapter1Data.Root.GetProperty("MAIN_OPERATION_LINES").GetProperty(lineId);
                deliveredLines.Add(new(lineId,line.GetProperty("text").GetString()!,line.GetProperty("speaker").GetString()!));
            }
            var declaration=AcquiredPropositions.Read(Chapter1Data.Root);
            declaration.Bindings.Add(new(){Kind="memory",Key=source,Source="memory",Act="recall",ShowReference=source,Reliability=op.GetProperty("reliability").GetInt32(),Propositions=OpStrings(op,"memory_propositions").ToList()});
            new AcquiredPropositions(declaration,person.Soul).Acquire("memory",source,Chapter1Data.Root.GetProperty("EVIDENCE").GetProperty(source).GetProperty("recall_fragment").GetString()!,_dailySession.CTB.Now);
        }
        else if(OpString(op,"mode")=="sound")
        {
            if(!KnownOperationSentences(person,op).Contains(sentence) || sentence<0 || sentence>=TestSentences.All.Length) return false;
            var positions=_dailyPeople.Values.Where(p=>p.Hosted is not null).ToDictionary(p=>p.Hosted!.Value,
                p=>(Room)Array.IndexOf(Names.RoomKeys,_dailySpaces.Single(r=>ReferenceEquals(r.Value,p.Body.Get<SpatialProperty>()?.Space)).Key));
            var heard=SoundTest(TestSentences.All[sentence],positions);
            deliveredSound=heard;
            foreach(var hearing in heard)
            {
                var listener=RequiredActor(Names.PersonKeys[(int)hearing.Who]);
                if(hearing.Hearing is Hearing.Nothing or Hearing.AlarmOnly) continue;
                RecordMainExecutionReceipt(listener.Actor,"test",source);
                var resultIdentity=ActualInformationIdentity(id,new { Sentence=sentence,Room=Names.RoomKeys[(int)hearing.Where],Hearing=hearing.Hearing,hearing.Text,hearing.Direction });
                var existing=listener.Soul.World.Projections.FirstOrDefault(p=>p.KnownTerms.Any(t=>t.TermId.Value==resultIdentity));
                Observation.Observe(listener.Soul,new(hearing.Text,ProjectionKind.Event){Target=existing,Source=ObservationSource.Perception,Existence=Truth.True,Time=_dailySession.CTB.Now,
                    Details=hearing.Text,KnownTerms=[new(new(resultIdentity),resultIdentity,hearing.Text)]});
                if(ReferenceEquals(listener,person))
                {
                    information=existing is null;
                    informationIdentity=resultIdentity;
                }
                var hearingKey=hearing.Hearing.ToString().ToLowerInvariant();
                var established=new List<string>();
                if(OpStrings(op,"heard_requires").Contains(hearingKey)) established.AddRange(OpStrings(op,"heard_propositions"));
                if(op.TryGetProperty("hearing_rule",out var rule) && OpString(rule,"heard")==hearingKey
                    && (!rule.GetProperty("requires_known_sentence").GetBoolean() || KnownOperationSentences(listener,op).Contains(sentence)))
                    established.Add(OpString(rule,"proposition"));
                if(established.Count>0)
                {
                    var declaration=AcquiredPropositions.Read(Chapter1Data.Root);
                    declaration.Bindings.Add(new(){Kind="operation",Key=id+"@"+sentence+":"+hearingKey,Source="perception",Act="assert",Reliability=100,Propositions=established});
                    new AcquiredPropositions(declaration,listener.Soul).Acquire("operation",id+"@"+sentence+":"+hearingKey,hearing.Text,_dailySession.CTB.Now);
                }
            }
        }
        else
        {
            information=ExamineActor(person.Actor,source);
            var outcomeLines=OpStrings(op,"outcome_lines");
            if(op.TryGetProperty("boundary",out var boundary) && boundary.GetBoolean()
                && Chapter1Data.Root.GetProperty("MORNING_PASSAGES").EnumerateObject().Where(e=>e.Value.TryGetProperty("main_boundary",out var b)&&b.GetBoolean())
                    .Any(e=>_morningPassages[e.Name].Get<LockProperty>() is {IsLocked:false})) outcomeLines=OpStrings(op,"open_outcome_lines");
            foreach(var lineId in outcomeLines)
            {
                var line=Chapter1Data.Root.GetProperty("MAIN_OPERATION_LINES").GetProperty(lineId);
                deliveredLines.Add(new(lineId,line.GetProperty("text").GetString()!,line.GetProperty("speaker").GetString()!));
                var identity="operation.result:"+id+":"+lineId;
                var prior=recipient.Soul.World.Projections.FirstOrDefault(p=>p.KnownTerms.Any(t=>t.TermId.Value==identity));
                if(prior is null)
                {
                    Observation.Observe(recipient.Soul,new(line.GetProperty("text").GetString()!,ProjectionKind.Event){Source=ObservationSource.Perception,Existence=Truth.True,
                        Time=_dailySession.CTB.Now,Details=line.GetProperty("text").GetString()!,KnownTerms=[new(new(identity),lineId,line.GetProperty("text").GetString()!)]});
                    information=true;
                }
                AcquireActorLine(recipient.Actor,lineId,line.GetProperty("text").GetString()!,line.GetProperty("speaker").GetString()!);
                if(!ReferenceEquals(person,recipient)) AcquireActorLine(person.Actor,lineId,line.GetProperty("text").GetString()!,line.GetProperty("speaker").GetString()!);
            }
            var group=OpStrings(op,"group_required");
            if(OpString(op,"mode")=="compare")
            {
                var compared=participant=="self" ? person.Actor : participant;
                Observation.Observe(recipient.Soul,new(recipient.Self.Name,recipient.Self.Kind){Target=recipient.Self,Source=ObservationSource.Introspection,Time=_dailySession.CTB.Now,
                    Tags=ImmutableDictionary<Tag,int?>.Empty.Add(new Tag("main.comparison:"+source+":"+compared),1)});
            }
            if(group.Length>0)
            {
                if(group.All(key=>recipient.Self.Tags.GetValueOrDefault(new Tag("main.comparison:"+source+":"+key))==1)) RecordMainExecutionReceipt(recipient.Actor,kind,source);
            }
            else RecordMainExecutionReceipt(recipient.Actor,kind,source);
            Observation.Observe(recipient.Soul,new(recipient.Self.Name,recipient.Self.Kind){Target=recipient.Self,Source=ObservationSource.Introspection,Time=_dailySession.CTB.Now,Tags=ImmutableDictionary<Tag,int?>.Empty.Add(DoneOperation(id),1)});
        }
        if(information && informationIdentity.Length==0)
            informationIdentity=ActualInformationIdentity(id,new {Source=source,Participant=participant,Results=deliveredLines.Select(l=>new {l.Id,l.Text}),
                Tags=entity.Get<StateProperty>()?.Observable.OrderBy(t=>t.Name).Select(t=>new {t.Name,Value=target.Tags.GetValueOrDefault(t)}).ToArray()});
        if(information) _completedOperationInformation[person.Actor]=informationIdentity;
        Observation.Observe(person.Soul,new(person.Self.Name,person.Self.Kind){Target=person.Self,Source=ObservationSource.Introspection,Time=_dailySession.CTB.Now,
            Tags=ImmutableDictionary<Tag,int?>.Empty.Add(receiptTag,1)});
        var actualReceipt=new MorningOperationReceipt(ActorIdentity(recipient.Actor),id,source,kind,ActorIdentity(participant=="self" ? person.Actor : participant),sentence,OpString(op,"presentation"),deliveredSound,ActorIdentity(person.Actor),Memory:completedMemory,Lines:deliveredLines,InformationIdentity:informationIdentity,AcquiredInformation:information);
        _actualOperationReceipts.Add(actualReceipt);
        OperationCompleted?.Invoke(actualReceipt);
        return true;
    }
}
