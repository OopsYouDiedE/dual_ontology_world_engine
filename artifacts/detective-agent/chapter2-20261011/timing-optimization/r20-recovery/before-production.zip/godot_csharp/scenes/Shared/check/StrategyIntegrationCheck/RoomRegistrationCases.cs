using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using DualOntologyWorldEngine.Awakening;
using DualOntologyWorldEngine.Core;
using DualOntologyWorldEngine.Story;
using static DualOntologyWorldEngine.Story.SessionPersistence;

// Injected mechanism fixtures, not evidence of geometry, rendering, or playtime.
// Identity and compatibility numbers are read from the formal compiled declarations.
internal static class RoomRegistrationCases
{
    private static object Field(object target, string name) => target.GetType().GetField(name,
        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)!.GetValue(target)!;
    private static void Stop(Chapter1Session session) => session.World.GetType().GetMethod("StopEcology",
        BindingFlags.Instance | BindingFlags.NonPublic)!.Invoke(session.World, null);
    private static (string Key, Room Id)[] Rooms() => Chapter1Data.Root.GetProperty("ROOM_IDS")
        .EnumerateObject().Select(p => (p.Name, (Room)p.Value.GetInt32())).OrderBy(p => (int)p.Item2).ToArray();
    private static (string Key, Person Id)[] Actors() => Chapter1Data.Root.GetProperty("PERSON_IDS")
        .EnumerateObject().Select(p => (p.Name, (Person)p.Value.GetInt32())).OrderBy(p => (int)p.Item2).ToArray();
    private static Essence Space(Chapter1Session session, Room id) =>
        (Essence)((IDictionary)Field(session.World, "_space"))[id]!;
    private static Essence Body(Chapter1Session session, Person id) =>
        (Essence)((IDictionary)Field(session.World, "_bodies"))[id]!;
    private static SoulEssence Soul(Chapter1Session session, Person id) =>
        (SoulEssence)((IDictionary)Field(session.World, "_souls"))[id]!;
    private static bool OwnObservationMatchesRoom(Chapter1Session session, Person id, Room room)
    {
        var runtime = session.World.PersistentSession.Runtime;
        var own = runtime.KnownProjection(Soul(session, id), Body(session, id));
        var observedRoom = runtime.KnownProjection(Soul(session, id), Space(session, room));
        return observedRoom is not null && ReferenceEquals(own!.Parent, observedRoom);
    }
    private static void Report(Chapter1Session session, string region, string entered, string name)
    {
        var result = session.Dispatch(new Dictionary<string, object?>
        {
            ["kind"] = "move",
            ["context"] = new Dictionary<string, object?>
            {
                ["field_active"] = false, ["modal"] = "",
                ["actors"] = Actors().ToDictionary(p => p.Key, p => (object?)new Dictionary<string, object?>
                {
                    ["room"] = region, ["entered"] = entered, ["room_name"] = name,
                    ["visible"] = true, ["moving"] = false, ["distance"] = 0.0
                })
            }
        });
        if (result.Any(e => e.GetValueOrDefault("kind") as string == "error"))
            throw new InvalidOperationException(JsonSerializer.Serialize(result));
    }
    private static void RegisteredState(Chapter1Session session, Room room, string key, Action<string, bool> check)
    {
        var declarations = Rooms();
        var spaces = (IDictionary)Field(session.World, "_space");
        check("declared_rooms_create_distinct_actual_spaces", spaces.Count == declarations.Length
            && declarations.All(p => spaces.Contains(p.Id) && Space(session, p.Id).Kind == ProjectionKind.Space)
            && declarations.Select(p => Space(session, p.Id)).Distinct(ReferenceEqualityComparer.Instance).Count() == declarations.Length);
        var daily = (IDictionary)Field(session.World, "_dailySpaces");
        check("declared_room_reuses_same_space_in_ecology_registry", ReferenceEquals(daily[key], Space(session, room)));
        check("appended_room_receipt_moves_player_and_party_real_bodies", Actors().All(p =>
            ReferenceEquals(Body(session, p.Id).Get<SpatialProperty>()!.Space, Space(session, room))));
        check("appended_room_receipt_moves_player_and_party_logical_rooms", Actors().All(p =>
            session.ContentSession.Session.CharacterRooms[p.Key] == key));
        check("appended_room_receipt_updates_each_subject_own_room_observation", Actors().All(p => OwnObservationMatchesRoom(session, p.Id, room)));
    }
    public static void EntryAndSave(Action<string, bool> check)
    {
        var declarations = Rooms();
        var extended = declarations.Where(p => !Enum.IsDefined(p.Id)).ToArray();
        check("formal_compiled_room_declaration_extends_legacy_named_enum", extended.Length > 0);
        foreach (var appended in extended)
        {
            var session = new Chapter1Session();
            Chapter1Session? restored = null;
            try
            {
                var actors = Actors();
                var runtime = session.World.PersistentSession.Runtime;
                var originalBodies = actors.Select(p => Body(session, p.Id).Get<SpatialProperty>()!.Space).ToArray();
                var originalParents = actors.Select(p => runtime.KnownProjection(Soul(session, p.Id), Body(session, p.Id))!.Parent).ToArray();
                var originalLogicalRooms = actors.Select(p => session.ContentSession.Session.CharacterRooms.GetValueOrDefault(p.Key, "")).ToArray();
                Report(session, appended.Key, "", Names.Of(appended.Id));
                check("appended_room_threshold_preserves_each_last_actual_room", actors.Select((p, i) => (p, i)).All(item =>
                    ReferenceEquals(Body(session, item.p.Id).Get<SpatialProperty>()!.Space, originalBodies[item.i])
                    && ReferenceEquals(runtime.KnownProjection(Soul(session, item.p.Id), Body(session, item.p.Id))!.Parent, originalParents[item.i])
                    && session.ContentSession.Session.CharacterRooms.GetValueOrDefault(item.p.Key, "") == originalLogicalRooms[item.i]));
                Report(session, appended.Key, appended.Key, Names.Of(appended.Id));
                RegisteredState(session, appended.Id, appended.Key, check);
                var facts = (IDictionary)Field(session, "_facts");
                check("appended_entry_fact_keeps_declared_key_and_display_name", actors.All(p =>
                    (string)Field(facts[p.Key]!, "Room") == appended.Key
                    && (string)Field(facts[p.Key]!, "Entered") == appended.Key
                    && (string)Field(facts[p.Key]!, "RoomName") == Names.Of(appended.Id)));
                var previousRoom = declarations.First(p => p.Id != appended.Id);
                Report(session, previousRoom.Key, "", Names.Of(previousRoom.Id));
                check("threshold_after_appended_entry_keeps_appended_room_facts", actors.All(p =>
                    (string)Field(facts[p.Key]!, "Room") == appended.Key
                    && (string)Field(facts[p.Key]!, "Entered") == ""
                    && (string)Field(facts[p.Key]!, "RoomName") == Names.Of(appended.Id)));
                check("threshold_after_appended_entry_keeps_actual_room_and_own_observation", actors.All(p =>
                    ReferenceEquals(Body(session, p.Id).Get<SpatialProperty>()!.Space, Space(session, appended.Id))
                    && OwnObservationMatchesRoom(session, p.Id, appended.Id)));

                // The neutral fixture relocates one formally declared object into this room.
                var evidenceKey = Chapter1Data.Root.GetProperty("EVIDENCE").EnumerateObject().First().Name;
                var evidence = (Essence)((IDictionary)Field(session.World, "_evidence"))[evidenceKey]!;
                evidence.Get<SpatialProperty>()!.Space = Space(session, appended.Id);
                ((IDictionary)Field(session.World, "_evidenceRoom"))[evidenceKey] = appended.Id;
                session.ContentSession.Session.Place(evidenceKey, appended.Key);
                runtime.Sync();
                var before = actors.Select(p => Soul(session, p.Id).World.Revision).ToArray();
                var bytes = Value(session.Save());
                check("appended_room_save_does_not_reobserve_or_mutate_live_subjects", actors.Select((p, i) => (p, i)).All(item =>
                    Soul(session, item.p.Id).World.Revision == before[item.i]));
                var directory = Environment.GetEnvironmentVariable("LEARNING_HOST_EVIDENCE");
                if (directory is not null) File.WriteAllBytes(Path.Combine(directory, "room-registration-save.json"), bytes);
                var store = new Chapter1SessionStore(session);
                restored = Value(store.Restore(bytes));
                RegisteredState(restored, appended.Id, appended.Key, check);
                check("appended_room_save_restores_stable_actual_space_identity", Space(restored, appended.Id).Id == Space(session, appended.Id).Id);
                check("appended_room_save_restores_declared_object_room", ((Room)((IDictionary)Field(restored.World, "_evidenceRoom"))[evidenceKey]!) == appended.Id
                    && ReferenceEquals(((Essence)((IDictionary)Field(restored.World, "_evidence"))[evidenceKey]!).Get<SpatialProperty>()!.Space, Space(restored, appended.Id)));
                var epoch = store.RestoreEpoch;
                foreach (var invalid in new[] { -1, declarations.Max(p => (int)p.Id) + 1 })
                {
                    var spacesJson = JsonNode.Parse(bytes)!.AsObject();
                    var spaceRows = spacesJson["morning"]!["spaces"]!.AsObject();
                    spaceRows[invalid.ToString(CultureInfo.InvariantCulture)] = spaceRows[((int)appended.Id).ToString(CultureInfo.InvariantCulture)]!.DeepClone();
                    var rejectedSpace = store.Restore(JsonSerializer.SerializeToUtf8Bytes(spacesJson));
                    check("undeclared_space_number_is_rejected_" + invalid, rejectedSpace is ContractResult<Chapter1Session>.Failure f
                        && f.Error.Path == "spaces" && f.Error.Code == ContractErrorCode.MalformedData);
                    check("rejected_space_keeps_published_session_" + invalid, ReferenceEquals(store.Current, restored) && store.RestoreEpoch == epoch);
                    var evidenceJson = JsonNode.Parse(bytes)!.AsObject();
                    evidenceJson["morning"]!["evidence_rooms"]![evidenceKey] = invalid;
                    var rejectedEvidence = store.Restore(JsonSerializer.SerializeToUtf8Bytes(evidenceJson));
                    check("undeclared_evidence_room_number_is_rejected_" + invalid, rejectedEvidence is ContractResult<Chapter1Session>.Failure f2
                        && f2.Error.Path == "evidence_room" && f2.Error.Code == ContractErrorCode.MalformedData);
                    check("rejected_evidence_room_keeps_published_session_" + invalid, ReferenceEquals(store.Current, restored) && store.RestoreEpoch == epoch);
                }
                Console.WriteLine("OBSERVATION declared-room-registration " + JsonSerializer.Serialize(new
                {
                    roomKey = appended.Key, compatibilityId = (int)appended.Id, legacyEnumNamed = Enum.IsDefined(appended.Id),
                    spaceId = Space(session, appended.Id).Id,
                    subjects = actors.Select(p => new { p.Key, logicalRoom = session.ContentSession.Session.CharacterRooms[p.Key],
                        actualSpace = Body(session, p.Id).Get<SpatialProperty>()!.Space!.Id, ownObservationMatches = OwnObservationMatchesRoom(session, p.Id, appended.Id) })
                }));
            }
            finally { if (restored is not null) Stop(restored); Stop(session); }
        }
    }
    public static int Read(string file)
    {
        Chapter1Session? session = null;
        var failed = false;
        void Check(string name, bool okay) { Console.WriteLine((okay ? "PASS " : "FAIL ") + "fresh_process_" + name); failed |= !okay; }
        try
        {
            session = Value(Chapter1Session.Restore(File.ReadAllBytes(file)));
            foreach (var room in Rooms().Where(p => !Enum.IsDefined(p.Id))) RegisteredState(session, room.Id, room.Key, Check);
            Console.WriteLine(failed ? "ROOM REGISTRATION READ FAILED" : "ROOM REGISTRATION READ COMPLETE");
            return failed ? 1 : 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
        finally { if (session is not null) Stop(session); }
    }
}
