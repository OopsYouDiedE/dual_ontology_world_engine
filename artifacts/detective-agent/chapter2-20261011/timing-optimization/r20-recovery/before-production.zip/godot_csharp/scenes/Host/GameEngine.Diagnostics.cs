public partial class GameEngine
{
    private IDisposable? _corePerformanceSubscription;
    private void EnableCorePerformanceDiagnostics()
    {
        if (!_aiSeat || _corePerformanceSubscription is not null) return;
        _corePerformanceSubscription = DualOntologyWorldEngine.Core.CorePerformance.Subscribe((stage, ms) =>
        {
            if (!_aiSeat) return;
            var prior = _performance.GetValueOrDefault(stage);
            _performance[stage] = (prior.Calls + 1, prior.Total + ms, Math.Max(prior.Max, ms));
        });
    }
    private void DisableCorePerformanceDiagnostics()
    {
        _corePerformanceSubscription?.Dispose();
        _corePerformanceSubscription = null;
    }
    /// <summary>Test measurement side channel; does not construct, dispatch, or observe a game session.</summary>
    public string TakeChapter1DiagnosticsJson()
        => _session?.TakeChapter1DiagnosticsJson()
            ?? "{\"diagnostic\":\"chapter1_execution\",\"version\":1,\"available\":false}";
}
