using System.Collections.Immutable;
using System.Text.Json;
using DualOntologyWorldEngine.Core;
using DualOntologyWorldEngine.Story;

namespace DualOntologyWorldEngine.Awakening;

public sealed partial class MorningWorld
{
    public sealed record MainSubmissionReceipt(string Actor, int Step, string Statement, string Material, string Verdict, int Minute);
    public event Action<MainSubmissionReceipt>? MainSubmissionCompleted;
    private sealed class MainInvestigationProgress
    {
        public int Step = 1;
        public bool Asked;
        public HashSet<string> Examined = new(StringComparer.Ordinal);
        public HashSet<string> Tests = new(StringComparer.Ordinal);
        public List<MainSubmissionReceipt> Receipts = [];
    }
    private readonly Dictionary<string, MainInvestigationProgress> _mainInvestigations = new(StringComparer.Ordinal);
    private readonly Dictionary<string,HashSet<string>> _fieldVisibleSources=new(StringComparer.Ordinal);
    public void ObserveActorVisibleSources(string actor,IReadOnlyList<string> sourceKeys)
    {
        var person=RequiredActor(actor);
        var room=_dailySpaces.FirstOrDefault(p=>ReferenceEquals(p.Value,person.Body.Get<SpatialProperty>()?.Space)).Key;
        if(room is null) {_fieldVisibleSources[person.Actor]=new(StringComparer.Ordinal);return;}
        var declared=MainDeclaration.GetProperty("sources").EnumerateArray().Select(s=>s.GetString()!).ToHashSet(StringComparer.Ordinal);
        var visible=sourceKeys.Where(key=>declared.Contains(key)&&!_destroyed.Contains(key)&&MainSourceRoom(key)==room).ToHashSet(StringComparer.Ordinal);
        _fieldVisibleSources[person.Actor]=visible;
        _runtime.Observe(person.Soul,visible.SelectMany(key=>_runtime.Representations(_evidence[key])),_dailySession.CTB.Now);
    }
    private Func<string,int,string,string,IReadOnlySet<string>,string>? _mainJudge;
    public void BindMainInvestigationJudge(Func<string,int,string,string,IReadOnlySet<string>,string> judge) => _mainJudge = judge;
    public IReadOnlyList<MainSubmissionReceipt> MainSubmissionReceipts => _mainInvestigations.Values.SelectMany(p => p.Receipts).ToArray();
    private void RecordMainInspection(string actor,string evidence) => MainProgress(RequiredActor(actor)).Examined.Add(evidence);
    public bool ActorHasExaminedMainMaterial(string actor,string evidence) => MainProgress(RequiredActor(actor)).Examined.Contains(evidence);
    public IReadOnlySet<string> ActorMainTests(string actor) => MainProgress(RequiredActor(actor)).Tests;
    public void RecordMainExecutionReceipt(string actor, string kind, string source)
    {
        if (kind is not ("test" or "help")) throw new ArgumentException("Unknown investigation receipt kind.");
        if (!_evidence.ContainsKey(source)) throw new ArgumentException("Unknown investigation source.");
        MainProgress(RequiredActor(actor)).Tests.Add(kind == "help" ? "help:" + source : source);
    }
    public bool ActorKnowsMainMaterial(string actor,string key) => ActorSoul(actor).World.Projections.Any(p=>p.Existence==Truth.True
        && AcquiredPropositions.ShowReference(p)==key && p.Rules.Length>0);
    private static JsonElement MainDeclaration => Chapter1Data.Root.GetProperty("PUBLIC_INVESTIGATION");
    private static string MainSourceId(string evidence) => "world:object." + evidence;
    private MainInvestigationProgress MainProgress(DailyPerson person)
    {
        if (!_mainInvestigations.TryGetValue(person.Key, out var progress)) _mainInvestigations[person.Key] = progress = new();
        return progress;
    }
    private bool MainParticipant(DailyPerson person) => MainDeclaration.GetProperty("actors").EnumerateArray().Any(v => v.GetString() == person.Actor);
    private string? MainSourceRoom(string key)
    {
        var visited=new HashSet<Essence>();
        Essence? current=_evidence[key];
        while(current is not null && visited.Add(current))
        {
            if(current.Kind==ProjectionKind.Space) return _dailySpaces.SingleOrDefault(p=>ReferenceEquals(p.Value,current)).Key;
            var spatial=current.Get<SpatialProperty>();
            current=spatial?.Holder??spatial?.Space;
        }
        return null;
    }
    private Projection? MainMaterial(DailyPerson person, string key) => person.Soul.World.Projections.FirstOrDefault(p =>
        p.Existence == Truth.True && p.KnownTerms.Any(t => t.TermId.Value == "acquired.card." + key));
    private Projection? MainReportableMaterial(DailyPerson person,string key)=>person.Soul.World.Projections.FirstOrDefault(p=>
        p.Existence==Truth.True&&p.Tags.GetValueOrDefault(AcquiredPropositions.Presentable)==1&&AcquiredPropositions.ShowReference(p)==key);
    private IEnumerable<SubjectProjectionId> OwnedMainMaterials(DailyPerson person) => person.Soul.World.Projections
        .Where(p => p.Existence == Truth.True && p.Tags.GetValueOrDefault(AcquiredPropositions.Presentable) == 1).Select(p => p.SubjectId!.Value);
    private IEnumerable<MorningSourceHeader> MainSourceHeaders(DailyPerson person, string room)
    {
        foreach (var node in MainDeclaration.GetProperty("sources").EnumerateArray())
        {
            var key = node.GetString()!;
            if(person.Hosted is not null && (!_fieldVisibleSources.TryGetValue(person.Actor,out var visible)||!visible.Contains(key))) continue;
            var known = _runtime.KnownProjection(person.Soul,_evidence[key]);
            var knownRoom = _runtime.KnownProjection(person.Soul,_dailySpaces[room]);
            if (known is null || known.Existence == Truth.False || knownRoom is null) continue;
            var location = known.Parent;
            var visited = new HashSet<Projection>();
            while (location is not null && location.Kind != ProjectionKind.Space && visited.Add(location)) location = location.Parent;
            if (!ReferenceEquals(location,knownRoom)) continue;
            yield return new(MainSourceId(key), room, known.Name, MainExamineId(person,key));
        }
    }
    private IEnumerable<MorningPublicQuestion> MainPublicQuestions(DailyPerson person,string room)
    {
        if (!MainParticipant(person) || !MainSourceHeaders(person,room).Any(h=>h.SourceId==MainSourceId(MainDeclaration.GetProperty("question_source").GetString()!))) yield break;
        if (!_mainInvestigations.TryGetValue(person.Key,out var progress) || !progress.Asked || MainQuestion(progress.Step) is not { } question) yield break;
        yield return new(MainDeclaration.GetProperty("id").GetString()!,_evidence[MainDeclaration.GetProperty("question_source").GetString()!].TrueName,
            question.GetProperty("text").GetString()!,MainDeclaration.GetProperty("statements").EnumerateArray().Select(s=>s.GetProperty("label").GetString()!).ToArray());
    }
    private IEnumerable<SubjectiveMethodScopeV1> MainVisibleScopes(DailyPerson person)
    {
        var here=_dailySpaces.FirstOrDefault(p=>ReferenceEquals(_runtime.KnownProjection(person.Soul,p.Value),person.Self.Parent)).Key;
        if(here is null) yield break;
        foreach(var header in MainSourceHeaders(person,here))
            {
                yield return new(header.SourceId,"main.sources");
                if(header.SourceId==MainSourceId(MainDeclaration.GetProperty("question_source").GetString()!)) yield return new(header.SourceId,"main.form");
            }
    }
    private string MainExamineId(DailyPerson person,string key) => MainSourceId(key) + ":examine:" +
        (key == MainDeclaration.GetProperty("question_source").GetString() && MainParticipant(person)
            ? _mainInvestigations.TryGetValue(person.Key,out var progress) ? progress.Step : 1 : 0);
    private string? AcquiredMainSourceText(DailyPerson person, string sourceId)
    {
        foreach (var node in MainDeclaration.GetProperty("sources").EnumerateArray())
        {
            var key = node.GetString()!;
            if (MainSourceId(key) != sourceId || MainMaterial(person,key) is not { } material) continue;
            var text = material.LastObservation?.Details ?? material.Name;
            if (key == MainDeclaration.GetProperty("question_source").GetString() && MainParticipant(person))
            {
                var progress = MainProgress(person);
                if (progress.Asked && MainQuestion(progress.Step) is { } question) text += "\n" + question.GetProperty("text").GetString();
            }
            return text;
        }
        return null;
    }
    private static JsonElement? MainQuestion(int step) => MainDeclaration.GetProperty("questions").EnumerateArray()
        .Where(q => q.GetProperty("step").GetInt32() == step).Select(q => (JsonElement?)q).SingleOrDefault();
    private FrozenConditionV1? MainProposition(DailyPerson person, string proposition)
    {
        return ActorKnowledge(person.Actor).PropositionCondition(proposition);
    }
    private IEnumerable<FrozenConditionV1> MainGoal(DailyPerson person)
    {
        if (!MainParticipant(person) || !MainProgress(person).Asked || MainQuestion(MainProgress(person).Step) is not { } q) return [];
        return q.GetProperty("propositions").EnumerateArray().Select(p => MainProposition(person,p.GetString()!)).OfType<FrozenConditionV1>();
    }
    private void AddMainInvestigationOffers(DailyPerson person,List<MorningWork> candidates)
    {
        var room = _dailySpaces.Single(p => ReferenceEquals(p.Value,person.Body.Get<SpatialProperty>()?.Space)).Key;
        foreach (var header in MainSourceHeaders(person,room))
        {
            var key = header.SourceId["world:object.".Length..];
            var source = _runtime.KnownProjection(person.Soul,_evidence[key]);
            if (source is null) continue;
            var knowledge = ActorKnowledge(person.Actor);
            knowledge.Acquire("field",key,header.Label,_dailySession.CTB.Now);
            knowledge.BindPublicSource("field",key,header.SourceId,_dailySession.CTB.Now);
            var binding = AcquiredPropositions.Read(Chapter1Data.Root).Bindings.FirstOrDefault(b=>b.Kind=="field"&&b.Key==key);
            var claims = binding is null ? ImmutableArray<FrozenConditionV1>.Empty : binding.Propositions
                .Select(p=>MainProposition(person,p)).OfType<FrozenConditionV1>().ToImmutableArray();
            candidates.Add(new(new(header.OfferId,header.OfferId,header.SourceId,SubjectiveActionKindV1.Observe)
                { ScopeId="main.sources",Materials=[source.SubjectId!.Value],Claims=claims,AcquiresInformation=true,Cost=1,Context=room },
                new(room,key,"examine",header.Label,1,1,[]),new Effect.Act(ActionOp.Inspect,source),MainEvidence:key));
            if (MainReportableMaterial(person,key) is not { } material) continue;
            foreach (var listener in _dailyPeople.Values.Where(p=>!ReferenceEquals(p,person)&&ReferenceEquals(p.Body.Get<SpatialProperty>()?.Space,person.Body.Get<SpatialProperty>()?.Space)))
            {
                var target = _runtime.KnownProjection(person.Soul,listener.Body);
                if (target is null) continue;
                var id=header.SourceId+":report:"+listener.Key;
                candidates.Add(new(new(id,id,header.SourceId,SubjectiveActionKindV1.Observe)
                    { ScopeId="main.sources",Materials=[material.SubjectId!.Value],AcquiresInformation=false,Cost=1,Context=room },
                    new(room,key,"report",header.Label,1,1,[]),new Effect.Say(target,material.Name),Listener:listener.Actor,MainEvidence:key));
            }
        }
        AddMainOperationCandidates(person,room,candidates);
        if (!MainParticipant(person)) return;
        var progress=MainProgress(person);
        var questionSource=MainDeclaration.GetProperty("question_source").GetString()!;
        if (!progress.Asked || MainQuestion(progress.Step) is null || !MainSourceHeaders(person,room).Any(h=>h.SourceId==MainSourceId(questionSource))) return;
        var group="main.question:"+progress.Step;
        var materials=OwnedMainMaterials(person).ToArray();
        foreach(var node in MainDeclaration.GetProperty("statements").EnumerateArray())
        {
            var key=node.GetProperty("id").GetString()!;
            var label=node.GetProperty("label").GetString()!;
            ActorKnowledge(person.Actor).Acquire("statement",key,label,_dailySession.CTB.Now);
            var claims=node.GetProperty("propositions").EnumerateArray().Select(p=>MainProposition(person,p.GetString()!)).OfType<FrozenConditionV1>().ToImmutableArray();
            if(claims.Length!=1) continue;
            var index=Array.FindIndex(MainDeclaration.GetProperty("statements").EnumerateArray().ToArray(),s=>s.GetProperty("id").GetString()==key);
            var id=group+":assert:"+key;
            candidates.Add(new(new(id,id,MainSourceId(questionSource),SubjectiveActionKindV1.Assert)
                { ScopeId="main.form",GroupId=group,Claims=claims,RequiresEvidence=true,Context=room,
                    Selected=person.Self.Tags.TryGetValue(new Tag("main.assertion:"+progress.Step),out var selected)&&selected==index },
                new(room,key,"assert",label,1,1,[]),new Effect.Set(person.Self,new Tag("main.assertion:"+progress.Step),index),MainStep:progress.Step));
        }
        foreach(var id in materials)
        {
            var material=person.Soul.World.Projections.Single(p=>p.SubjectId==id);
            var marker=new Tag("main.presentation:"+progress.Step+":"+id);
            var method=group+":present:"+id;
            candidates.Add(new(new(method,method,MainSourceId(questionSource),SubjectiveActionKindV1.Present)
                { ScopeId="main.form",GroupId=group,Materials=[id],Presentable=true,Context=room,Selected=person.Self.Tags.GetValueOrDefault(marker)==1 },
                new(room,questionSource,"present",material.Name,1,1,[]),new Effect.Set(person.Self,marker,1),MainStep:progress.Step));
        }
        var commit=group+":submit";
        candidates.Add(new(new(commit,commit,MainSourceId(questionSource),SubjectiveActionKindV1.Commit)
            { ScopeId="main.form",GroupId=group,Materials=ActorAgency(person.Actor).Evidence,RequiresEvidence=true,Context=room,Cost=1 },
            new(room,questionSource,"submit",MainQuestion(progress.Step)!.Value.GetProperty("text").GetString()!,1,1,[]),
            new Effect.Set(person.Self,new Tag("main.submission:"+progress.Step),1),MainStep:progress.Step));
    }
    private bool CompleteMainInvestigation(DailyPerson person,out bool information)
    {
        information=false;
        var work=person.Work!;
        if(work.Step.Room!=_dailySpaces.Single(p=>ReferenceEquals(p.Value,person.Body.Get<SpatialProperty>()?.Space)).Key) return false;
        if(work.MainOperation.Length>0) return CompleteMainOperation(person,out information);
        if(work.Step.Action=="examine")
        {
            information=ExamineActor(person.Actor,work.MainEvidence);
            if(work.MainEvidence==MainDeclaration.GetProperty("question_source").GetString() && MainParticipant(person))
            {
                var progress=MainProgress(person);
                if(!progress.Asked && MainQuestion(progress.Step) is { } q)
                {
                    ActorKnowledge(person.Actor).Acquire("question",q.GetProperty("line").GetString()!,q.GetProperty("text").GetString()!,
                        _dailySession.CTB.Now,q.GetProperty("speaker").GetString()!);
                    progress.Asked=true; information=true;
                }
            }
            return information;
        }
        if(work.Step.Action=="report") return ReportMainMaterial(person,work.MainEvidence,work.Listener);
        if(work.Step.Action is "assert" or "present") return true;
        if(work.Step.Action!="submit" || work.Statement is null || work.Proof is not {Value:Truth.True,Complete:true,Contradicted:false,Hypothetical:false}
            || work.Evidence.IsDefaultOrEmpty || _mainJudge is null) return false;
        var owned=OwnedMainMaterials(person).ToHashSet();
        if(!work.Evidence.All(owned.Contains) || !work.Proof.Basis.Any(owned.Contains)) return false;
        var statement=MainDeclaration.GetProperty("statements").EnumerateArray().FirstOrDefault(s=>s.GetProperty("propositions").EnumerateArray()
            .Select(p=>MainProposition(person,p.GetString()!)).OfType<FrozenConditionV1>().Any(c=>MorningContract(Ast.Equivalent(c,work.Statement))));
        if(statement.ValueKind==JsonValueKind.Undefined) return false;
        var material=work.Evidence.Select(id=>person.Soul.World.Projections.Single(p=>p.SubjectId==id))
            .Where(p=>work.Proof.Basis.Contains(p.SubjectId!.Value)).Select(AcquiredPropositions.ShowReference).FirstOrDefault(reference=>reference is not null);
        if(material is null) return false;
        var current=MainProgress(person);
        var said=statement.GetProperty("id").GetString()!;
        var verdict=_mainJudge(person.Actor,current.Step,said,material,current.Tests);
        var receipt=new MainSubmissionReceipt(person.Actor,current.Step,said,material,verdict,_dailySettledMinutes);
        current.Receipts.Add(receipt);
        if(verdict=="answer_ok"+current.Step || verdict=="answer_rescue") {current.Step++;current.Asked=false;}
        MainSubmissionCompleted?.Invoke(receipt);
        return verdict=="answer_ok"+work.MainStep || verdict=="answer_rescue";
    }
    private bool ReportMainMaterial(DailyPerson person,string key,string listenerActor)
    {
        var listener=RequiredActor(listenerActor);
        if(MainReportableMaterial(person,key) is not { } material || !ReferenceEquals(person.Body.Get<SpatialProperty>()?.Space,listener.Body.Get<SpatialProperty>()?.Space)) return false;
        var declaration=AcquiredPropositions.Read(Chapter1Data.Root);
        var speaker=_runtime.KnownProjection(listener.Soul,person.Body);
        if(speaker is null) return false;
        var identity=person.Actor+":"+key;
        string? Proposition(Condition condition)
        {
            var negative=condition is Condition.Not;
            var fact=negative ? ((Condition.Not)condition).Operand : condition;
            if(fact is not Condition.Tagged {Target:Noun.Reference reference,Tag:var tag}||tag!=new Tag("Asserted")) return null;
            var term=reference.Projection.KnownTerms.FirstOrDefault(t=>t.TermId.Value.StartsWith("acquired.atom.",StringComparison.Ordinal));
            return term is null ? null : (negative ? "!" : "")+term.TermId.Value["acquired.atom.".Length..];
        }
        var propositions=material.Rules.Where(r=>r.Mode==RuleMode.Infer&&r.Condition is Condition.Constant {Value:Truth.True})
            .Select(r=>r.Effect is Effect.Think thought ? Proposition(thought.Fact) : null).OfType<string>().Distinct().ToList();
        if(propositions.Count==0) return false;
        declaration.Bindings.Add(new(){Kind="testimony",Key=identity,Source="testimony",Speaker=speaker.Name,ShowReference=key,
            Act="assert",Reliability=material.Tags.GetValueOrDefault(AcquiredPropositions.Reliability),Propositions=propositions});
        new AcquiredPropositions(declaration,listener.Soul).Acquire("testimony",identity,material.Name,_dailySession.CTB.Now,speaker.Name,
            perceivedSpeaker:speaker,trust:Math.Clamp(speaker.Tags.GetValueOrDefault(Tags.Trust)*100/3,0,100));
        return true;
    }
}
