using DualOntologyWorldEngine.Core;
using DualOntologyWorldEngine.Story;

namespace DualOntologyWorldEngine.Awakening;

public sealed partial class MorningWorld
{
    private AcquiredPropositions ActorKnowledge(string actor) => new(
        AcquiredPropositions.Read(Chapter1Data.Root), ActorSoul(actor));

    /// <summary>Completes an actual local examination for any registered subject.
    /// New information compares this acquired source and visible material state,
    /// not unrelated cognition revisions or the number of observations.</summary>
    public bool ExamineActor(string actor, string evidence)
    {
        var person = RequiredActor(actor);
        if (!_evidence.TryGetValue(evidence, out var essence) || _destroyed.Contains(evidence)) return false;
        var previous = _runtime.KnownProjection(person.Soul, essence);
        // This is a real execution receipt, never a candidate-information lookup.
        var physicalTarget = previous ?? _runtime.Representations(essence).FirstOrDefault();
        if (physicalTarget is null || !new ActionRuntime(_runtime).CanInspect(person.Soul, person.Self, physicalTarget)) return false;
        var previousExistence = previous?.Existence;
        var previousParent = previous?.Parent?.SubjectId;
        var visibleTags = essence.Get<StateProperty>()?.Observable ?? [];
        var previousTags = visibleTags.ToDictionary(t => t,
            t => previous is not null && previous.Tags.TryGetValue(t, out var value) ? (int?)value : null);
        var sourceTerm = "acquired.card." + evidence;
        var acquired = person.Soul.World.Projections.Any(p => p.KnownTerms.Any(t => t.TermId.Value == sourceTerm));
        _runtime.Observe(person.Soul, _runtime.Representations(essence), ++_time);
        var known = _runtime.KnownProjection(person.Soul, essence)!;
        var changed = previous is null || previousExistence != known.Existence || previousParent != known.Parent?.SubjectId
            || visibleTags.Any(t => previousTags[t] != (known.Tags.TryGetValue(t, out var value) ? (int?)value : null));
        var entry = Chapter1Data.Root.GetProperty("EVIDENCE").GetProperty(evidence);
        var facts = entry.GetProperty("facts").GetString()!;
        Observation.Observe(person.Soul, new(known.Name, known.Kind) { Target = known,
            Source = ObservationSource.Perception, Time = _time, Details = facts });
        ActorKnowledge(actor).Acquire("card", evidence, facts, _time, physicalSource: known);
        RecordMainInspection(actor, evidence);
        var nowAcquired = person.Soul.World.Projections.Any(p => p.KnownTerms.Any(t => t.TermId.Value == sourceTerm));
        return !acquired && nowAcquired || changed;
    }

    public bool CompleteActorRecall(string actor, string evidence)
    {
        var person = RequiredActor(actor);
        if (!Chapter1Data.Root.GetProperty("EVIDENCE").TryGetProperty(evidence, out var entry)
            || !entry.TryGetProperty("recall", out var owner) || owner.GetString() != person.Actor
            || !_evidence.TryGetValue(evidence, out var entity) || _destroyed.Contains(evidence)) return false;
        var target = _runtime.KnownProjection(person.Soul, entity);
        if (target is null || !new ActionRuntime(_runtime).CanInspect(person.Soul, person.Self, target)) return false;
        var memory = Memories.FirstOrDefault(m => m.Evidence == evidence && Names.PersonKeys[(int)m.Who] == person.Actor);
        if (memory is null || HasRecalled(memory.Who)) return false;
        return Recall(evidence) is not null;
    }

    public FrozenConditionV1? ChapterClaim(string actor, string question, string option)
    {
        var variable = Chapter1Data.Root.GetProperty("VARIABLES").EnumerateArray()
            .FirstOrDefault(v => v.GetProperty("key").GetString() == question);
        if (variable.ValueKind == System.Text.Json.JsonValueKind.Undefined) return ActorClaim(actor, question, option);
        var index = Array.IndexOf(variable.GetProperty("options").EnumerateArray().Select(v => v.GetString()).ToArray(), option);
        if (index < 0) return null;
        var declaration = AcquiredPropositions.Read(Chapter1Data.Root);
        var binding = declaration.Bindings.FirstOrDefault(b => b.Kind == "statement" && b.Key == question + "_" + index);
        if (binding?.Propositions.Count != 1) return null;
        var key = binding.Propositions[0];
        return new AcquiredPropositions(declaration, ActorSoul(actor)).PropositionCondition(key);
    }

    // The caller supplies an actually delivered line and its declared source ID.
    public void AcquireActorLine(string actor, string lineId, string text, string speaker)
    {
        var knowledge = ActorKnowledge(actor);
        var listenerSoul = ActorSoul(actor);
        var speakerActor = _dailyPeople.Values.FirstOrDefault(p => p.Body.TrueName == speaker);
        Projection? perceived = null;
        var trust = 100;
        if (speakerActor is not null)
        {
            perceived = _runtime.KnownProjection(listenerSoul, speakerActor.Body);
            trust = ReferenceEquals(listenerSoul, speakerActor.Soul) ? 100
                : perceived is null ? 0 : Math.Clamp(perceived.Tags.GetValueOrDefault(Tags.Trust) * 100 / 3, 0, 100);
        }
        knowledge.Acquire("line", lineId, text, _time, speaker, perceivedSpeaker: perceived, trust: trust);
        knowledge.Acquire("question", lineId, text, _time, speaker);
    }
}
