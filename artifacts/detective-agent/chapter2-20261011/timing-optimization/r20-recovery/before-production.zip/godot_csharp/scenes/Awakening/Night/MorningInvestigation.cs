using System.Collections.Immutable;
using System.Text.Json;
using DualOntologyWorldEngine.Core;
using DualOntologyWorldEngine.Story;

namespace DualOntologyWorldEngine.Awakening;

public sealed record MorningSourceHeader(string SourceId, string Room, string Label, string OfferId);
public sealed record MorningPublicQuestion(string CaseId, string Title, string Question, IReadOnlyList<string> Options);

public sealed record MorningSourceOffer(string Id, string SourceId, string Room, string Label, string Action, SubjectiveOfferV1 Semantic, string ListenerName = "");

public sealed partial class MorningWorld
{
    public sealed record DormCaseResult(string Case, string Dorm, string Answer, int Minute, IReadOnlyList<string> Beliefs);
    private sealed record DormTrace(string Key, string Text, string SourceId, string Label, string Room, string Action,
        int Question, int Option, bool Negate, int Value, Essence Entity);
    private sealed record DormInference(int Question, int Option, (string SourceId, int Value)[] When);
    private sealed record DormSubmission(int Option, SubjectProjectionId[] Evidence, int Minute);
    private sealed class DormCase
    {
        public required string Id, Dorm, Title, ExamineAction, ExchangeAction, SubmitAction, Acceptance;
        public required CaseModel Model;
        public required int Answer;
        public required DormTrace[] Traces;
        public required DormInference[] Inference;
        public int EarliestOut;
        public bool Answered;
        public Dictionary<string, DormSubmission> Submissions = new(StringComparer.Ordinal);
    }
    private sealed record MorningWork(SubjectiveOfferV1 Offer, DailyStep Step, Effect Effect, int? StepIndex = null,
        DormCase? Case = null, DormTrace? Trace = null, string Listener = "", int Option = -1,
        FrozenConditionV1? Statement = null, ImmutableArray<SubjectProjectionId> Evidence = default,
        SubjectiveProofV1? Proof = null, string MainEvidence = "", int MainStep = 0, bool Travels = false, string MainOperation = "")
    { public bool Investigating => Case is not null || MainEvidence.Length > 0 || MainStep > 0 || MainOperation.Length>0; }
    private static readonly Tag Trace = new("所见");
    private static Tag TraceValue(int value) => new("case-observation:value:" + value);
    private readonly Dictionary<string, DormCase> _dormCases = new(StringComparer.Ordinal);
    private readonly List<DormCaseResult> _dormResults = [];
    private readonly Dictionary<string, int> _dormOpened = new(StringComparer.Ordinal);
    public IReadOnlyList<DormCaseResult> DormCaseResults => _dormResults;
    public IReadOnlyDictionary<string, int> DormOpenedMinutes => _dormOpened;
    public bool DormIsOpen(string name) => _dormOpened.Keys.Any(dorm => dorm == name || _dailySpaces[dorm].TrueName == name);
    public IEnumerable<string> MorningActors => _dailyPeople.Values.Select(p => p.Actor);
    public IEnumerable<string> FieldMorningActors => _dailyPeople.Values.Where(p => p.Hosted is not null || p.FieldResident).Select(p => p.Actor);
    public IReadOnlyDictionary<string, Essence> InvestigationSources => _dormCases.Values.SelectMany(c => c.Traces)
        .ToDictionary(t => t.SourceId, t => t.Entity, StringComparer.Ordinal);

    private static readonly Lazy<IReadOnlyList<ActorControllerDefinition>> MorningControllers = new(() =>
    {
        using var stream = typeof(MorningWorld).Assembly.GetManifestResourceStream("Awakening.World.json")!;
        using var reader = new StreamReader(stream);
        return PlayerControllers.Read(reader.ReadToEnd());
    });
    private ActorControllerDefinition? ControllerOf(DailyPerson person) => MorningControllers.Value
        .FirstOrDefault(c => c.Actor == "world:person." + person.Key);
    private static T MorningContract<T>(ContractResult<T> result) => result switch
    {
        ContractResult<T>.Success success => success.Value,
        ContractResult<T>.Failure failure => throw new InvalidOperationException(failure.Error.ToString()),
        _ => throw new InvalidOperationException("Unknown cognition contract result.")
    };
    public ReasoningBudgetV1 ActorReasoningBudget(string actor)
    {
        var person = RequiredActor(actor);
        var declared = ControllerOf(person)?.Reasoning;
        return declared is null ? new() : new(declared.Depth, declared.Expansions, declared.Hypotheses);
    }
    public SubjectiveAgentState ActorAgency(string actor)
    {
        var person = RequiredActor(actor);
        return person.Agency ??= new(person.Self.SubjectId!.Value) { Memory = ActionLearning.Capture(person.Soul.World, person.Self) };
    }
    public PlayerCognition CaptureActorCognition(string actor)
    {
        var person = RequiredActor(actor);
        return new(MorningContract(person.Soul.World.CaptureSnapshot()), person.Self.SubjectId!.Value) { Agency = ActorAgency(actor) };
    }
    public FrozenConditionV1? ActorClaim(string actor, string question, string option)
    {
        var person = RequiredActor(actor);
        var suffix = ":" + question + "=" + option;
        var known = person.Soul.World.Projections.Where(p => p.Name.EndsWith(suffix, StringComparison.Ordinal)).ToArray();
        return known.Length == 1 ? new FrozenConditionV1.Exists(new FrozenNounV1.Reference(known[0].SubjectId!.Value)) : null;
    }
    private SoulEssence ActorSoul(string actor) => RequiredActor(actor).Soul;
    private DailyPerson RequiredActor(string actor) => DailyActor(actor)
        ?? _dailyPeople.GetValueOrDefault(actor.Replace("world:person.", "", StringComparison.Ordinal))
        ?? throw new ArgumentException("Unknown morning actor: " + actor);
    private DailyStep CurrentDailyStep(DailyPerson person) => person.Work?.Step ?? person.Steps[person.Index];
    private bool CanInvestigate(DailyPerson person) => _dormCases.TryGetValue(person.Dorm, out var c) && !c.Answered && !person.Departed;

    private void InitializeDormCases()
    {
        if (!Chapter1Data.Root.TryGetProperty("DORM_CASES", out var cases)) return;
        foreach (var item in cases.EnumerateObject())
        {
            var authored = CaseVariants.Variant(item.Name, item.Value, CaseVariants.Seed);
            var questions = authored.GetProperty("questions").EnumerateArray().ToArray();
            var traces = authored.GetProperty("traces").EnumerateArray().Select(t =>
            {
                var room = t.GetProperty("source_room").GetString()!;
                var id = t.GetProperty("source_id").GetString()!;
                if (!_dailySpaces.TryGetValue(room, out var space) || room != authored.GetProperty("dorm").GetString()
                    || _dormCases.Values.SelectMany(c => c.Traces).Any(p => p.SourceId == id))
                    throw new InvalidDataException("Invalid investigation source binding: " + id);
                var key = t.GetProperty("key").GetString()!;
                // A coarse source has an explicit room, not an inferred furniture position.
                // Its observable facade contains no fact until an actual examination completes.
                var label = t.GetProperty("source_label").GetString()!;
                var entity = new Essence(label, ProjectionKind.Object);
                entity.Add(new SpatialProperty { Space = space });
                _runtime.Project(entity, label);
                return new DormTrace(key, t.GetProperty("text").GetString()!, id, label, room, t.GetProperty("action").GetString()!,
                    t.GetProperty("question").GetInt32(), t.GetProperty("option").GetInt32(), t.GetProperty("negate").GetBoolean(),
                    authored.GetProperty("true_facts").GetProperty(key).GetInt32(), entity);
            }).ToArray();
            var inference = authored.GetProperty("inference").EnumerateArray().Select(r => new DormInference(
                r.GetProperty("question").GetInt32(), r.GetProperty("option").GetInt32(),
                r.GetProperty("when").EnumerateArray().Select(p => (p.GetProperty("source_id").GetString()!, p.GetProperty("value").GetInt32())).ToArray())).ToArray();
            var model = new CaseModel(item.Name, questions.Select(q => q.GetProperty("key").GetString()!),
                questions.Select(q => q.GetProperty("options").EnumerateArray().Select(o => o.GetString()!)),
                traces.Select(t => new CaseField(t.Key, Trace, t.Key)),
                authored.GetProperty("hypotheses").EnumerateArray().Select(h => new CaseHypothesis(
                    [..h.GetProperty("options").EnumerateArray().Select(o => o.GetInt32())],
                    h.GetProperty("facts").EnumerateObject().ToImmutableDictionary(f => f.Name, f => f.Value.GetInt32()))));
            var c = new DormCase { Id = item.Name, Dorm = authored.GetProperty("dorm").GetString()!, Title = authored.GetProperty("title").GetString()!,
                Model = model, Answer = authored.GetProperty("answer").GetInt32(), Traces = traces, Inference = inference,
                ExamineAction = authored.GetProperty("examine_action").GetString()!, ExchangeAction = authored.GetProperty("exchange_action").GetString()!,
                SubmitAction = authored.GetProperty("submit_action").GetString()!, Acceptance = authored.GetProperty("acceptance").GetString()!,
                EarliestOut = authored.TryGetProperty("earliest_out", out var earliest) && earliest.ValueKind == JsonValueKind.Object
                    ? (earliest.GetProperty("day").GetInt32() - 2) * 1440 + earliest.GetProperty("minutes").GetInt32() : 0 };
            if (c.ExamineAction != "examine" || c.ExchangeAction != "report" || c.SubmitAction != "submit"
                || c.Acceptance != "submitted_majority_with_evidence" || traces.Any(t => t.Action != c.ExamineAction))
                throw new InvalidDataException("Unsupported explicit investigation contract.");
            _dormCases.Add(c.Dorm, c);
            foreach (var prior in authored.GetProperty("priors").EnumerateArray())
            {
                if (!_dailyPeople.TryGetValue(prior.GetProperty("person").GetString()!, out var person)) continue;
                var question = prior.GetProperty("question").GetInt32();
                var strength = Persona.Overrides.TryGetValue($"{person.Soul.TrueName}.先入之见.{model.Questions[question]}", out var forced)
                    ? (int)Math.Round(forced) : prior.GetProperty("strength").GetInt32();
                if (strength <= 0) continue;
                Observation.Observe(person.Soul, new(model.ClaimName(question, prior.GetProperty("option").GetInt32()), ProjectionKind.Concept)
                { Source = ObservationSource.Introspection, Existence = Truth.True,
                    Tags = ImmutableDictionary<Tag, int?>.Empty.Add(Tags.Confidence, strength) });
            }
        }
        ObserveDailyRooms();
    }

    private Projection? DormMaterial(DailyPerson person,DormTrace trace,bool create=false)
    {
        var term="investigation.material."+trace.SourceId;
        var known=person.Soul.World.Projections.FirstOrDefault(p=>p.KnownTerms.Any(t=>t.TermId.Value==term));
        if(known is not null || !create) return known;
        var source=_runtime.KnownProjection(person.Soul,trace.Entity)
            ?? throw new InvalidOperationException("Investigation source is not perceived.");
        return Observation.Observe(person.Soul,new(trace.Label,ProjectionKind.Concept)
        {Source=ObservationSource.Perception,Existence=Truth.Unknown,Time=_dailySession.CTB.Now,
            KnownTerms=[new(new(term),term,term)],AddRelations=[(new RelationTag("SourceObject"),source)]});
    }
    private void ObserveDormProblem(DailyPerson person)
    {
        var here = person.Body.Get<SpatialProperty>()!.Space;
        foreach (var c in _dormCases.Values.Where(c => ReferenceEquals(here, _dailySpaces[c.Dorm])))
        {
            if (person.Soul.World.Projections.Any(p => p.Name == c.Model.ConceptName(c.Answer))) continue;
            var options = c.Model.Options.Select((items, q) => items.Select((_, o) =>
            {
                var name = c.Model.ClaimName(q, o);
                return person.Soul.World.Projections.SingleOrDefault(p => p.Name == name)
                    ?? Observation.Observe(person.Soul, new(name, ProjectionKind.Concept)
                    { Source = ObservationSource.Perception, Existence = Truth.Unknown });
            }).ToArray()).ToArray();
            var sources = c.Traces.ToDictionary(t => t.SourceId, t => DormMaterial(person,t,true)!, StringComparer.Ordinal);
            var rules = c.Inference.Select(r => new Rule(new Condition.All([..r.When.Select(w =>
                    (Condition)new Condition.Tagged(sources[w.SourceId], TraceValue(w.Value), 1))]), RuleMode.Infer,
                new Effect.Think(new Condition.Exists(options[r.Question][r.Option])), Acceptance: Truth.True)).ToImmutableArray();
            Observation.Observe(person.Soul, new(c.Model.ConceptName(c.Answer), ProjectionKind.Concept)
            { Source = ObservationSource.Perception, Existence = Truth.True, Details = c.Title, Rules = rules });
        }
    }

    private SubjectiveAgentMotivesV1 MotivesOf(DailyPerson person)
    {
        var declared = ControllerOf(person);
        return declared is null ? new() : new(
            declared.Rules.Where(r => r.Mode == "prefer" && r.Kind == "untried").Sum(r => r.Weight),
            declared.Reasoning.InformationWeight, declared.Reasoning.ArgumentWeight);
    }
    private readonly Dictionary<Projection, (KnowledgeRevision Revision, IReadOnlyList<DecisionAssessment> Values)> _morningRuleAssessments = [];
    private IReadOnlyList<DecisionAssessment> MorningRuleAssessments(DailyPerson person)
    {
        if (!person.Soul.World.Contains(person.Self)) throw new InvalidOperationException("Foreign morning actor.");
        var revision = person.Soul.World.Revision;
        if (_morningRuleAssessments.TryGetValue(person.Self, out var cached) && cached.Revision == revision) return cached.Values;
        var values = DecisionSystem.Assess(person.Soul.World, person.Self);
        _morningRuleAssessments[person.Self] = (revision, values);
        return values;
    }
    private List<MorningWork> PrepareMorningOffers(DailyPerson person)
    {
        using var performance = CorePerformance.Begin("morning.prepare_offers");
        var candidates = new List<MorningWork>();
        AddInvestigationOffers(person, candidates);
        AddMainInvestigationOffers(person, candidates);
        AddMorningTravelOffers(person,candidates);
        StrategyPolicy.Bind(person.Soul, person.Self, StrategiesFor(person.Key),
            candidates.Select(c => new StrategyMethod(c.Offer.Id, c.Effect, new Condition.Constant(Truth.True),
                c.Step.Action == "travel" ? "travel" : c.Step.Action == "report" ? "listen" : "check")).ToArray(),
            "investigation-strategy", _dailySession.CTB.Now, "awakening");
        foreach (var raw in MorningRuleAssessments(person))
        {
            var index = Array.FindIndex(person.Effects, e => Ast.Equivalent(raw.Decision.Effect, e));
            if (index < 0)
            {
                for (var i = 0; i < candidates.Count; i++)
                    if (Ast.Equivalent(candidates[i].Effect, raw.Decision.Effect))
                        candidates[i] = candidates[i] with { Offer = candidates[i].Offer with {
                            RuleScore = raw.Decision.Score, Forbidden = raw.Forbidden, RuleBasis = [..raw.Reasons] } };
                continue;
            }
            var step = person.Steps[index];
            var effect = raw.Decision.Effect;
            if (step.Action == "check" && _evidence.TryGetValue(step.Target, out var entity)
                && _dailySpaces.TryGetValue(step.Room, out var targetRoom)
                && ReferenceEquals(entity.Get<SpatialProperty>()?.Space, targetRoom)
                && _runtime.KnownProjection(person.Soul, entity) is { } knownSource)
                effect = new Effect.Sequence([effect, new Effect.Act(ActionOp.Inspect, knownSource)]);
            var adapted=AdaptMorningTravel(person,step,effect);
            effect=adapted.Effect;
            var semantic = ActionLearning.EffectOffer(person.Soul.World, person.Self,
                raw with { Decision = raw.Decision with { Effect = effect } }, "daily:" + index,
                "daily:" + step.Room + ":" + step.Target, "daily");
            candidates.Add(new(semantic with {Forbidden=semantic.Forbidden||adapted.Forbidden}, step, effect, index,Travels:adapted.Travels));
        }
        return candidates;
    }
    private SubjectiveAgentRequestV1 MorningRequest(DailyPerson person, IReadOnlyList<MorningWork> candidates)
    {
        var cognition = CaptureActorCognition(person.Actor);
        var claims = candidates.Where(c => c.Case is not null && c.Offer.Kind == SubjectiveActionKindV1.Assert).SelectMany(c => c.Offer.Claims)
            .Concat(MainGoal(person)).ToImmutableArray();
        var visibleScopes = candidates.Select(c => new SubjectiveMethodScopeV1(c.Offer.SourceId, c.Offer.ScopeId))
            .Concat(_dormCases.Values.Where(c => ReferenceEquals(person.Body.Get<SpatialProperty>()!.Space, _dailySpaces[c.Dorm])).SelectMany(c =>
            {
                var scope = "case:" + c.Id + ":" + c.Model.Questions[c.Answer];
                return c.Traces.Select(t => t.SourceId).Append(scope).Select(id => new SubjectiveMethodScopeV1(id, scope));
            }))
            .Concat(ActorAgency(person.Actor).KnownMethods.Where(o => o.ScopeId == "daily")
                .Select(o => new SubjectiveMethodScopeV1(o.SourceId, o.ScopeId))).Concat(MainVisibleScopes(person)).Distinct().ToImmutableArray();
        return new(cognition.Snapshot, cognition.Actor, ActorReasoningBudget(person.Actor), [..candidates.Select(c => c.Offer)], MotivesOf(person))
        { Goal = claims.Length == 0 ? null : new FrozenConditionV1.Any(claims), CompleteMethodScopes = visibleScopes,
            PresentableMaterials = [.._dormCases.Values.SelectMany(c => OwnedCaseMaterials(person, c)).Concat(OwnedMainMaterials(person)).Distinct()] };
    }
    private (MorningWork Work, SubjectiveOfferAssessmentV1 Assessment)? ChooseMorningWork(DailyPerson person,
        IReadOnlyList<MorningWork>? offered = null, string? selectedId = null)
    {
        var agency = ActorAgency(person.Actor);
        var candidates = offered ?? PrepareMorningOffers(person);
        if (candidates.Count == 0) return null;
        var request = MorningRequest(person, candidates);
        var statement = agency.Statement;
        var evidence = agency.Evidence;
        // The actual public form selections can restore commitments after a player
        // seat has already selected Commit with this same Agent state.
        var selectedClaim = request.Offers.FirstOrDefault(o => o.Kind == SubjectiveActionKindV1.Assert && o.Selected);
        if (selectedClaim?.Claims is { Length: 1 }) statement = selectedClaim.Claims[0];
        var selectedMaterial = request.Offers.FirstOrDefault(o => o.Kind == SubjectiveActionKindV1.Present && o.Selected);
        if (selectedMaterial is not null) evidence = selectedMaterial.Materials;
        var choice = selectedId is null ? SubjectiveAgent.Decide(request, agency) : SubjectiveAgent.Select(request, agency, selectedId);
        var selected = candidates.FirstOrDefault(c => c.Offer.Id == choice.OfferId);
        if (selected is null) return null;
        var assessed = choice.Assessment.Offers.Single(o => o.Offer.Id == selected.Offer.Id);
        if (selected.Offer.Kind == SubjectiveActionKindV1.Commit)
        {
            var proof = statement is null ? null : assessed.Arguments.FirstOrDefault(p => MorningContract(Ast.Equivalent(p.Proposition, statement)));
            selected = selected with { Statement = statement, Evidence = evidence, Proof = proof };
        }
        return (selected, assessed);
    }
    public IReadOnlyList<MorningSourceHeader> AvailableSourceHeaders(string actor, string actualRoom)
    {
        var person = RequiredActor(actor);
        if (!_dailySpaces.TryGetValue(actualRoom, out var room) || !ReferenceEquals(person.Body.Get<SpatialProperty>()!.Space, room)) return [];
        return _dormCases.Values.Where(c => c.Dorm == actualRoom).SelectMany(c => c.Traces.Select(t =>
            new MorningSourceHeader(t.SourceId, t.Room, t.Label, t.SourceId + ":" + c.ExamineAction)))
            .Concat(MainSourceHeaders(person, actualRoom)).ToArray();
    }
    public IReadOnlyList<MorningPublicQuestion> AvailableInvestigationQuestions(string actor, string actualRoom)
    {
        var person = RequiredActor(actor);
        if (!_dailySpaces.TryGetValue(actualRoom, out var room) || !ReferenceEquals(person.Body.Get<SpatialProperty>()!.Space, room)) return [];
        return _dormCases.Values.Where(c => c.Dorm == actualRoom).Select(c =>
            new MorningPublicQuestion(c.Id, c.Title, c.Model.Questions[c.Answer], c.Model.Options[c.Answer]))
            .Concat(MainPublicQuestions(person,actualRoom)).ToArray();
    }
    public string? AcquiredSourceText(string actor, string sourceId)
    {
        var person = RequiredActor(actor);
        var trace = _dormCases.Values.SelectMany(c => c.Traces).SingleOrDefault(t => t.SourceId == sourceId);
        return trace is not null && HasTrace(person, trace) ? trace.Text : AcquiredMainSourceText(person, sourceId);
    }
    public SubjectiveAgentRequestV1 CaptureInvestigationRequest(string actor)
    {
        var person = RequiredActor(actor);
        return MorningRequest(person, PrepareMorningOffers(person));
    }
    public IReadOnlyList<MorningSourceOffer> InvestigationOffers(string actor)
        => PrepareMorningOffers(RequiredActor(actor)).Where(w => w.Investigating).Select(w =>
            new MorningSourceOffer(w.Offer.Id, w.Offer.SourceId, w.Step.Room,
                w.Option >= 0 && w.Case is not null ? w.Case.Model.Options[w.Case.Answer][w.Option]
                    : w.Offer.Kind == SubjectiveActionKindV1.Present && w.Offer.Materials.Length == 1
                        ? RequiredActor(actor).Soul.World.Projections.Single(p => p.SubjectId == w.Offer.Materials[0]).Name
                        : w.Step.Note,
                w.Step.Action, w.Offer, string.IsNullOrEmpty(w.Listener) ? ""
                    : _runtime.KnownProjection(RequiredActor(actor).Soul, RequiredActor(w.Listener).Body)?.Name ?? "")).ToArray();
    public bool SelectInvestigation(string actor, string offerId)
        => SelectMorningWork(actor,offerId,false);
    public bool SelectMorningTravel(string actor,string offerId)
        => SelectMorningWork(actor,offerId,true);
    private bool SelectMorningWork(string actor,string offerId,bool travel)
    {
        var person = RequiredActor(actor);
        if (_dailyClosed || person.Execution is not null || person.Serial != 0
            || person.Hosted is { } hosted && StoryBusy(hosted)) return false;
        var candidates = PrepareMorningOffers(person);
        if (!candidates.Any(w => (travel ? w.Step.Action=="travel" : w.Investigating) && w.Offer.Id == offerId)) return false;
        var selected = ChooseMorningWork(person, candidates, offerId);
        if (selected is null) return false;
        person.Work = selected.Value.Work;
        person.ExternalWork = true;
        person.Serial = ++_dailySerial;
        person.Remaining = 1;
        MorningFeedback(person, "contact-started", DecisionOutcomeV1.Attempted);
        _dailyDecisions.Add(new(_dailySession.CTB.Now, person.Key, "selected", person.Serial, person.Work.Step.Room,
            person.Work.Step.Action, selected.Value.Assessment.Score, selected.Value.Assessment.Basis, _dailySettledMinutes));
        return true;
    }
    public bool InvestigationRunning(string actor)
    {
        var person = RequiredActor(actor);
        return person.ExternalWork && person.Work?.Investigating == true && person.Serial != 0;
    }
    public bool ContactInvestigation(string actor, string room)
    {
        var person = RequiredActor(actor);
        return person.Work?.Investigating == true && person.ExternalWork && DailyArrive(person.Actor, person.Serial, room);
    }
    private IEnumerable<SubjectProjectionId> OwnedCaseMaterials(DailyPerson person, DormCase c)
    {
        foreach (var trace in c.Traces)
        {
            if (DormMaterial(person,trace) is { } source && source.Tags.ContainsKey(Trace))
                yield return source.SubjectId!.Value;
            foreach (var testimony in person.Soul.World.Projections.Where(p => p.Existence == Truth.True
                && p.Tags.GetValueOrDefault(new Tag("case-material-source:" + trace.SourceId)) == 1))
                yield return testimony.SubjectId!.Value;
        }
    }
    private void AddInvestigationOffers(DailyPerson person, List<MorningWork> candidates)
    {
        var here = person.Body.Get<SpatialProperty>()!.Space;
        foreach (var c in _dormCases.Values.Where(c => ReferenceEquals(here, _dailySpaces[c.Dorm])))
        {
            ObserveDormProblem(person);
            var group = "case:" + c.Id + ":" + c.Model.Questions[c.Answer];
            var agency = ActorAgency(person.Actor);
            foreach (var trace in c.Traces)
            {
                var source = _runtime.KnownProjection(person.Soul, trace.Entity);
                if (source is null) continue;
                var knowledgeMaterial = DormMaterial(person,trace,true)!;
                var method = trace.SourceId + ":" + c.ExamineAction;
                candidates.Add(Work(new(method, method, trace.SourceId, SubjectiveActionKindV1.Observe)
                    { Materials = [source.SubjectId!.Value], AcquiresInformation = true, Context = c.Dorm, Cost = 1,
                        Claims = [new FrozenConditionV1.Tagged(new FrozenNounV1.Reference(knowledgeMaterial.SubjectId!.Value), TraceValue(0), 1),
                            new FrozenConditionV1.Tagged(new FrozenNounV1.Reference(knowledgeMaterial.SubjectId!.Value), TraceValue(1), 1)] },
                    c.ExamineAction, trace.SourceId, new Effect.Act(ActionOp.Inspect, source), trace));
                if (!c.Answered && !c.Submissions.ContainsKey(person.Key))
                    foreach (var testimony in person.Soul.World.Projections.Where(p => p.Existence == Truth.True
                        && p.Tags.GetValueOrDefault(new Tag("case-material-source:" + trace.SourceId)) == 1))
                    {
                        var materialId = testimony.SubjectId!.Value;
                        var id = trace.SourceId + ":present:" + materialId;
                        var marker = new Tag("case-presentation:" + materialId);
                        candidates.Add(Work(new(id, id, trace.SourceId, SubjectiveActionKindV1.Present)
                            { Materials = [materialId], GroupId = group, Context = c.Dorm, Presentable = true,
                                Selected = person.Self.Tags.GetValueOrDefault(marker) == 1 },
                            "present", trace.SourceId, new Effect.Set(person.Self, marker, 1), trace));
                    }
                if (!HasTrace(person, trace)) continue;
                var material = knowledgeMaterial.SubjectId!.Value;
                if (!c.Answered && !c.Submissions.ContainsKey(person.Key))
                    candidates.Add(Work(new(trace.SourceId + ":present", group + ":present:" + trace.SourceId, trace.SourceId, SubjectiveActionKindV1.Present)
                        { Materials = [material], GroupId = group, Context = c.Dorm, Presentable = true,
                            Selected = person.Self.Tags.GetValueOrDefault(new Tag("case-presentation:" + trace.SourceId)) == 1 },
                        "present", trace.SourceId, new Effect.Set(person.Self, new Tag("case-presentation:" + trace.SourceId), 1), trace));
                foreach (var listener in _dailyPeople.Values.Where(p => !ReferenceEquals(p, person) && ReferenceEquals(p.Body.Get<SpatialProperty>()!.Space, here)))
                {
                    var heard = _runtime.KnownProjection(person.Soul, listener.Body);
                    if (heard is null) continue;
                    var report = trace.SourceId + ":report:" + listener.Key;
                    candidates.Add(Work(new(report, report, trace.SourceId, SubjectiveActionKindV1.Observe)
                        { Materials = [material], AcquiresInformation = false, Context = c.Dorm, Cost = 1 },
                        c.ExchangeAction, listener.Actor, new Effect.Say(heard, trace.Text,
                            Claim: new Condition.Tagged(knowledgeMaterial, TraceValue(trace.Value), 1)), trace, listener.Actor));
                }
            }
            if (c.Answered || c.Submissions.ContainsKey(person.Key)) continue;
            for (var option = 0; option < c.Model.Options[c.Answer].Length; option++)
            {
                var claim = ActorClaim(person.Actor, c.Model.Questions[c.Answer], c.Model.Options[c.Answer][option]);
                if (claim is null) continue;
                var method = group + ":assert:" + option;
                candidates.Add(Work(new(method, method, group, SubjectiveActionKindV1.Assert)
                    { Claims = [claim], GroupId = group, Context = c.Dorm, RequiresEvidence = true,
                        Selected = person.Self.Tags.TryGetValue(new Tag("case-assertion:" + c.Id), out var selectedOption) && selectedOption == option },
                    "assert", group, new Effect.Set(person.Self, new Tag("case-assertion:" + c.Id), option), option: option));
            }
            var submit = group + ":" + c.SubmitAction;
            candidates.Add(Work(new(submit, submit, group, SubjectiveActionKindV1.Commit)
                { GroupId = group, Context = c.Dorm, RequiresEvidence = true, Materials = agency.Evidence, Cost = 1 },
                c.SubmitAction, group, new Effect.Set(person.Self, new Tag("case-submission:" + c.Id), 1)));

            MorningWork Work(SubjectiveOfferV1 offer, string action, string target, Effect effect,
                DormTrace? trace = null, string listener = "", int option = -1)
                => new(offer with { ScopeId = group }, new(c.Dorm, target, action, trace?.Label ?? c.Title, 1, 1, []), effect,
                    Case: c, Trace: trace, Listener: listener, Option: option);
        }
    }
    private bool HasTrace(DailyPerson person, DormTrace trace)
        => DormMaterial(person,trace) is { } known && known.Tags.ContainsKey(Trace);
    private void MorningFeedback(DailyPerson person, string stage, DecisionOutcomeV1 outcome, bool information = false)
    {
        if (person.Work is not { } work || person.Serial == 0) return;
        var method = !person.Arrived && (work.Investigating || work.Travels) ? "contact:" + work.Offer.MethodId : work.Offer.MethodId;
        var informationIdentity=information && stage=="completed" ? MorningInformationIdentity(person,work) : "";
        if(information && informationIdentity.Length==0) throw new InvalidOperationException("Actual acquired information requires a stable result identity.");
        SubjectiveAgent.Feedback(ActorAgency(person.Actor), new("morning:" + person.Serial + ":" + stage,
            method, work.Offer.Context, outcome, information,informationIdentity));
        _dailyTrajectory.Add(new(_dailySession.CTB.Now, person.Key, work.Step.Room,
            "receipt:" + stage, work.Offer.Id + ":" + outcome, _dailySettledMinutes));
    }
    private string MorningInformationIdentity(DailyPerson person,MorningWork work)
    {
        if(work.MainOperation.Length>0) return OperationInformationIdentity(person.Actor);
        object result;
        if(work.Trace is {} trace)
            result=new {Source=trace.SourceId,trace.Value,trace.Text};
        else
        {
            var key=work.MainEvidence.Length>0 ? work.MainEvidence : work.Step.Target;
            if(!_evidence.TryGetValue(key,out var physical)||_runtime.KnownProjection(person.Soul,physical) is not {} source) return "";
            var question=key==MainDeclaration.GetProperty("question_source").GetString()&&MainParticipant(person)
                && MainProgress(person).Asked ? MainQuestion(MainProgress(person).Step)?.GetProperty("line").GetString() : null;
            result=new {Source=physical.Id.Value,source.Name,source.Existence,Parent=source.Parent?.SubjectId?.ToString(),
                Details=source.LastObservation?.Details,Tags=source.Tags.OrderBy(p=>p.Key.ToString(),StringComparer.Ordinal).Select(p=>new {Tag=p.Key.ToString(),p.Value}).ToArray(),Question=question};
        }
        return "result:"+Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
            System.Text.Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(result))));
    }
    private bool CompleteInvestigation(DailyPerson person, out bool information)
    {
        using var performance = CorePerformance.Begin("morning.complete_investigation");
        information = false;
        var work = person.Work!;
        if (work.Case is null) return CompleteMainInvestigation(person, out information);
        var c = work.Case;
        if (!ReferenceEquals(person.Body.Get<SpatialProperty>()!.Space, _dailySpaces[c.Dorm])) return false;
        if (work.Step.Action == c.ExamineAction && work.Trace is { } trace)
        {
            if (!ReferenceEquals(trace.Entity.Get<SpatialProperty>()!.Space, person.Body.Get<SpatialProperty>()!.Space)) return false;
            information = !HasTrace(person, trace);
            AcquireTrace(person, trace, ObservationSource.Perception);
            _dailyTrajectory.Add(new(_dailySession.CTB.Now, person.Key, c.Dorm, "trace", trace.Text, _dailySettledMinutes));
            return information;
        }
        if (work.Step.Action == c.ExchangeAction && work.Trace is { } reported)
        {
            var listener = DailyActor(work.Listener);
            if (listener is null || !HasTrace(person, reported) || !ReferenceEquals(listener.Body.Get<SpatialProperty>()!.Space, person.Body.Get<SpatialProperty>()!.Space)) return false;
            AcquireTrace(listener, reported, ObservationSource.Testimony, person);
            _dailyTrajectory.Add(new(_dailySession.CTB.Now, person.Key, c.Dorm, "report", reported.SourceId + ":" + listener.Key, _dailySettledMinutes));
            return true;
        }
        if (work.Step.Action == "assert" || work.Step.Action == "present") return true;
        if (work.Step.Action != c.SubmitAction || work.Statement is null || work.Proof is not { Value: Truth.True, Complete: true, Contradicted: false, Hypothetical: false }
            || work.Evidence.IsDefaultOrEmpty) return false;
        var owned = OwnedCaseMaterials(person, c).ToHashSet();
        if (!work.Evidence.All(owned.Contains) || !work.Proof.Basis.Any(owned.Contains)) return false;
        var option = Enumerable.Range(0, c.Model.Options[c.Answer].Length).FirstOrDefault(o =>
        {
            var candidate = ActorClaim(person.Actor, c.Model.Questions[c.Answer], c.Model.Options[c.Answer][o]);
            return candidate is not null && MorningContract(Ast.Equivalent(candidate, work.Statement));
        }, -1);
        if (option < 0) return false;
        c.Submissions[person.Key] = new(option, [..work.Evidence], _dailySettledMinutes);
        _dailyTrajectory.Add(new(_dailySession.CTB.Now, person.Key, c.Dorm, "submitted", c.Model.Options[c.Answer][option], _dailySettledMinutes));
        AcceptDormSubmissions(c);
        return true;
    }
    private void AcquireTrace(DailyPerson listener, DormTrace trace, ObservationSource source, DailyPerson? speaker = null)
    {
        var known = DormMaterial(listener,trace,true)!;
        var subject = speaker is null ? null : _runtime.KnownProjection(listener.Soul, speaker.Body);
        if (source == ObservationSource.Testimony)
        {
            var identity = new Tag("case-testimony:" + speaker!.Key + ":" + trace.SourceId);
            var name = trace.Label + " · " + subject!.Name;
            var testimony = listener.Soul.World.Projections.FirstOrDefault(p => p.Tags.GetValueOrDefault(identity) == 1);
            var acceptance = SocialSystem.EvaluateSender(listener.Soul.World, listener.Self, subject).Stance switch
            { SocialStance.Accept => Truth.True, SocialStance.Reject => Truth.False, _ => Truth.Unknown };
            Observation.Observe(listener.Soul, new(name, ProjectionKind.Concept) { Target = testimony, Source = source,
                Existence = Truth.True, Time = _dailySession.CTB.Now, Details = trace.Text,
                Tags = ImmutableDictionary<Tag, int?>.Empty.Add(new Tag("case-material-source:" + trace.SourceId), 1).Add(identity, 1),
                AddRelations = subject is null ? [] : [(Relations.Subject, subject)],
                Rules = [new(new Condition.Constant(Truth.True), RuleMode.Infer,
                    new Effect.Think(new Condition.Tagged(known, TraceValue(trace.Value), 1)), Acceptance: acceptance)] });
            return;
        }
        Observation.Observe(listener.Soul, new(known.Name, known.Kind) { Target = known, Source = source,
            Existence = Truth.True, Time = _dailySession.CTB.Now, Details = trace.Text,
            Tags = ImmutableDictionary<Tag, int?>.Empty.Add(Trace, trace.Value).Add(TraceValue(trace.Value), 1),
            AddRelations = subject is null ? [] : [(Relations.Subject, subject)] });
    }
    private void AcceptDormSubmissions(DormCase c)
    {
        if (c.Answered) return;
        // Only completed personal submissions participate, never a scan of everyone's confidence.
        var electorate = _dailyPeople.Values.Where(p => p.Dorm == c.Dorm).Select(p => p.Key).ToHashSet(StringComparer.Ordinal);
        var winner = c.Submissions.Where(p => electorate.Contains(p.Key)).GroupBy(p => p.Value.Option).MaxBy(g => g.Count());
        if (winner is null || winner.Count() * 2 <= electorate.Count) return;
        c.Answered = true;
        OpenAnsweredDorms(_dailySettledMinutes);
        var answer = c.Model.Options[c.Answer][winner.Key];
        var submissions = winner.Select(p => p.Key + ":" + p.Value.Option + ":" + p.Value.Evidence.Length).ToArray();
        _dormResults.Add(new(c.Id, c.Dorm, answer, _dailySettledMinutes, submissions));
        _dailyTrajectory.Add(new(_dailySession.CTB.Now, winner.First().Key, c.Dorm, "answered", answer, _dailySettledMinutes));
    }
    private void OpenAnsweredDorms(int minutes)
    {
        foreach (var c in _dormCases.Values.Where(c => c.Answered && minutes >= c.EarliestOut))
            if(_dormOpened.TryAdd(c.Dorm, minutes)) OpenMorningSector(c.Dorm);
    }
}
