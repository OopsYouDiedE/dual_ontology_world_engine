namespace DualOntologyWorldEngine.Awakening;

public sealed partial class Chapter1Session
{
    // Test diagnostics only. These cursors are not simulation state, save data,
    // player observations, or inputs to any subject's decision process.
    private MorningWorld? _diagnosticWorld;
    private string _diagnosticEpoch = "";
    private int _diagnosticTrajectory, _diagnosticDecisions, _diagnosticDormResults, _diagnosticOperations;
    private readonly Dictionary<string, int> _diagnosticDormOpened = new(StringComparer.Ordinal);
    private readonly Dictionary<string, int> _diagnosticMainReceipts = new(StringComparer.Ordinal);

    public IReadOnlyDictionary<string, object?> TakeExecutionDiagnostics()
    {
        var reset = !ReferenceEquals(_diagnosticWorld, _world);
        if (reset)
        {
            _diagnosticWorld = _world;
            _diagnosticEpoch = Guid.NewGuid().ToString("D");
            _diagnosticTrajectory = _diagnosticDecisions = _diagnosticDormResults = _diagnosticOperations = 0;
            _diagnosticDormOpened.Clear();
            _diagnosticMainReceipts.Clear();
        }
        var trajectory = _world.DailyTrajectory;
        var decisions = _world.DailyDecisions;
        var results = _world.DormCaseResults;
        var trajectoryFrom = _diagnosticTrajectory;
        var decisionsFrom = _diagnosticDecisions;
        var resultsFrom = _diagnosticDormResults;
        var addedTrajectory = trajectory.Skip(trajectoryFrom).ToArray();
        var addedDecisions = decisions.Skip(decisionsFrom).ToArray();
        var addedResults = results.Skip(resultsFrom).ToArray();
        var operationsFrom = _diagnosticOperations;
        var operations = _world.ActualOperationReceipts;
        var addedOperations = operations.Skip(operationsFrom).ToArray();
        _diagnosticOperations = operations.Count;
        // Each actor owns an append-only receipt list. A single cursor over the
        // flattened actor lists would miss later insertions in an earlier list.
        var mainReceipts = new List<MorningWorld.MainSubmissionReceipt>();
        foreach (var actorReceipts in _world.MainSubmissionReceipts.GroupBy(r => r.Actor))
        {
            var observed = _diagnosticMainReceipts.GetValueOrDefault(actorReceipts.Key);
            mainReceipts.AddRange(actorReceipts.Skip(observed));
            _diagnosticMainReceipts[actorReceipts.Key] = actorReceipts.Count();
        }
        var opened = _world.DormOpenedMinutes.Where(p => !_diagnosticDormOpened.TryGetValue(p.Key, out var prior) || prior != p.Value)
            .ToDictionary(p => p.Key, p => p.Value, StringComparer.Ordinal);
        _diagnosticTrajectory = trajectory.Count;
        _diagnosticDecisions = decisions.Count;
        _diagnosticDormResults = results.Count;
        foreach (var entry in opened) _diagnosticDormOpened[entry.Key] = entry.Value;
        return new Dictionary<string, object?>
        {
            ["diagnostic"] = "chapter1_execution", ["version"] = 1, ["available"] = true,
            ["epoch"] = _diagnosticEpoch, ["reset"] = reset, ["game_minutes"] = _world.GameMinutes,
            ["trajectory"] = addedTrajectory, ["decisions"] = addedDecisions,
            ["dorm_case_results"] = addedResults, ["dorm_opened"] = opened,
            ["main_submissions"] = mainReceipts,
            ["operations"] = addedOperations,
            ["cursor"] = new Dictionary<string, object?> {
                ["trajectory_from"] = trajectoryFrom, ["trajectory_to"] = _diagnosticTrajectory,
                ["decisions_from"] = decisionsFrom, ["decisions_to"] = _diagnosticDecisions,
                ["operations_from"] = operationsFrom, ["operations_to"] = _diagnosticOperations,
                ["dorm_case_results_from"] = resultsFrom, ["dorm_case_results_to"] = _diagnosticDormResults }
        };
    }
}
