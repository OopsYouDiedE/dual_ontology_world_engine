using DualOntologyWorldEngine.Core;
using System.Collections.Immutable;

namespace DualOntologyWorldEngine.Awakening;

public sealed partial class MorningWorld
{
    private readonly Dictionary<string,Essence> _morningPassages = new(StringComparer.Ordinal);
    private static readonly RelationTag MorningEndpoint = new("TravelEndpoint");
    public IReadOnlyList<MorningSourceOffer> MorningTravelOffers(string actor)
        => PrepareMorningOffers(RequiredActor(actor)).Where(w=>w.Step.Action=="travel")
            .Select(w=>new MorningSourceOffer(w.Offer.Id,w.Offer.SourceId,w.Step.Room,w.Step.Note,"travel",w.Offer)).ToArray();
    private void InitializeMorningPassages()
    {
        foreach(var declaration in Chapter1Data.Root.GetProperty("SHARED_PASSAGES").EnumerateObject()
            .Concat(Chapter1Data.Root.GetProperty("MORNING_PASSAGES").EnumerateObject()))
        {
            var from=declaration.Value.GetProperty("from").GetString()!;
            var to=declaration.Value.GetProperty("to").GetString()!;
            if(!_dailySpaces.TryGetValue(from,out var source) || !_dailySpaces.TryGetValue(to,out var destination))
                throw new InvalidOperationException("Shared passage references an undeclared actual room.");
            var passage=new Essence(new EntityId("world:route."+declaration.Name),source.TrueName+" → "+destination.TrueName,ProjectionKind.Boundary);
            passage.Add(new SpatialProperty {Space=source});
            var connections=passage.Add(new PassageProperty()).Connections;
            connections[source]=destination;connections[destination]=source;
            if(declaration.Value.TryGetProperty("isolation",out var isolation) && isolation.GetBoolean()) passage.Add(new LockProperty());
            _morningPassages.Add(declaration.Name,passage);
            _runtime.Project(passage,passage.TrueName);
        }
    }
    public void OpenMainMorningBoundary()
    {
        foreach(var edge in Chapter1Data.Root.GetProperty("MORNING_PASSAGES").EnumerateObject())
            if(edge.Value.TryGetProperty("main_boundary",out var main) && main.GetBoolean())
                _morningPassages[edge.Name].Get<LockProperty>()!.IsLocked=false;
        _runtime.Sync();
    }
    private void OpenMorningSector(string sector)
    {
        foreach(var edge in Chapter1Data.Root.GetProperty("MORNING_PASSAGES").EnumerateObject())
            if(edge.Value.TryGetProperty("sector",out var value) && value.GetString()==sector)
                _morningPassages[edge.Name].Get<LockProperty>()!.IsLocked=false;
        _runtime.Sync();
    }
    private void ObserveMorningPassages(DailyPerson person,Essence room)
    {
        // Actual local contact publishes both public endpoints; planning below
        // only uses this actor's retained projections, never the live topology.
        foreach(var passage in _morningPassages.Values.Where(p=>p.Get<PassageProperty>()!.Connections.ContainsKey(room)))
        {
            var rooms=passage.Get<PassageProperty>()!.Connections.Keys.ToArray();
            _runtime.Observe(person.Soul,rooms.SelectMany(r=>_runtime.Representations(r)).Concat(_runtime.Representations(passage)),_dailySession.CTB.Now);
            var known=_runtime.KnownProjection(person.Soul,passage)!;
            var endpoints=rooms.Select(r=>(MorningEndpoint,_runtime.KnownProjection(person.Soul,r)!)).ToImmutableHashSet();
            if(!known.Relations.IsSupersetOf(endpoints)) Observation.Observe(person.Soul,new ObservationInput(known.Name,known.Kind)
                {Target=known,Existence=Truth.True,Time=_dailySession.CTB.Now,AddRelations=endpoints});
        }
    }
    private Effect? MorningTravelEffect(DailyPerson person,string destination)
    {
        if(!_dailySpaces.TryGetValue(destination,out var target)) return null;
        var current=person.Self.Parent;
        var knownTarget=_runtime.KnownProjection(person.Soul,target);
        if(ReferenceEquals(current,knownTarget)) return new Effect.Sequence([]);
        if(current is null) return null;
        var paths=new Dictionary<Projection,Effect[]> { [current]=[] };
        var queue=new Queue<Projection>();queue.Enqueue(current);
        while(queue.TryDequeue(out var room))
            foreach(var known in person.Soul.World.Projections.Where(p=>p.Kind==ProjectionKind.Boundary && p.Existence==Truth.True))
            {
                var endpoints=known.Relations.Where(r=>r.Relation==MorningEndpoint).Select(r=>r.Target).ToArray();
                if(endpoints.Contains(room) && known.Tags.GetValueOrDefault(Tags.Locked)!=1)
                foreach(var next in endpoints.Where(n=>!ReferenceEquals(n,room)&&!paths.ContainsKey(n)))
                {
                    var path=paths[room].Append<Effect>(new Effect.Act(ActionOp.Travel,known)).ToArray();
                    paths[next]=path;
                    if(ReferenceEquals(next,knownTarget)) return new Effect.Sequence([..path]);
                    queue.Enqueue(next);
                }
            }
        return null;
    }
    private void AddMorningTravelOffers(DailyPerson person,List<MorningWork> candidates)
    {
        var here=person.Self.Parent;
        if(here is null) return;
        foreach(var passage in _morningPassages.Values)
        {
            var known=_runtime.KnownProjection(person.Soul,passage);
            if(known is null || known.Existence!=Truth.True) continue;
            var endpoints=known.Relations.Where(r=>r.Relation==MorningEndpoint).Select(r=>r.Target).ToArray();
            if(!endpoints.Contains(here)) continue;
            foreach(var destination in endpoints.Where(p=>!ReferenceEquals(p,here)))
            {
                var room=_dailySpaces.FirstOrDefault(p=>ReferenceEquals(_runtime.KnownProjection(person.Soul,p.Value),destination)).Key;
                if(room is null) continue;
                var id="travel:"+passage.Id.Value+":"+destination.SubjectId;
                candidates.Add(new(new(id,id,passage.Id.Value,SubjectiveActionKindV1.Travel)
                    {ScopeId="morning.travel",Materials=[known.SubjectId!.Value],Cost=1,Context=destination.Name,
                        Forbidden=known.Tags.GetValueOrDefault(Tags.Locked)==1},
                    new(room,passage.Id.Value,"travel",known.Name,1,1,[]),
                    new Effect.When(new Condition.Not(new Condition.At(person.Self,destination)),new Effect.Act(ActionOp.Travel,known)),Travels:true));
            }
        }
    }
    private (Effect Effect,bool Travels,bool Forbidden) AdaptMorningTravel(DailyPerson person,DailyStep step,Effect effect)
    {
        if(ReferenceEquals(person.Self.Parent,_runtime.KnownProjection(person.Soul,_dailySpaces[step.Room]))) return (effect,false,false);
        var travel=MorningTravelEffect(person,step.Room);
        if(travel is null) return (effect,false,true);
        var target=_runtime.KnownProjection(person.Soul,_dailySpaces[step.Room]);
        if(target is null) return (effect,false,true);
        // A geometry receipt may already have completed the exact same trip.
        // The low precision seat completes it through the actual Travel effects.
        return (new Effect.Sequence([new Effect.When(new Condition.Not(new Condition.At(person.Self,target)),travel),effect]),true,false);
    }
}
