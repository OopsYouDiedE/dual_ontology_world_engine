using System.Collections.Immutable;
using System.Text.Json;
using DualOntologyWorldEngine.Core;
using static DualOntologyWorldEngine.Story.ChapterEvents;

namespace DualOntologyWorldEngine.Story;

public sealed class ActorControllerDefinition
{
    public string Actor { get; set; } = "";
    public string Name { get; set; } = "";
    public string Mode { get; set; } = "";
    public List<ControllerRuleDefinition> Rules { get; set; } = [];
    public ControllerReasoningDefinition Reasoning { get; set; } = new();
}
public sealed class ControllerReasoningDefinition
{
    public int Depth { get; set; } = 1;
    public int Expansions { get; set; } = 256;
    public int Hypotheses { get; set; } = 16;
    public int ArgumentWeight { get; set; } = 1;
    public int InformationWeight { get; set; } = 1;
}
public sealed class ControllerRuleDefinition
{
    public string Mode { get; set; } = "";
    public string Kind { get; set; } = "";
    public int Weight { get; set; }
    public string LabelContains { get; set; } = "";
}
public sealed record PlayerTime(int Day, double Minutes, string Phase);
public sealed record PlayerCognition(CognitionSnapshotV1 Snapshot, SubjectProjectionId Actor)
{
    public SubjectiveAgentState? Agency { get; init; }
    public SubjectiveAgentRequestV1? Investigation { get; init; }
}

// Implemented by trusted chapter adapters. Never handed to a controller.
public interface IPlayerRoleSession
{
    string PlayerActor { get; }
    PlayerCognition CapturePlayerCognition(string actor);
    PlayerTime PlayerTime { get; }
    void ObservePlayerOffers(IReadOnlyList<PlayerFieldOffer> offers) { }
    SubjectiveOfferV1? PublicChoiceSemantic(IReadOnlyDictionary<string, object?> input) => null;
    void ObservePlayerFormField(IReadOnlyDictionary<string, object?> field) { }
}

public sealed record PublicPlayerLine(string Speaker, string Mood, string Text);
public sealed record PlayerPoint(double X, double Y);
public sealed record PlayerFieldState(string Space, PlayerPoint Position)
{
    public string Entered { get; init; } = "";
}
public sealed record PublicPlayerCandidate(string Token, string Label, string Kind, bool New, string Group = "", string Value = "", string Purpose = "", bool Selected = false)
{
    public string SourceId { get; init; } = "";
    public string MethodId { get; init; } = "";
    public string DestinationSourceId { get; init; } = "";
    public string EffectKind { get; init; } = "";
    public string ScopeId { get; init; } = "";
    public string MaterialId { get; init; } = "";
    public string SourceState { get; init; } = "";
    public SubjectiveOfferV1? Semantic { get; init; }
    public PlayerPoint? Location { get; init; }
    public double TravelDistance { get; init; }
    public double ArrivalRadius { get; init; } = 12;
    public bool Traversal { get; init; }
    public bool KnownGround { get; init; } = true;
}
public sealed record PublicExecutionResult(string SourceId, string MethodId, string InformationIdentity, bool Succeeded);
public sealed record PublicPlayerObservation(long Turn, ImmutableArray<PublicPlayerLine> Lines,
    ImmutableArray<string> Text, ImmutableArray<PublicPlayerCandidate> Candidates, bool Complete)
{
    public PlayerFieldState? Field { get; init; }
    public bool CompleteMethodMenu { get; init; }
    public ImmutableArray<string> CompleteScopeIds { get; init; } = [];
    public ImmutableArray<PublicExecutionResult> ExecutionResults { get; init; } = [];
}
public sealed record PlayerDecision(string? Token, string Reason, int? Score)
{
    public ImmutableArray<string> Basis { get; init; } = [];
    public int ReasoningExpansions { get; init; }
    public string ReasoningStop { get; init; } = "not_run";
    public int HypothesesCompared { get; init; }
    public ImmutableArray<PlayerArgument> Arguments { get; init; } = [];
    public ImmutableArray<PlayerAlternative> Alternatives { get; init; } = [];
}
public sealed record PlayerAlternative(string Token, string Label, string Kind, int Score, ImmutableArray<string> Basis);
public sealed record PlayerArgument(string Proposition, string Value, bool Complete, ImmutableArray<string> Materials, ImmutableArray<string> Steps)
{
    public ImmutableArray<PlayerInference> Derivations { get; init; } = [];
    public ImmutableArray<string> Missing { get; init; } = [];
    public bool? MaterialSupports { get; init; }
}
public sealed record PlayerInference(string Conclusion, ImmutableArray<string> Premises, string Material);
public sealed class PlayerBoundaryException(string code) : InvalidOperationException(code)
{
    public string Code { get; } = code;
}
public interface IPlayerCandidatePort
{
    PublicPlayerObservation Submit(SelectCandidate selection);
}

// Host-generated offers must already pass the real field's visibility/navigation gates.
// Their payload is retained by the trusted port, never exposed to the controller.
public sealed record PlayerFieldOffer(string Label, string Kind, bool New,
    IReadOnlyDictionary<string, object?> Input, string Group = "", string Value = "", string Purpose = "", bool Selected = false)
{
    public string SourceId { get; init; } = "";
    public string MethodId { get; init; } = "";
    public string DestinationSourceId { get; init; } = "";
    public string EffectKind { get; init; } = "";
    public string SourceState { get; init; } = "";
    public SubjectiveOfferV1? Semantic { get; init; }
    public PlayerPoint? Location { get; init; }
    public double TravelDistance { get; init; }
    public bool KnownGround { get; init; } = true;
}

// Trusted projection of exactly the shared panels' presentation contracts.
// IDs, numeric option indices and maps remain in private submission payloads.
public sealed record PlayerPanelView(IReadOnlyList<string> Text, IReadOnlyList<PlayerFieldOffer> Offers);
public static class PlayerPanels
{
    private static IEnumerable<IReadOnlyDictionary<string, object?>> Entries(IReadOnlyDictionary<string, object?> data, string key)
        => (data.GetValueOrDefault(key) as IEnumerable<object?> ?? []).OfType<IReadOnlyDictionary<string, object?>>();
    public static PlayerPanelView Project(IReadOnlyDictionary<string, object?> presentation, string panel, string runLabel)
    {
        var text = new List<string>(); var offers = new List<PlayerFieldOffer>();
        void Line(string value) { if (value != "") text.Add(value); }
        void Card(IReadOnlyDictionary<string, object?> entry)
        {
            if (Text(entry, "card_id") is { Length: > 0 } id)
                offers.Add(new(Text(entry, "label", Text(entry, "title")), "interact", false, Event("card", ("card_id", id))));
        }
        if (panel == "notebook" && Flag(Map(presentation, "controls"), "notebook"))
        {
            var data = Map(presentation, "notebook"); var sections = Entries(data, "sections").ToArray();
            if (sections.Length == 0) Line(Text(data, "empty_text"));
            foreach (var section in sections)
            {
                Line(Text(section, "heading"));
                foreach (var entry in Entries(section, "entries")) { Line(Text(entry, "label")); Card(entry); }
            }
        }
        else if (panel == "campus" && Flag(Map(presentation, "controls"), "campus"))
        {
            var data = Map(presentation, "campus"); Line(Text(data, "title"));
            var known = Map(data, "known");
            foreach (var (id, value) in Map(data, "nodes"))
                if (Flag(known, id) && value is IReadOnlyDictionary<string, object?> node)
                    offers.Add(new(Text(node, "label"), "move", false, Event("travel", ("node_id", id))));
        }
        else if (panel == "manuscript" && Flag(Map(presentation, "controls"), "manuscript"))
        {
            var data = Map(presentation, "replay");
            if (!Flag(data, "open")) throw new PlayerBoundaryException("panel_unavailable");
            Line(Text(data, "title")); Line(Text(data, "hint"));
            var questions = Entries(data, "questions").ToArray();
            var current = (data.GetValueOrDefault("vars") as IEnumerable<object?> ?? []).ToArray();
            var values = questions.Select((q, i) => i < current.Length && int.TryParse(current[i]?.ToString(), out var v)
                && v >= 0 && v < (q.GetValueOrDefault("options") as IEnumerable<object?> ?? []).Count() ? v : -1).ToArray();
            for (var i = 0; i < questions.Length; i++)
            {
                var question = questions[i]; Line(Text(question, "question") + Text(question, "mark"));
                var options = (question.GetValueOrDefault("options") as IEnumerable<object?> ?? []).OfType<string>().ToArray();
                for (var j = 0; j < options.Length; j++)
                {
                    var next = values.Cast<object?>().ToArray(); next[i] = j;
                    offers.Add(new(Text(question, "question") + " " + options[j], "form_field", values[i] == -1,
                        Event("replay_vars", ("vars", next)), Text(question, "question"), options[j], "hypothesis", values[i] == j)
                        { SourceId = "panel:manuscript", MethodId = "variable:" + i + ":option:" + j });
                }
            }
            if (values.Length > 0 && values.All(v => v >= 0))
                offers.Add(new(runLabel, "form_submit", false, Event("replay", ("vars", values.Cast<object?>().ToArray()), ("skip", false)), Purpose: "commit")
                    { SourceId = "panel:manuscript", MethodId = "experiment:submit", EffectKind = "Test" });
            foreach (var finding in Entries(Map(data, "result"), "findings"))
            {
                Line(Text(finding, "title")); Line(Text(finding, "status"));
                if (Text(finding, "status") != "match") Line(Text(finding, "text"));
                if (Text(finding, "status") != "unvisited") Card(finding);
            }
        }
        else throw new PlayerBoundaryException("panel_unavailable");
        offers.Add(new("Esc", "continue", false, Event("player_panel", ("panel", "")), Purpose: "close"));
        return new(text, offers);
    }
}

public static class PlayerControllers
{
    public static IReadOnlyList<ActorControllerDefinition> Read(string json)
    {
        var chapters = WorldScriptDocument.Parse(json, allowChapterAdapter: true);
        var controls = chapters.SelectMany(c => c.Controllers).ToArray();
        var actors = chapters.SelectMany(c => c.Entities.Where(e => e.Kind == "character")
            .Select(e => e.Id.Contains(':') ? e.Id : (e.Scope == "world" ? "world" : c.Id) + ":" + e.Id)).ToHashSet(StringComparer.Ordinal);
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var control in controls)
        {
            if (!actors.Contains(control.Actor) || !seen.Add(control.Actor) || string.IsNullOrWhiteSpace(control.Name))
                throw new InvalidDataException("Invalid or duplicate controller actor.");
            Validate(control);
        }
        return controls;
    }
    public static void Validate(ActorControllerDefinition control)
    {
        if (control.Mode is not ("agent" or "player") || control.Rules.Count > 64
            || control.Mode == "agent" && control.Rules.Count == 0)
            throw new InvalidDataException("Invalid controller mode or rule count.");
        foreach (var rule in control.Rules)
            if (rule.Mode is not ("prefer" or "require" or "forbid" or "permit")
                || rule.Kind is not ("menu" or "form_field" or "form_submit" or "continue" or "interact" or "move" or "wait" or "untried" or "new")
                || rule.Weight is < 0 or > 1000 || rule.LabelContains is null || rule.LabelContains.Length > 200)
                throw new InvalidDataException("Unsupported subjective controller rule.");
        var reasoning = control.Reasoning;
        if (reasoning is null || reasoning.Depth is < 0 or > 64 || reasoning.Expansions is < 1 or > 100000
            || reasoning.Hypotheses is < 1 or > 4096 || reasoning.ArgumentWeight is < 0 or > 1000 || reasoning.InformationWeight is < 0 or > 1000)
            throw new InvalidDataException("Unsupported subjective reasoning budget.");
    }
}

/// <summary>Public UI and geometry adapter for the same Core agent used by residents.</summary>
public sealed class SubjectivePlayerController
{
    private readonly ActorControllerDefinition _declaration;
    private readonly uint _seed;
    private SubjectiveAgentState? _state;
    private readonly Dictionary<string, string> _compatibilityIds = [];
    private readonly Dictionary<string, PublicPlayerCandidate> _selected = [];
    private string _source = "";
    private string _space = "";
    private PublicPlayerObservation? _lastObservation;
    private PlayerCognition? _lastCognition;
    private readonly Dictionary<string, SubjectiveOfferV1> _pendingTests = [];
    private readonly Dictionary<string, PublicPlayerCandidate> _pendingTestInputs = [];
    private (string Token, SubjectiveOfferV1 Offer, PublicPlayerCandidate Public, PlayerFieldState? Start, string Visible, ImmutableHashSet<string> SourceFacts)? _executing;

    private readonly Dictionary<string, SubjectiveOfferV1> _offers = [];
    public SubjectivePlayerController(ActorControllerDefinition declaration, int seed)
    { PlayerControllers.Validate(declaration); _declaration = declaration; _seed = unchecked((uint)seed); }
    private string CompatibilityIdentity(string mechanism)
    {
        // Compatibility callers without port identities receive a local opaque
        // identity. Production ports supply stable mechanism IDs explicitly.
        if (!_compatibilityIds.TryGetValue(mechanism, out var id))
            _compatibilityIds[mechanism] = id = "compat:" + _compatibilityIds.Count;
        return id;
    }
    private static string Visible(PublicPlayerObservation observation) => JsonSerializer.Serialize(new
    { observation.Lines, observation.Text, observation.Complete,
      Sources = observation.Candidates.Select(c => c.SourceId).Where(s => s.Length > 0).Distinct().Order() });
    private static ImmutableHashSet<string> AcquiredSourceFacts(PlayerCognition? cognition, string sourceId)
    {
        if (cognition is null) return ImmutableHashSet<string>.Empty;
        return cognition.Snapshot.Projections.Where(p => p.Existence == Truth.True
            && p.KnownTerms.Any(t => t.TermId.Value == "public-source." + sourceId)
            && p.KnownTerms.Any(t => t.TermId.Value.StartsWith("acquired.card.", StringComparison.Ordinal)
                || t.TermId.Value.StartsWith("acquired.line.", StringComparison.Ordinal)
                || t.TermId.Value.StartsWith("acquired.memory.", StringComparison.Ordinal)
                || t.TermId.Value.StartsWith("acquired.testimony.", StringComparison.Ordinal)))
            .Select(p => JsonSerializer.Serialize(new
            {
                Facts = p.KnownTerms.Where(t => t.TermId.Value.StartsWith("acquired.", StringComparison.Ordinal)).Select(t => t.TermId.Value).Order(StringComparer.Ordinal),
                Rules = p.Rules, Tags = p.Tags.OrderBy(t => t.Key.Name).Select(t => new { Key = t.Key.Name, t.Value })
            })).ToImmutableHashSet(StringComparer.Ordinal);
    }
    private void Feedback(string token, SubjectiveOfferV1 offer, string stage, DecisionOutcomeV1 outcome, bool acquired = false, string informationIdentity = "")
    {
        if (_state is not null) SubjectiveAgent.Feedback(_state, new(token + ":" + stage, offer.MethodId, offer.Context, outcome, acquired, informationIdentity));
    }
    public bool StartExecution(string token)
    {
        if (!_offers.TryGetValue(token, out var offer) || !_selected.TryGetValue(token, out var candidate)) return false;
        if (candidate.Semantic is not null) return true; // The chapter owns the actual execution lifecycle.
        if (_state?.Receipts.Contains(token + ":start") == true) return false;
        if (offer.Kind == SubjectiveActionKindV1.Test)
        {
            if (_pendingTests.Count > 0) return false;
            Feedback(token, offer, "start", DecisionOutcomeV1.Attempted);
            _pendingTests[token] = offer; _pendingTestInputs[token] = candidate;
            return true;
        }
        if (_executing is { } active)
        {
            if (active.Token == token) return false;
            Feedback(active.Token, active.Offer, "finish", DecisionOutcomeV1.Interrupted);
            _executing = null;
        }
        Feedback(token, offer, "start", DecisionOutcomeV1.Attempted);
        _executing = (token, offer, candidate, _lastObservation?.Field, _lastObservation is null ? "" : Visible(_lastObservation), AcquiredSourceFacts(_lastCognition, offer.SourceId));
        return true;
    }
    public bool CompleteInteraction(string token, bool reached)
    {
        if (_state?.Receipts.Contains(token + ":finish") == true || _state?.Receipts.Contains(token + ":superseded") == true) return false;
        if (!reached && _pendingTests.Remove(token, out var pendingTest))
        {
            _pendingTestInputs.Remove(token);
            Feedback(token, pendingTest, "finish", DecisionOutcomeV1.Interrupted);
            return true;
        }
        if (_executing is not { } execution || execution.Token != token)
        {
            if (!_selected.TryGetValue(token, out var candidate) || !_offers.TryGetValue(token, out var selected)) return false;
            if (!reached)
            { Feedback(token, selected, "superseded", DecisionOutcomeV1.Interrupted); return true; }
            if (candidate.Kind != "interact" || !StartExecution(token)) return false;
            execution = _executing!.Value;
        }
        if (execution.Public.Kind != "interact")
        {
            if (!reached) { Feedback(token, execution.Offer, "finish", DecisionOutcomeV1.Interrupted); _executing = null; return true; }
            return false;
        }
        Feedback(token, execution.Offer, "finish", reached ? DecisionOutcomeV1.Succeeded : DecisionOutcomeV1.Failed);
        if (reached)
        {
            _source = execution.Offer.SourceId;

        }
        _executing = null;
        return true;
    }
    private void CompleteObservedExecution(PublicPlayerObservation observation, PlayerCognition cognition)
    {
        foreach (var (token, test) in _pendingTests.ToArray())
        {
            var input = _pendingTestInputs[token];
            var result = observation.ExecutionResults.FirstOrDefault(r => r.SourceId == test.SourceId && r.MethodId == input.MethodId);
            if (result is null) continue;
            var actualInformation = result.Succeeded && result.InformationIdentity.Length > 0
                && cognition.Snapshot.Projections.Any(p => p.Existence == Truth.True
                    && p.KnownTerms.Any(t => t.TermId.Value == result.InformationIdentity));
            Feedback(token, test, "finish", result.Succeeded ? DecisionOutcomeV1.Succeeded : DecisionOutcomeV1.Failed,
                actualInformation, actualInformation ? result.InformationIdentity : "");
            _pendingTests.Remove(token); _pendingTestInputs.Remove(token);
        }
        if (_executing is not { } execution) return;
        var candidate = execution.Public;
        if (candidate.Kind == "interact" && candidate.Location is not null) { CompleteInteraction(execution.Token, false); return; }
        var changed = execution.Visible != Visible(observation);
        var outcome = DecisionOutcomeV1.Succeeded;
        if (candidate.Kind == "move")
        {
            if (execution.Start is not { } start || observation.Field is not { } finish) outcome = DecisionOutcomeV1.Interrupted;
            else
            {
                var displacement = Math.Sqrt(Math.Pow(start.Position.X - finish.Position.X, 2) + Math.Pow(start.Position.Y - finish.Position.Y, 2));
                var atPoint = candidate.Location is { } point && Math.Sqrt(Math.Pow(point.X - finish.Position.X, 2) + Math.Pow(point.Y - finish.Position.Y, 2)) <= candidate.ArrivalRadius;
                var crossed = finish.Space != start.Space || finish.Entered.Length > 0 && finish.Entered != start.Entered;
                outcome = displacement < 8 ? DecisionOutcomeV1.NoProgress : (candidate.Traversal ? crossed && atPoint : atPoint) ? DecisionOutcomeV1.Succeeded : DecisionOutcomeV1.Interrupted;
                if (execution.Offer.Kind == SubjectiveActionKindV1.Open)
                {
                    var observedOpen = observation.Candidates.Any(c => c.SourceId == candidate.SourceId && c.SourceState == "open");
                    outcome = observedOpen ? DecisionOutcomeV1.Succeeded : displacement < 8 ? DecisionOutcomeV1.NoProgress : DecisionOutcomeV1.Interrupted;
                }
            }
        }
        else if (candidate.Kind == "wait" && !changed) outcome = DecisionOutcomeV1.NoProgress;
        if (candidate.Kind == "interact" && outcome == DecisionOutcomeV1.Succeeded) _source = execution.Offer.SourceId;
        var acquiredIdentity = "";
        if (outcome == DecisionOutcomeV1.Succeeded && execution.Offer.Kind == SubjectiveActionKindV1.Observe)
        {
            var newFacts = AcquiredSourceFacts(cognition, execution.Offer.SourceId).Except(execution.SourceFacts).Order(StringComparer.Ordinal).ToArray();
            if (newFacts.Length > 0)
                acquiredIdentity = "source-facts:" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
                    System.Text.Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new { Source = execution.Offer.SourceId, Facts = newFacts }))));
        }
        Feedback(execution.Token, execution.Offer, "finish", outcome, acquiredIdentity.Length > 0, acquiredIdentity);
        _executing = null;
    }
    private static SubjectiveActionKindV1 ActionKind(PublicPlayerCandidate candidate)
    {
        if (Enum.TryParse<SubjectiveActionKindV1>(candidate.EffectKind, out var explicitKind)) return explicitKind;
        return candidate.Purpose switch
        {
            "close" or "cancel" => SubjectiveActionKindV1.Withdraw,
            "destroy" => SubjectiveActionKindV1.Destroy,
            "hide" => SubjectiveActionKindV1.Hide,
            "hypothesis" => SubjectiveActionKindV1.Edit,
            "statement" => SubjectiveActionKindV1.Assert,
            "evidence" => SubjectiveActionKindV1.Present,
            "commit" => SubjectiveActionKindV1.Commit,
            "tab" => SubjectiveActionKindV1.Open,
            "panel" or "argument" => SubjectiveActionKindV1.Open,
            _ => candidate.Kind switch
            {
                "move" => SubjectiveActionKindV1.Travel,
                "interact" => candidate.Location is null ? SubjectiveActionKindV1.Observe : SubjectiveActionKindV1.Open,
                "wait" => SubjectiveActionKindV1.Wait,
                "continue" => SubjectiveActionKindV1.Acknowledge,
                "form_field" => SubjectiveActionKindV1.Edit,
                "form_submit" => SubjectiveActionKindV1.Test,
                _ => SubjectiveActionKindV1.Observe
            }
        };
    }
    public PlayerDecision Decide(PublicPlayerObservation observation, PlayerCognition cognition)
    {
        CompleteObservedExecution(observation, cognition);
        if (observation.Candidates.IsEmpty && (!observation.CompleteMethodMenu || observation.CompleteScopeIds.IsEmpty)) return new(null, "candidate_missing", null);
        if (!cognition.Snapshot.Projections.Any(p => p.Id == cognition.Actor)) return new(null, "actor_cognition_missing", null);
        if (cognition.Agency is not null) _state = cognition.Agency;
        _state ??= new(cognition.Actor, _seed);
        if (_state.Actor != cognition.Actor) throw new PlayerBoundaryException("subject_changed");
        _space = observation.Field?.Space ?? _space;
        _lastObservation = observation; _lastCognition = cognition;
        var snapshot = cognition.Snapshot;
        var budget = _declaration.Reasoning;
        var reasoner = new SubjectiveReasoner(snapshot, cognition.Actor, new(budget.Depth, budget.Expansions, budget.Hypotheses));
        var materialIndex = snapshot.Projections.SelectMany(p => p.KnownTerms.Select(t =>
            (Key: "material:" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(t.TermId.Value))), Projection: p)))
            .GroupBy(p => p.Key).ToDictionary(g => g.Key, g => g.Select(p => p.Projection).DistinctBy(p => p.Id).ToArray());
        var sourceIndex = snapshot.Projections.SelectMany(p => p.KnownTerms.Where(t => t.TermId.Value.StartsWith("public-source.", StringComparison.Ordinal))
            .Select(t => (Key: t.TermId.Value, Projection: p))).GroupBy(p => p.Key)
            .ToDictionary(g => g.Key, g => g.Select(p => p.Projection).DistinctBy(p => p.Id).ToArray());
        FrozenProjectionV1[] Materials(PublicPlayerCandidate c)
        {
            if (c.MaterialId.Length > 0)
                return materialIndex.GetValueOrDefault(c.MaterialId) ?? [];
            if (c.SourceId.Length > 0)
                return sourceIndex.GetValueOrDefault("public-source." + c.SourceId) ?? [];
            var exact = snapshot.Projections.Where(p => p.Name.Length > 0 && (c.Value == p.Name || c.Label == p.Name)
                || p.KnownTerms.Any(t => t.CanonicalLexeme.Length > 0 && (c.Value == t.CanonicalLexeme || c.Label == t.CanonicalLexeme))).ToArray();
            return exact.Length > 0 ? exact : snapshot.Projections.Where(p => p.Tags.GetValueOrDefault(AcquiredPropositions.Opportunity) != 1
                && p.KnownTerms.Any(t => t.CanonicalLexeme.Length > 0 && c.Label.Contains(t.CanonicalLexeme, StringComparison.Ordinal))).ToArray();
        }
        var question = snapshot.Projections.LastOrDefault(p => p.Tags.GetValueOrDefault(AcquiredPropositions.Question) == 1);
        var goal = question is null ? null : reasoner.Claims(question.Id).FirstOrDefault();
        var form = observation.Candidates.Any(c => c.Kind is "form_field" or "form_submit" || c.Purpose == "tab");
        var questionId = goal is null ? "" : Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(goal)));
        var scope = form ? "form:" + questionId : "methods";
        var next = ImmutableArray.CreateBuilder<SubjectiveOfferV1>();
        _offers.Clear();
        foreach (var candidate in observation.Candidates)
        {
            if (candidate.Semantic is { } shared)
            {
                var projected = shared with { Id = candidate.Token };
                next.Add(projected); _offers[candidate.Token] = projected; continue;
            }
            var material = Materials(candidate);
            var source = candidate.SourceId.Length > 0 ? candidate.SourceId
                : candidate.Kind == "move" ? "ground:" + _space
                : candidate.Kind == "interact" && candidate.MethodId.Length > 0 ? "source:" + candidate.MethodId
                : candidate.Kind == "interact" ? CompatibilityIdentity(_space + ":source:" + candidate.Label)
                : candidate.Purpose == "panel" ? CompatibilityIdentity(_space + ":panel:" + candidate.MethodId)
                : _source.Length > 0 ? _source : "public:" + _space;
            var method = candidate.MethodId.Length > 0 ? candidate.MethodId : CompatibilityIdentity(candidate.Kind + ":" + candidate.Label);
            if (form && candidate.MethodId.Length == 0) method += ":question:" + questionId;
            if (candidate.Kind == "move" && candidate.DestinationSourceId.Length == 0 && candidate.Location is { } point)
                method += ":" + Math.Floor(point.X / 64) + ":" + Math.Floor(point.Y / 64);
            else if (candidate.Purpose == "approach" && candidate.Location is { } waypoint)
                method += ":" + Math.Floor(waypoint.X / 64) + ":" + Math.Floor(waypoint.Y / 64);
            var kind = ActionKind(candidate);
            if (kind == SubjectiveActionKindV1.Commit && observation.Candidates.Any(c => c.Purpose == "hypothesis")
                && !observation.Candidates.Any(c => c.Purpose is "statement" or "evidence")) kind = SubjectiveActionKindV1.Test;
            var preferences = _declaration.Rules.Where(r => (r.LabelContains.Length == 0 || candidate.Label.Contains(r.LabelContains, StringComparison.Ordinal))
                && (r.Kind == candidate.Kind || r.Kind is "new" or "untried"))
                .Select(r => new SubjectiveOfferPreferenceV1(r.Kind == "new" ? SubjectivePreferenceConditionV1.New
                    : r.Kind == "untried" ? SubjectivePreferenceConditionV1.Untried : SubjectivePreferenceConditionV1.Always,
                    Enum.Parse<RuleMode>(r.Mode, true), r.Weight,
                    "authored_rule:" + r.Mode + ":" + r.Kind + ":" + r.Weight
                        + (r.LabelContains.Length > 0 ? ":public_label=" + r.LabelContains : ""))).ToImmutableArray();
            var context = _space;
            if (candidate.Kind == "interact" && candidate.Location is { } target && observation.Field is { } field)
                context += ":contact:" + Math.Floor(field.Position.X / 64) + ":" + Math.Floor(field.Position.Y / 64)
                    + ":" + Math.Floor(target.X / 64) + ":" + Math.Floor(target.Y / 64);
            var offer = new SubjectiveOfferV1(candidate.Token, source + ":" + method, source, kind)
            {
                Materials = [..material.Select(p => p.Id)], Claims = [..material.SelectMany(p => reasoner.Claims(p.Id)).Distinct()],
                GroupId = candidate.Group, Context = context, ScopeId = form ? scope : candidate.ScopeId.Length > 0 ? candidate.ScopeId : scope, Preferences = preferences,
                Novel = candidate.New, Selected = candidate.Selected, Presentable = material.Any(p => p.Tags.GetValueOrDefault(AcquiredPropositions.Presentable) == 1),
                AcquiresInformation = kind is SubjectiveActionKindV1.Observe or SubjectiveActionKindV1.Test,
                RequiresEvidence = form && observation.Candidates.Any(c => c.Purpose == "evidence"),
                Frontier = candidate.Purpose == "frontier", KnownGround = candidate.KnownGround,
                Cost = (int)Math.Min(1000000, Math.Ceiling(candidate.TravelDistance / 64) * Math.Max(0, _declaration.Rules.Where(r => r.Kind == "untried" && r.Mode == "prefer").Select(r => r.Weight).DefaultIfEmpty(1).Max())),
                Distance = candidate.TravelDistance, DestinationSourceId = candidate.DestinationSourceId.Length > 0
                    ? candidate.DestinationSourceId : candidate.Kind == "interact" && candidate.Location is not null ? source : ""
            };
            next.Add(offer); _offers[candidate.Token] = offer;
        }
        var completeScopes = observation.CompleteMethodMenu && !form && _source.Length > 0
            && !observation.Candidates.Any(c => c.Kind is "move" or "interact")
            ? (observation.CompleteScopeIds.IsEmpty
                ? observation.Candidates.Select(c => c.ScopeId.Length > 0 ? c.ScopeId : scope)
                : observation.CompleteScopeIds).Select(id => new SubjectiveMethodScopeV1(_source, id)).Distinct().ToImmutableArray()
            : ImmutableArray<SubjectiveMethodScopeV1>.Empty;
        var request = new SubjectiveAgentRequestV1(snapshot, cognition.Actor, new(budget.Depth, budget.Expansions, budget.Hypotheses), next.ToImmutable(),
            new(_declaration.Rules.Where(r => r.Kind == "untried" && r.Mode == "prefer").Select(r => r.Weight).DefaultIfEmpty(1).Max(), budget.InformationWeight, budget.ArgumentWeight))
            { Goal = goal, CompleteMethodScopes = completeScopes,
              PresentableMaterials = [..snapshot.Projections.Where(p => p.Tags.GetValueOrDefault(AcquiredPropositions.Presentable) == 1).Select(p => p.Id)] };
        if (cognition.Investigation is { } investigation && observation.Candidates.Any(c => c.Semantic is not null))
            request = request with
            {
                Goal = request.Goal is null ? investigation.Goal : investigation.Goal is null ? request.Goal
                    : new FrozenConditionV1.Any([request.Goal, investigation.Goal]),
                CompleteMethodScopes = [..request.CompleteMethodScopes.Concat(investigation.CompleteMethodScopes).Distinct()],
                PresentableMaterials = [..request.PresentableMaterials.Concat(investigation.PresentableMaterials).Distinct()],
                Budget = investigation.Budget, Motives = investigation.Motives
            };
        var choice = SubjectiveAgent.Decide(request, _state);
        if (choice.OfferId is null) return new(null, observation.Candidates.IsEmpty ? "candidate_missing" : "agent_cannot_assess", null);
        var chosen = observation.Candidates.First(c => c.Token == choice.OfferId);
        _selected.Clear(); _selected[chosen.Token] = chosen;
        var assessment = choice.Assessment.Offers.First(a => a.Offer.Id == chosen.Token);
        string Name(SubjectProjectionId id) => snapshot.Projections.FirstOrDefault(p => p.Id == id)?.Name ?? "acquired_material";
        string Claim(FrozenConditionV1 condition) => string.Join(" / ", reasoner.References(condition).Select(Name));
        PlayerArgument Argument(SubjectiveProofV1 proof) => new(Claim(proof.Proposition), proof.Value.ToString(), proof.Complete,
            [..proof.Basis.Select(Name)], proof.Steps)
            { Missing = [..proof.Missing.Select(Claim)], Derivations = [..proof.Derivations.Select(d => new PlayerInference(Claim(d.Conclusion), [..d.Premises.Select(Claim)], Name(d.Source)))] };
        return new(chosen.Token, "subjective_rules", assessment.Score)
        {
            Basis = assessment.Basis, ReasoningExpansions = choice.Assessment.Reasoning.Expansions,
            ReasoningStop = choice.Assessment.Reasoning.StopReason, HypothesesCompared = choice.Assessment.Reasoning.Predictions.Length,
            Arguments = [..assessment.Arguments.Select(Argument)],
            Alternatives = [..choice.Assessment.Offers.Where(a => !a.Forbidden).Select(a =>
                { var c = observation.Candidates.First(c => c.Token == a.Offer.Id); return new PlayerAlternative(c.Token, c.Label, c.Kind, a.Score, a.Basis); })]
        };
    }
}

/// <summary>Trusted token translation into the unchanged player Dispatch entry.
/// All source IDs, raw state, presentation IDs and command payloads stay here.</summary>
public sealed class PlayerCandidateSession : IPlayerCandidatePort
{
    private sealed record Offer(PublicPlayerCandidate Visible, Dictionary<string, object?> Input, string? Field = null, object? Value = null, bool Tab = false);
    private readonly Func<IReadOnlyDictionary<string, object?>, IReadOnlyList<Dictionary<string, object?>>> _dispatch;
    private readonly string _selfName;
    private readonly int _maxSelections, _maxObservations;
    private readonly Action<IReadOnlyDictionary<string, object?>>? _observeField;
    private readonly Func<IReadOnlyDictionary<string, object?>, SubjectiveOfferV1?>? _semantic;
    private readonly string _session = Guid.NewGuid().ToString("N");
    private readonly Dictionary<string, Offer> _offers = new(StringComparer.Ordinal);
    // A refresh keeps the token of a choice that is still offered unchanged; consumed or withdrawn choices expire.
    private Dictionary<string, string> _standing = new(StringComparer.Ordinal);
    // The host's latest field/panel offers stay on the table across lifecycle refreshes until consumed or replaced.
    private IReadOnlyList<PlayerFieldOffer>? _hostOffers;
    private readonly Dictionary<string, string> _identities = new(StringComparer.Ordinal);
    private Dictionary<string, object?>? _pending;
    private Dictionary<string, object?>? _underlyingModal;
    private string _activeField = "";
    private readonly Dictionary<string, object?> _values = new(StringComparer.Ordinal);
    private long _serial, _turn;
    private bool _closed;
    public int Selections { get; private set; }
    public PublicPlayerObservation Current { get; private set; } = new(0, [], [], [], false);
    public IReadOnlyList<Dictionary<string, object?>> LastOutput { get; private set; } = [];
    public IReadOnlyDictionary<string, object?>? LastInput { get; private set; }
    public PlayerCandidateSession(Func<IReadOnlyDictionary<string, object?>, IReadOnlyList<Dictionary<string, object?>>> dispatch,
        string selfName, int maxSelections = 10000, int maxObservations = 20000,
        Action<IReadOnlyDictionary<string, object?>>? observeField = null,
        Func<IReadOnlyDictionary<string, object?>, SubjectiveOfferV1?>? semantic = null)
    {
        if (maxSelections < 0 || maxObservations < 1) throw new ArgumentOutOfRangeException(nameof(maxSelections));
        (_dispatch, _selfName, _maxSelections, _maxObservations) = (dispatch, selfName, maxSelections, maxObservations);
        _observeField = observeField; _semantic = semantic;
    }
    private void Open() { if (_closed) throw new PlayerBoundaryException("boundary_closed"); }
    private PlayerBoundaryException Fail(string code) { _closed = true; _offers.Clear(); return new(code); }
    public void Close() { _closed = true; _offers.Clear(); }
    private static IEnumerable<IReadOnlyDictionary<string, object?>> Maps(IReadOnlyDictionary<string, object?> map, string key)
        => (map.GetValueOrDefault(key) as System.Collections.IEnumerable ?? Array.Empty<object>()).Cast<object?>().OfType<IReadOnlyDictionary<string, object?>>();
    // Mirrors FormPanel.uses_columns: small tab forms are rendered side by side.
    // Their fields are simultaneously visible and the UI has no tab buttons.
    private static bool UsesColumns(IReadOnlyDictionary<string, object?> form) => Text(form, "layout") == "tabs"
        && Maps(form, "fields").Count() is >= 2 and <= 3;
    private static bool UsesTabs(IReadOnlyDictionary<string, object?> form) => Text(form, "layout") == "tabs" && !UsesColumns(form);
    private static string ScopeIdentity(IReadOnlyDictionary<string, object?> menu)
    {
        var identity = Text(menu, "method_scope", Text(menu, "id", Text(menu, "kind")));
        return identity.Length == 0 ? "" : "scope:" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(identity)));
    }
    private void Add(string label, string kind, Dictionary<string, object?> input, bool isNew = false, string? field = null, object? value = null, bool tab = false, string group = "", string publicValue = "", string purpose = "", bool selected = false, PlayerPoint? location = null, double travelDistance = 0, bool knownGround = false, string sourceId = "", string methodId = "", string destinationSourceId = "", string effectKind = "", string sourceState = "", SubjectiveOfferV1? semantic = null)
    {
        if (_offers.Count >= 256) throw Fail("candidate_limit");
        if (!double.IsFinite(travelDistance) || travelDistance < 0 || travelDistance > 1000000) throw Fail("invalid_travel_distance");
        var scopeId = _pending is null ? "" : ScopeIdentity(_pending);
        var materialId = Text(input, "choice_id") is { Length: > 0 } choice ? AcquiredPropositions.PublicMaterialIdentity("choice", choice)
            : Text(input, "card_id") is { Length: > 0 } card ? AcquiredPropositions.PublicMaterialIdentity("card", card)
            : kind == "form_field" && value is not null ? AcquiredPropositions.PublicMaterialIdentity("statement", value.ToString()!) : "";
        if (methodId.Length == 0)
        {
            // Mechanism identities survive re-presentation; presentation IDs and
            // submission tokens never form the experience identity.
            var mechanism = new[] { "choice_id", "card_id", "site", "panel", "node_id", "action", "to" }
                .Select(key => key + "=" + Text(input, key)).Where(key => !key.EndsWith('=')).ToArray();
            var identityFields = new object?[] { kind, scopeId, field, value?.ToString(), tab, mechanism,
                mechanism.Length == 0 && field is null ? label : "" };
            methodId = "method:" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(identityFields)));
        }
        var identity = JsonSerializer.Serialize(new object?[] { label, kind, isNew, group, publicValue, purpose, selected, location?.X, location?.Y, travelDistance, knownGround, input, field, value?.ToString(), tab, sourceId, methodId, destinationSourceId, effectKind, sourceState });
        if (!_standing.TryGetValue(identity, out var token) || _offers.ContainsKey(token)) token = "player:" + _session + ":" + ++_serial;
        _identities[token] = identity;
        semantic ??= _semantic?.Invoke(input);
        if (_pending is not null && Text(_pending, "method_scope").StartsWith("room_sources:", StringComparison.Ordinal)
            && Text(input, "choice_id") != "close" && semantic is null) return;
        _offers.Add(token, new(new(token, label, kind, isNew, group, publicValue, purpose, selected) { Location = location, ArrivalRadius = input.TryGetValue("goal_reach", out var publicReach) ? Convert.ToDouble(publicReach) + 6 : 12, Traversal = input.TryGetValue("entry_crossing", out var publicCrossing) && Convert.ToBoolean(publicCrossing), TravelDistance = travelDistance, KnownGround = knownGround, SourceId = sourceId, MethodId = methodId, DestinationSourceId = destinationSourceId, EffectKind = effectKind, ScopeId = scopeId, MaterialId = materialId, SourceState = sourceState, Semantic = semantic }, input, field, value, tab));
    }
    public PublicPlayerObservation Observe(IReadOnlyList<Dictionary<string, object?>> output,
        IReadOnlyList<PlayerFieldOffer>? fieldOffers = null)
    {
        Open();
        if (_turn >= _maxObservations) throw Fail("observation_budget");
        // Only a refresh without a new presentation keeps standing tokens; a re-presented choice is a new offer.
        _standing = new(StringComparer.Ordinal);
        if (!output.Any(e => Text(e, "kind") is "lines" or "card" or "candidates" or "form" or "ending"))
            foreach (var standing in _offers.Keys) _standing.TryAdd(_identities[standing], standing);
        _offers.Clear(); _identities.Clear(); LastOutput = output;
        var lines = ImmutableArray.CreateBuilder<PublicPlayerLine>();
        var text = ImmutableArray.CreateBuilder<string>();
        var complete = false;
        var executionResults = ImmutableArray.CreateBuilder<PublicExecutionResult>();
        foreach (var ev in output)
        {
            var kind = Text(ev, "kind");
            if (kind == "execution_result")
                executionResults.Add(new(Text(ev, "source_id"), Text(ev, "method_id"), Text(ev, "information_identity"), Flag(ev, "succeeded")));
            if (kind == "lines")
                foreach (var line in Maps(ev, "lines")) lines.Add(new(Text(line, "speaker_name", Text(line, "speaker")), Text(line, "mood"), Text(line, "text")));
            if (kind is "lines" or "card" or "candidates" or "form" or "ending")
            {
                foreach (var key in new[] { "title", "prompt", "intro", "facts", "source", "text", "outcome" })
                    if (Text(ev, key) is { Length: > 0 } value) text.Add(value);
                foreach (var key in new[] { "notes", "rows", "items" })
                    if (ev.GetValueOrDefault(key) is IEnumerable<object?> entries)
                        text.AddRange(entries.OfType<string>());
                if (ev.GetValueOrDefault("table") is IEnumerable<object?> table)
                    foreach (var row in table.OfType<IEnumerable<object?>>())
                        text.Add(string.Join("\t", row.OfType<string>()));
                var header = Map(ev, "header");
                foreach (var key in new[] { "question", "instructions" })
                    if (Text(header, key) is { Length: > 0 } value) text.Add(value);
                foreach (var option in Maps(ev, kind == "lines" ? "choices" : "options").Where(o => !Flag(o, "available", true)))
                    text.Add(Text(option, "label") + " " + Text(option, "lock_hint"));
                if (kind == "lines")
                {
                    if (_pending is not null && Text(_pending, "kind") != "lines")
                        _underlyingModal = _pending;
                    _pending = ev;
                }
                else
                {
                    _pending = ev; _underlyingModal = null; _values.Clear();
                }
                if (kind == "form")
                    foreach (var field in Maps(ev, "fields"))
                    {
                        var initial = Text(field, "value");
                        if (initial.Length > 0 && (Text(field, "kind") == "text"
                            || Maps(field, "options").Any(o => Text(o, "id") == initial && Flag(o, "available", true))))
                            _values[Text(field, "id")] = initial;
                    }
                if (kind != "lines") _activeField = Maps(ev, "fields").Select(f => Text(f, "id")).FirstOrDefault() ?? "";
                if (kind == "ending") complete = !Maps(ev, "actions").Any(a => Text(a, "id") is "continue" or "chapter2");
            }
            if (kind is "aside" or "error") text.Add(Text(ev, kind == "error" ? "message" : "text"));
            if (kind == "player_panel_view" && ev.GetValueOrDefault("rows") is IEnumerable<string> panelText) text.AddRange(panelText);
            if (kind == "replay_play")
                foreach (var key in new[] { "title", "caption" })
                    if (Text(ev, key) is { Length: > 0 } value) text.Add(value);
            if (kind == "error") { _closed = true; _pending = null; _underlyingModal = null; }
            if (kind == "close") { _pending = null; _underlyingModal = null; _values.Clear(); _activeField = ""; }
            if (kind == "state")
            {
                var hud = Map(Map(ev, "snapshot"), "hud");
                foreach (var key in new[] { "title", "time" }) if (Text(hud, key) is { Length: > 0 } value) text.Add(value);
            }
            if (kind == "replay_play" && Text(ev, "mode") is not ("stage" or "campus")) throw Fail("unsupported_replay_presentation");
        }
        if (_pending is { } form && Text(form, "kind") == "form")
            foreach (var field in Maps(form, "fields").Where(f => !UsesTabs(form) || Text(f, "id") == _activeField))
            {
                foreach (var key in new[] { "heading", "placeholder", "empty_text" })
                    if (Text(field, key) is { Length: > 0 } value) text.Add(value);
                foreach (var option in Maps(field, "options"))
                    text.Add(Text(option, "label") + (Flag(option, "available", true) ? "" : " " + Text(option, "lock_hint")));
            }
        if (fieldOffers is not null) _hostOffers = fieldOffers;
        else if (_standing.Count == 0) _hostOffers = null;
        if (!_closed && !complete)
        {
            if (_pending is { } pending) BuildPending(pending);
            else if (_hostOffers is not null)
                foreach (var offer in _hostOffers)
                {
                    if (offer.Kind is not ("move" or "interact" or "wait" or "menu" or "form_field" or "form_submit" or "continue")) throw Fail("unsupported_field_offer");
                    Add(offer.Label, offer.Kind, offer.Input.ToDictionary(p => p.Key, p => p.Value), offer.New, group: offer.Group, publicValue: offer.Value, purpose: offer.Purpose, selected: offer.Selected, location: offer.Location, travelDistance: offer.TravelDistance, knownGround: offer.KnownGround, sourceId: offer.SourceId, methodId: offer.MethodId, destinationSourceId: offer.DestinationSourceId, effectKind: offer.EffectKind, sourceState: offer.SourceState, semantic: offer.Semantic);
                }
        }
        var completeMenu = _pending is { } menu && (Text(menu, "kind") is "lines" or "card" or "candidates");
        var completeScope = completeMenu ? ScopeIdentity(_pending!) : "";
        Current = new(++_turn, lines.ToImmutable(), text.ToImmutable(), [.._offers.Values.Select(o => o.Visible)], complete)
            { Field = Current.Field, ExecutionResults = executionResults.ToImmutable(), CompleteMethodMenu = completeMenu, CompleteScopeIds = completeScope.Length > 0 ? [completeScope] : [] };
        if (System.Text.Encoding.UTF8.GetByteCount(JsonSerializer.Serialize(Current)) > 65536) throw Fail("observation_limit");
        return Current;
    }
    public void Locate(PlayerFieldState field)
    {
        Open();
        if (field.Space.Length is < 1 or > 128 || !double.IsFinite(field.Position.X) || !double.IsFinite(field.Position.Y))
            throw Fail("invalid_field_observation");
        Current = Current with { Field = field };
    }
    private void BuildPending(Dictionary<string, object?> pending)
    {
        var kind = Text(pending, "kind");
        var pid = Text(pending, "presentation_id");
        if (kind == "form")
        {
            var tabs = UsesTabs(pending);
            var columns = UsesColumns(pending);
            foreach (var field in Maps(pending, "fields"))
            {
                var id = Text(field, "id");
                if (tabs && id != _activeField || !tabs && !columns && _values.ContainsKey(id)) continue;
                var fieldKind = Text(field, "kind");
                _observeField?.Invoke(field);
                if (fieldKind == "choice")
                    foreach (var option in Maps(field, "options").Where(o => Flag(o, "available", true)))
                        Add(Text(field, "heading") + " " + Text(option, "label"), "form_field", [], field: id, value: Text(option, "id"), group: Text(field, "heading"), publicValue: Text(option, "label"), purpose: Text(field, "purpose"), selected: _values.GetValueOrDefault(id)?.ToString() == Text(option, "id"));
                else if (fieldKind == "text")
                    Add(Text(field, "placeholder") + " " + _selfName, "form_field", [], field: id, value: _selfName);
                else throw Fail("unsupported_form_field");
                // One field at a time, as in the ordinary form. Empty fields stay empty;
                // action requirements below must still pass before submission.
                if (!columns && _offers.Count > 0) break;
            }
            foreach (var action in Maps(pending, "actions").Where(a => Flag(a, "available", true)))
            {
                var required = (action.GetValueOrDefault("requires") as IEnumerable<object?> ?? []).Select(v => v?.ToString() ?? "");
                if (required.Any(id => !_values.TryGetValue(id, out var value) || string.IsNullOrEmpty(value?.ToString()))) continue;
                if (action.ContainsKey("tab"))
                {
                    if (columns) continue;
                    var target = Text(action, "tab");
                    if (Maps(pending, "fields").Any(f => Text(f, "id") == target))
                        Add(Text(action, "label"), "menu", [], field: target, tab: true, purpose: "tab", selected: target == _activeField);
                    continue;
                }
                Add(Text(action, "label"), "form_submit", Event("form", ("presentation_id", pid), ("action", Text(action, "id")), ("values", new Dictionary<string, object?>(_values))), purpose: required.Any() || Flag(action, "default") ? "commit" : "cancel");
            }
            return;
        }
        if (kind == "ending")
        {
            foreach (var action in Maps(pending, "actions").Where(a => Text(a, "id") is "continue" or "chapter2"))
                Add(Text(action, "label"), "continue", Event("navigate", ("to", Text(action, "id"))));
            return;
        }
        var options = Maps(pending, kind == "lines" ? "choices" : "options").ToArray();
        foreach (var option in options.Where(o => Flag(o, "available", true)))
        {
            // The same exits the shared UI treats as its back button.
            var id = Text(option, "id");
            var purpose = Text(option, "purpose") is { Length: > 0 } declared ? declared
                : id is "close" or "cancel" || id.EndsWith(":close", StringComparison.Ordinal) ? "close" : "";
            Add(Text(option, "label"), "menu", Event("select", ("presentation_id", pid), ("choice_id", id), ("token", Text(option, "token"))), purpose: purpose);
        }
        if (options.Length == 0 && pid != "") Add("", "continue", Event("presented", ("presentation_id", pid)));
    }
    public IReadOnlyDictionary<string, object?> Peek(string token)
    {
        Open();
        if (!_offers.TryGetValue(token, out var offer)) throw new PlayerBoundaryException("unknown_consumed_or_expired_token");
        if (offer.Field is { } field)
            return offer.Tab ? Event("form_tab", ("field", field)) : Event("form_field", ("field", field), ("value", offer.Value));
        return offer.Input.ToDictionary(p => p.Key, p => p.Value);
    }
    public PublicPlayerObservation Submit(SelectCandidate selection)
    {
        Open();
        if (Selections >= _maxSelections) throw Fail("selection_budget");
        if (!_offers.TryGetValue(selection.Token, out var offer)) throw Fail("unknown_consumed_or_expired_token");
        _offers.Clear(); _identities.Clear(); _hostOffers = null; Selections++;
        if (offer.Field is { } field)
        {
            if (offer.Tab) _activeField = field;
            else _values[field] = offer.Value;
            LastInput = offer.Tab ? Event("form_tab", ("field", field)) : Event("form_field", ("field", field), ("value", offer.Value));
            LastOutput = [];
            // Preserve the current form but issue a fresh token batch.
            return Observe([]);
        }
        var submittedPresentation = Text(offer.Input, "presentation_id");
        if (_pending is not null && Text(_pending, "kind") == "lines" && submittedPresentation == Text(_pending, "presentation_id"))
        {
            _pending = _underlyingModal;
            _underlyingModal = null;
        }
        else
        {
            _pending = null; _underlyingModal = null; _values.Clear(); _activeField = "";
        }
        LastInput = offer.Input;
        try { return Observe(_dispatch(offer.Input)); }
        catch { _closed = true; _offers.Clear(); throw; }
    }
}
