using System.Reflection;
using DualOntologyWorldEngine.Core;
using DualOntologyWorldEngine.Story;

// Neutral execution receipts only; no chapter content or authority-state access.
var passed = 0; var failed = 0;
void Check(string name, bool holds) { Console.WriteLine((holds ? "PASS " : "FAIL ") + name); if (holds) passed++; else failed++; }
var runtime = new WorldRuntime();
using var simulation = new SimulationSession(runtime);
var world = new CoreScriptWorld(runtime, simulation);
var actor = world.DefineCharacter("neutral.unified.actor", "A", world.DefineSpace("neutral.unified.room", "R"));
var cognition = new PlayerCognition(((ContractResult<CognitionSnapshotV1>.Success)actor.Soul.World.CaptureSnapshot()).Value, actor.Self.SubjectId!.Value);
SubjectivePlayerController Controller() => new(new() { Actor = "neutral.unified.actor", Name = "A", Mode = "agent", Rules = [new() { Mode = "prefer", Kind = "untried", Weight = 6 }] }, 23);
SubjectiveAgentState State(SubjectivePlayerController c) => (SubjectiveAgentState)(typeof(SubjectivePlayerController).GetField("_state", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(c)!);
PublicPlayerCandidate Offer(string token, string kind = "menu", string source = "neutral.source", string method = "neutral.method") => new(token, "same-name", kind, false) { SourceId = source, MethodId = method, EffectKind = kind == "move" ? "Travel" : "Observe", Location = kind == "move" ? new(100, 0) : null, KnownGround = true };
PublicPlayerObservation At(long turn, double x, params PublicPlayerCandidate[] offers) => new(turn, [], [], [.. offers], false) { Field = new("neutral.room", new(x, 0)) };

var controller = Controller();
controller.Decide(At(1, 0, Offer("first")), cognition);
Check("selection_does_not_record_attempt", State(controller).Memory.Experiences.IsEmpty);
Check("actual_start_accepted", controller.StartExecution("first"));
controller.Decide(new(2, [], ["neutral finished"], [], true) { Field = new("neutral.room", new(0, 0)) }, cognition);
Check("terminal_empty_candidate_observation_settles_execution", State(controller).Memory.Experiences.Sum(e => e.Successes) == 1);

controller = Controller();
controller.Decide(At(1, 0, Offer("failed", "interact")), cognition);
controller.StartExecution("failed"); controller.CompleteInteraction("failed", false);
controller.CompleteInteraction("failed", false);
Check("failure_receipt_idempotent", State(controller).Memory.Experiences.Sum(e => e.Failures) == 1 && State(controller).Memory.Experiences.Sum(e => e.Attempts) == 1);

controller = Controller();
controller.Decide(At(1, 0, Offer("still", "move")), cognition); controller.StartExecution("still");
controller.Decide(At(2, 0, Offer("next", "move")), cognition);
Check("real_stationary_move_no_progress", State(controller).Memory.Experiences.Sum(e => e.NoProgress) == 1);

controller = Controller();
controller.Decide(At(1, 0, Offer("source-a")), cognition); controller.StartExecution("source-a");
controller.Decide(At(2, 0, Offer("source-b", source: "neutral.other")), cognition);
Check("same_label_distinct_sources_isolated", State(controller).Memory.Experiences.Single().Key.Method.StartsWith("neutral.source:") && !State(controller).Memory.Experiences.Any(e => e.Key.Method.StartsWith("neutral.other:")));

var port = new PlayerCandidateSession(_ => [], "A", 10, 100);
Dictionary<string, object?> Menu(string presentation) => ChapterEvents.Event("candidates", ("presentation_id", presentation),
    ("options", new object[] { ChapterEvents.Option("neutral.choice.a", "same-name"), ChapterEvents.Option("neutral.choice.b", "same-name") }));
var publicFirst = port.Observe([Menu("neutral.presentation.a")]);
var publicNext = port.Observe([Menu("neutral.presentation.b")]);
Check("same_label_port_materials_isolated", publicFirst.Candidates.Length == 2 && publicFirst.Candidates.Select(c => c.MaterialId).Distinct().Count() == 2);
Check("port_material_identity_stable_across_token_refresh", publicFirst.Candidates.Select(c => c.MaterialId).SequenceEqual(publicNext.Candidates.Select(c => c.MaterialId)) && !publicFirst.Candidates.Select(c => c.Token).SequenceEqual(publicNext.Candidates.Select(c => c.Token)));

Console.WriteLine($"UnifiedHostCheck: {passed} passed, {failed} failed");
Environment.ExitCode = failed == 0 ? 0 : 1;
