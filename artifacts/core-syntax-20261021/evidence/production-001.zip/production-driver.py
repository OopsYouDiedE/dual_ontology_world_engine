import hashlib,json,os,shutil,subprocess,sys,time,traceback,zipfile
from pathlib import Path
repo=Path("C:\\Users\\iii\\AppData\\Local\\Temp\\dv-core-syntax-20261021-2daad96f252343a69a7c7f37634a5364\\worktree")
out=Path("C:\\Users\\iii\\AppData\\Local\\Temp\\dvcore-c21-2daad9-p1")
out.mkdir(exist_ok=False)
shutil.copyfile(__file__,out/'production-driver.py')
excluded={'bin','obj','__pycache__','node_modules'}
inputs=[repo/'AGENTS.md',repo/'docs/syntax.md']
inputs += [p for p in (repo/'language_core').rglob('*') if p.is_file() and not excluded.intersection(p.relative_to(repo).parts)]
manifest=[{'path':p.relative_to(repo).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(inputs)]
(out/'source-manifest.json').write_text(json.dumps({'root':str(repo),'inputs':manifest},indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(out/'source-snapshot.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in inputs: z.writestr(p.relative_to(repo).as_posix(),p.read_bytes())
def unchanged():
    for item in manifest:
        assert hashlib.sha256((repo/item['path']).read_bytes()).hexdigest()==item['sha256'], item['path']
commands=[
['dotnet','build','language_core/LanguageCore.sln','-c','Release','--disable-build-servers','-p:NuGetAudit=false','-p:DvPython='+sys.executable],
[sys.executable,'language_core/tools/check_dv.py','--format','json','language_core/30-session.dv']
]
summary={'scope':'production closure build and editor compiler diagnostics; content not executed','status':'incomplete','commands':[]}
env=os.environ.copy()
env['NuGetAudit']='false'
env['DOTNET_CLI_TELEMETRY_OPTOUT']='1'
env['DOTNET_CLI_UI_LANGUAGE']='en'
try:
    for number,argv in enumerate(commands,1):
        unchanged()
        prefix=out/f'{number:02d}'
        prefix.with_suffix('.command.json').write_text(json.dumps({'argv':argv,'cwd':str(repo),'timeout':180},indent=2)+'\n')
        started=time.monotonic()
        process=subprocess.Popen(argv,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        timed_out=False
        try: stdout,stderr=process.communicate(timeout=180)
        except subprocess.TimeoutExpired:
            timed_out=True
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
            stdout,stderr=process.communicate()
        prefix.with_suffix('.stdout.txt').write_bytes(stdout)
        prefix.with_suffix('.stderr.txt').write_bytes(stderr)
        result={'returncode':process.returncode,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-started}
        prefix.with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
        summary['commands'].append(result)
        print('Production stage',number,'exit',process.returncode,flush=True)
        unchanged()
        if timed_out or process.returncode: raise RuntimeError('Production stage '+str(number)+' failed')
    summary['status']='completed'
except Exception as e:
    summary['status']='failed'
    summary['error']=str(e)
    (out/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(out/('COMPLETE' if summary['status']=='completed' else 'INCOMPLETE')).write_text(summary['status']+'\n')
print(json.dumps(summary),flush=True)
sys.exit(0 if summary['status']=='completed' else 1)
