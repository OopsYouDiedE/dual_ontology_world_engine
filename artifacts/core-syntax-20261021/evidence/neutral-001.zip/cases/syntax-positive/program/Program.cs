using DuelView.Compiled;
public static partial class DVProgram {
static object F_neutral_square(object v_x) {
return R.mul(v_x,v_x);
}
static object F_neutral_pair(object v_a,object v_b) {
return new System.Collections.Generic.List<object>(2) {v_a,v_b};
}
static object F_neutral_absolute(object v_x) {
object v_result__155;
if (R.Bool(R.lt(v_x,R.number("0")))) {
v_result__155 = R.sub(R.number("0"),v_x);
} else {
if (R.Bool(R.eq(v_x,R.number("0")))) {
v_result__155 = R.number("0");
} else {
v_result__155 = v_x;
}
}
return v_result__155;
}
static object F_neutral_arithmetic(object v_a,object v_b) {
object v_sum__281;
object v_product__294;
v_sum__281 = R.add(v_a,v_b);
v_product__294 = R.mul(v_a,v_b);
return new System.Collections.Generic.List<object>(2) {v_sum__281,v_product__294};
}
static object F_neutral_early_return(object v_x) {
object v_result__396;
if (R.Bool(R.lt(v_x,R.number("0")))) {
v_result__396 = R.number("0");
return v_result__396;
} else {
}
v_result__396 = R.add(v_x,R.number("1"));
return v_result__396;
}
static object F_neutral_sum_to(object v_n) {
object v_result__507;
v_result__507 = R.number("0");
object v_i__561 = R.number("0");
while (R.Bool(R.lt(v_i__561,v_n))) {
v_i__561 = R.add(v_i__561,R.number("1"));
v_result__507 = R.add(v_result__507,v_i__561);
}
return v_result__507;
}
static object F_neutral_old_fn(object v_x) {
if (R.Bool(R.lt(R.number("0"),v_x))) {
return R.add(v_x,R.number("2"));
} else {
return R.number("2");
}
}
static object F_neutral_expect(object v_condition,object v_label) {
if (R.Bool(R.not(v_condition))) {
return R.fail(v_label);
} else {
}
return true;
}
static object F_checks_main() {
_ = F_neutral_expect(R.eq(F_neutral_square(R.sub(R.number("0"),R.number("3"))),R.number("9")),"Formula result differs");
_ = F_neutral_expect(R.eq(R.at(F_neutral_pair(R.number("2"),R.number("5")),R.number("1")),R.number("5")),"Formula list result differs");
_ = F_neutral_expect((R.Bool((R.Bool(R.eq(F_neutral_absolute(R.sub(R.number("0"),R.number("3"))),R.number("3"))) ? (object)(R.eq(F_neutral_absolute(R.number("0")),R.number("0"))) : (object)(false))) ? (object)(R.eq(F_neutral_absolute(R.number("4")),R.number("4"))) : (object)(false)),"Named-output branch result differs");
object v_values__1144 = F_neutral_arithmetic(R.number("3"),R.number("4"));
_ = F_neutral_expect((R.Bool((R.Bool(R.eq(R.count(v_values__1144),R.number("2"))) ? (object)(R.eq(R.at(v_values__1144,R.number("0")),R.number("7"))) : (object)(false))) ? (object)(R.eq(R.at(v_values__1144,R.number("1")),R.number("12"))) : (object)(false)),"Multiple outputs do not retain list order");
_ = F_neutral_expect((R.Bool(R.eq(F_neutral_early_return(R.sub(R.number("0"),R.number("1"))),R.number("0"))) ? (object)(R.eq(F_neutral_early_return(R.number("2")),R.number("3"))) : (object)(false)),"Bare return path differs");
_ = F_neutral_expect((R.Bool(R.eq(F_neutral_sum_to(R.number("0")),R.number("0"))) ? (object)(R.eq(F_neutral_sum_to(R.number("4")),R.number("10"))) : (object)(false)),"Initialized loop output differs");
_ = F_neutral_expect((R.Bool(R.eq(F_neutral_old_fn(R.number("3")),R.number("5"))) ? (object)(R.eq(F_neutral_old_fn(R.number("0")),R.number("2"))) : (object)(false)),"Existing fn syntax changed");
_ = R.print("CHECK syntax-positive completed");
return true;
}
public static int Main(string[] args) { R.Arguments=args; try { _ = F_checks_main(); return 0; } catch(System.Exception e) { System.Console.Error.WriteLine(e.ToString()); return 1; } }
}
