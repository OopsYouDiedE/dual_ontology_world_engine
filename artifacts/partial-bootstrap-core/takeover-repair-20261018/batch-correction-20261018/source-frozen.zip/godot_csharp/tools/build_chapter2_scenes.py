"""Build every chapter-2 location: painted maps, sprites and editable Godot scenes.

Run from the repository root:  python godot_csharp/tools/build_chapter2_scenes.py
Then import in Godot:          godot --headless --editor --path godot_csharp --import

Writes
  godot_csharp/ShareAsset/Internal/Props/Chapter2/rooms/<key>.png      painted architecture / outdoor ground (1x)
  godot_csharp/ShareAsset/Internal/Props/Chapter2/props/<name>.png     chapter-2 sprites (1x)
  godot_csharp/scenes/Chapter2/Maps/<key>.tscn                         one scene per location
  godot_csharp/ShareAsset/Internal/Props/Chapter2/manifest.json        sizes, anchors, exits
Chapter-1 furniture is referenced from FirstAwakeningInterior, not duplicated.
Interior exits name the outdoors as "campus"; they are pointed at the outdoor region that holds
their spawn point (outdoor.py cuts the outdoors into six regions).
Every pixel comes from the recipes in tools/first_awakening_art and tools/chapter2_art.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

GAME = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(GAME / "tools"))

from chapter2_art import rooms  # noqa: E402
from map_text import parse_json, publish, read_json, replace_json_strings, replace_spans, require_strings  # noqa: E402

OUT = GAME / "ShareAsset/Internal/Props/Chapter2"
CH1 = "res://ShareAsset/Internal/Props/FirstAwakeningInterior"
SCENES = GAME / "scenes/Chapter2/Maps"
CELL = 32
COMPILED = GAME / "scenes/Chapter2/Script/generated_chapter_02.json"


def title_key(key):
    return f"资源.地图.{key}.标题"


def label_key(key, site):
    return f"资源.场点.{key}.{site}.标签"


def load_room_text(path=COMPILED):
    compiled = read_json(path)
    chapters = compiled.get("chapters") if isinstance(compiled, dict) else None
    if not isinstance(chapters, list) or any(not isinstance(c, dict) for c in chapters):
        raise ValueError("Compiled chapters must be an array of objects")
    matching = [c for c in chapters if c.get("id") == "chapter2"]
    if len(matching) != 1 or not isinstance(matching[0].get("design"), dict):
        raise ValueError("Expected exactly one chapter2 design")
    keys = [k for key, sites in rooms.TEXT_SITES.items()
            for k in (title_key(key), *(label_key(key, site) for site in sites))]
    return require_strings(matching[0]["design"].get("text"), keys, ("资源.地图.", "资源.场点."))


def validate_maps(keys):
    if not keys or len(set(keys)) != len(keys) or any(key not in rooms.TEXT_SITES for key in keys):
        raise ValueError("Map batch must contain distinct known interior keys")


def site_indices(sites, key):
    if not isinstance(sites, list) or any(not isinstance(s, dict) or not isinstance(s.get("id"), str) for s in sites):
        raise ValueError(f"Invalid sites: {key}")
    ids = [s["id"] for s in sites]
    if len(set(ids)) != len(ids) or set(ids) != set(rooms.TEXT_SITES[key]):
        raise ValueError(f"Duplicate, missing or unknown site: {key}")
    return {site: i for i, site in enumerate(ids)}


def resolve_room_text(room, text):
    key = room["key"]
    validate_maps([key])
    site_indices(room.get("sites"), key)
    if room.get("title_key") != title_key(key):
        raise ValueError(f"Invalid title binding: {key}")
    result = {k: v for k, v in room.items() if k != "title_key"}
    result["title"] = text[room["title_key"]]
    result["sites"] = []
    for site in room["sites"]:
        if site.get("label_key") != label_key(key, site["id"]):
            raise ValueError(f"Invalid label binding: {key}/{site['id']}")
        result["sites"].append({**{k: v for k, v in site.items() if k != "label_key"}, "label": text[site["label_key"]]})
    return result


def scene_text(source, key, text):
    """Edit only the root title and explicit Sites children, retaining node order."""
    headers = list(re.finditer(r"(?m)^\[[^\r\n]*\][ \t]*\r?$", source))
    nodes = {}
    for i, header in enumerate(headers):
        if not header.group().startswith("[node "):
            continue
        attributes = dict(re.findall(r'(\w+)="([^"]*)"', header.group()))
        name, parent = attributes.get("name"), attributes.get("parent")
        if name is None or (parent is None and name != key):
            raise ValueError(f"Unexpected root node: {key}")
        path = name if parent in (None, ".") else f"{parent}/{name}"
        if path in nodes:
            raise ValueError(f"Duplicate scene node: {path}")
        end = headers[i + 1].start() if i + 1 < len(headers) else len(source)
        nodes[path] = (attributes, header.end(), end)
    roots = [path for path, (attrs, _, _) in nodes.items() if "parent" not in attrs]
    sites = {path.removeprefix("Sites/") for path in nodes if path.startswith("Sites/")}
    if roots != [key] or "Sites" not in nodes or sites != set(rooms.TEXT_SITES[key]):
        raise ValueError(f"Missing or unknown scene root/site: {key}")
    if nodes["Sites"][0].get("parent") != "." or nodes["Sites"][0].get("type") != "Node2D":
        raise ValueError(f"Invalid Sites container: {key}")
    edits = []
    bindings = [(key, "title", title_key(key))] + [(f"Sites/{site}", "label", label_key(key, site)) for site in rooms.TEXT_SITES[key]]
    for node, field, binding in bindings:
        attrs, start, end = nodes[node]
        if field == "label" and attrs.get("type") != "Marker2D":
            raise ValueError(f"Invalid site node type: {node}")
        block = source[start:end]
        properties = list(re.finditer(rf"(?m)^metadata/{field} = ([^\r\n]*)", block))
        if len(properties) != 1:
            raise ValueError(f"Missing or duplicate metadata/{field}: {node}")
        prop = properties[0]
        value_source = prop.group(1).rstrip(" \t")
        old = parse_json(value_source)
        if not isinstance(old, str):
            raise ValueError(f"Non-string metadata/{field}: {node}")
        if old != text[binding]:
            offset = start + prop.start(1)
            edits.append((offset, offset + len(value_source), json.dumps(text[binding], ensure_ascii=False)))
    return replace_spans(source, edits)


def update_text_only(keys, compiled=COMPILED, scenes=SCENES, manifest_path=OUT / "manifest.json"):
    validate_maps(keys)
    text = load_room_text(compiled)
    manifest_source = manifest_path.read_bytes().decode("utf-8")
    manifest = parse_json(manifest_source)
    entries = manifest.get("rooms") if isinstance(manifest, dict) else None
    if not isinstance(entries, dict):
        raise ValueError("Manifest rooms must be an object")
    replacements, candidates = {}, {}
    for key in keys:
        entry = entries.get(key)
        if not isinstance(entry, dict):
            raise ValueError(f"Missing manifest room: {key}")
        indices = site_indices(entry.get("sites"), key)
        replacements[("rooms", key, "title")] = text[title_key(key)]
        for site, i in indices.items():
            replacements[("rooms", key, "sites", i, "label")] = text[label_key(key, site)]
        path = scenes / f"{key}.tscn"
        candidates[path] = scene_text(path.read_bytes().decode("utf-8"), key, text).encode("utf-8")
    candidates[manifest_path] = replace_json_strings(manifest_source, replacements).encode("utf-8")
    return publish(candidates)


def update_sites_only(keys, compiled=COMPILED, scenes=SCENES, manifest_path=OUT / "manifest.json"):
    validate_maps(keys)
    text_table = load_room_text(compiled)
    manifest = read_json(manifest_path)
    authored = {room["key"]: resolve_room_text(room, text_table) for room in rooms.all_rooms()}
    candidates = {}
    for key in keys:
        room = authored[key]
        if not isinstance(manifest.get("rooms", {}).get(key), dict):
            raise ValueError(f"Missing manifest room: {key}")
        path = scenes / f"{key}.tscn"
        source = path.read_bytes().decode("utf-8")
        if source.count('[node name="Sites"') != 1:
            raise ValueError(f"Missing or duplicate Sites container: {key}")
        prefix = source.split('[node name="Sites"', 1)[0]
        lines = ['[node name="Sites" type="Node2D" parent="."]', '']
        for site in room["sites"]:
            lines += [f'[node name="{site["id"]}" type="Marker2D" parent="Sites"]',
                      f'position = Vector2({site["point"][0]}, {site["point"][1]})',
                      f'metadata/label = {json.dumps(site["label"], ensure_ascii=False)}', '']
        candidates[path] = (prefix + "\n".join(lines)).encode("utf-8")
        manifest["rooms"][key]["sites"] = room["sites"]
    candidates[manifest_path] = json.dumps(manifest, ensure_ascii=False, indent=1).encode("utf-8")
    return publish(candidates)

# Chapter-1 sprite footprints (w, h) measured from its placement table.
CH1_FP = {
    "bed_0": (36, 64), "desk_0": (58, 26), "chair_back": (14, 10), "chair_front": (14, 10), "wardrobe": (40, 16),
    "nightstand": (18, 12), "bookcase_0": (40, 14), "bookcase_study": (40, 14), "bookcase_study_b": (40, 14),
    "coat_stand": (12, 8), "study_table": (132, 46), "sideboard": (82, 22), "range_stove": (42, 20), "worktable": (96, 30),
    "washstand": (48, 20), "side_table_plain": (24, 12), "armchair": (28, 16), "floor_lamp": (10, 8), "barrel": (18, 12),
    "crate": (22, 10), "sack": (14, 8), "plant_stand": (16, 8), "bench": (40, 10), "transmitter": None,
}


def sprites_and_footprints():
    from first_awakening_art import props as ch1_props
    from chapter2_art import props_archive, props_core, props_service

    canvases, fps = {}, dict(CH1_FP)
    ch1 = ch1_props.build()
    for mod in (props_core, props_archive, props_service):
        canvases.update(mod.build())
        fps.update(mod.FOOTPRINTS)
    return canvases, ch1, fps


def resolve(furniture, fps):
    out = []
    for f in furniture:
        f = dict(f)
        if "footprint" not in f:
            fp = fps.get(f["sprite"])
            x, y = f["position"]
            f["footprint"] = None if fp is None else [int(x - fp[0] / 2), int(y - fp[1]), int(fp[0]), int(fp[1])]
        out.append(f)
    return out


def stands(room, n=16):
    """Standing points for people: open floor cells away from walls, furniture and doorways, spread out."""
    from chapter2_art import painter

    rows = room["rows"]
    if not rows:
        return room.get("stands", [])
    blocked = set()
    for f in room["furniture"]:
        if f.get("footprint"):
            x, y, w, h = f["footprint"]
            for cy in range((y - 12) // CELL, (y + h + 12) // CELL + 1):
                for cx in range((x - 12) // CELL, (x + w + 12) // CELL + 1):
                    blocked.add((cx, cy))
    for e in room["exits"]:
        if "cells" in e:
            x0, y0, x1, y1 = e["cells"]
            for cy in range(y0 - 2, y1 + 2):
                for cx in range(x0 - 2, x1 + 2):
                    blocked.add((cx, cy))
    ok = []
    for y in range(1, len(rows) - 1):
        for x in range(1, len(rows[0]) - 1):
            if (x, y) in blocked:
                continue
            if all(rows[y + dy][x + dx] in painter.WALKABLE for dy in (-1, 0, 1) for dx in (-1, 0, 1)):
                ok.append((x, y))
    if not ok:
        return []
    cx = sum(p[0] for p in ok) / len(ok); cy = sum(p[1] for p in ok) / len(ok)
    pick = [min(ok, key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2)]
    while len(pick) < min(n, len(ok)):
        pick.append(max(ok, key=lambda p: min((p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 for q in pick)))
    return [[x * CELL + CELL // 2, y * CELL + CELL - 4] for x, y in pick]


def wall_rects(rows):
    """Solid rectangles for every non-walkable cell, merged into horizontal runs."""
    from chapter2_art import painter

    rects = []
    for y, row in enumerate(rows):
        x = 0
        while x < len(row):
            if row[x] in painter.WALKABLE:
                x += 1
                continue
            start = x
            while x < len(row) and row[x] not in painter.WALKABLE:
                x += 1
            rects.append([start * CELL, y * CELL, (x - start) * CELL, CELL])
    return rects


# ---------------------------------------------------------------- scenes ----

def tscn(room: dict, arch_path: str, sprite_paths: dict, sizes: dict) -> str:
    ext = [("Texture2D", arch_path, "arch")]
    used = sorted({f["sprite"] for f in room["furniture"]})
    for name in used:
        ext.append(("Texture2D", sprite_paths[name], "t_" + name))
    lines = [f'[gd_scene load_steps={len(ext) + 1} format=3]', '']
    lines += [f'[ext_resource type="{k}" path="{p}" id="{i}"]' for k, p, i in ext]
    lines.append('')
    shapes = []
    solids = wall_rects(room["rows"]) + [f["footprint"] for f in room["furniture"] if f.get("footprint")] + room.get("solids_px", [])
    for i, (x, y, w, h) in enumerate(solids):
        shapes.append((f"s{i}", x + w / 2, y + h / 2, w, h))
    exits = []
    for e in room["exits"]:
        if "rect_px" in e:
            x, y, w, h = e["rect_px"]
        else:
            x0, y0, x1, y1 = e["cells"]
            x, y, w, h = x0 * CELL, y0 * CELL, (x1 - x0) * CELL, (y1 - y0) * CELL
        exits.append((e, x + w / 2, y + h / 2, w, h))
    for sid, _, _, w, h in shapes:
        lines += [f'[sub_resource type="RectangleShape2D" id="{sid}"]', f'size = Vector2({w}, {h})', '']
    for i, (_, _, _, w, h) in enumerate(exits):
        lines += [f'[sub_resource type="RectangleShape2D" id="e{i}"]', f'size = Vector2({w}, {h})', '']
    W = len(room["rows"][0]) * CELL if "size_px" not in room else room["size_px"][0]
    H = len(room["rows"]) * CELL if "size_px" not in room else room["size_px"][1]
    lines += [f'[node name="{room["key"]}" type="Node2D"]', 'texture_filter = 1',
              f'metadata/title = {json.dumps(room["title"], ensure_ascii=False)}', f'metadata/map_size = Vector2({W}, {H})']
    if room["rows"]:
        lines.append(f'metadata/terrain_rows = {json.dumps(room["rows"])}')
    lines += [f'metadata/{k} = {v}' for k, v in room.get("meta", {}).items()]
    lines += ['',
              '[node name="Architecture" type="Sprite2D" parent="."]', 'z_index = -10', 'texture = ExtResource("arch")', 'centered = false', '',
              '[node name="Objects" type="Node2D" parent="."]', 'y_sort_enabled = true', '']
    for f in room["furniture"]:
        w, h = sizes[f["sprite"]]
        x, y = f["position"]
        lines += [f'[node name="{f["name"]}" type="Sprite2D" parent="Objects"]', f'position = Vector2({x}, {y})',
                  f'texture = ExtResource("t_{f["sprite"]}")', 'centered = false', f'offset = Vector2({-(w // 2)}, {-h})']
        if f.get("occluder"):
            lines.append('metadata/occluder = true')
        lines.append('')
    lines += ['[node name="Solids" type="StaticBody2D" parent="."]', 'collision_mask = 0', '']
    for sid, cx, cy, _, _ in shapes:
        lines += [f'[node name="{sid}" type="CollisionShape2D" parent="Solids"]', f'position = Vector2({cx}, {cy})', f'shape = SubResource("{sid}")', '']
    lines += ['[node name="Exits" type="Node2D" parent="."]', '']
    for i, (e, cx, cy, _, _) in enumerate(exits):
        lines += [f'[node name="{e["name"]}" type="Area2D" parent="Exits"]', f'position = Vector2({cx}, {cy})', 'collision_layer = 0',
                  'collision_mask = 2', f'metadata/target = "{e["target"]}"', f'metadata/spawn = "{e["spawn"]}"', '',
                  f'[node name="Shape" type="CollisionShape2D" parent="Exits/{e["name"]}"]', f'shape = SubResource("e{i}")', '']
    lines += ['[node name="Spawns" type="Node2D" parent="."]', '']
    for name, (x, y) in room["spawns"].items():
        lines += [f'[node name="{name}" type="Marker2D" parent="Spawns"]', f'position = Vector2({x}, {y})', '']
    lines += ['[node name="Stands" type="Node2D" parent="."]', '']
    for i, (x, y) in enumerate(stands(room)):
        lines += [f'[node name="s{i:02d}" type="Marker2D" parent="Stands"]', f'position = Vector2({x}, {y})', '']
    lines += ['[node name="Sites" type="Node2D" parent="."]', '']
    for s in room.get("sites", []):
        lines += [f'[node name="{s["id"]}" type="Marker2D" parent="Sites"]', f'position = Vector2({s["point"][0]}, {s["point"][1]})',
                  f'metadata/label = {json.dumps(s["label"], ensure_ascii=False)}', '']
    return "\n".join(lines)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--text-only", nargs="+", metavar="MAP", help="Update existing interior titles and labels without rebuilding geometry.")
    modes.add_argument("--sites-only", nargs="+", metavar="MAP", help="Regenerate marker geometry with compiled text, using existing textures.")
    args = parser.parse_args()
    if args.text_only:
        print(f"room text: {update_text_only(args.text_only)} file(s) changed")
        return
    if args.sites_only:
        print(f"generated sites: {update_sites_only(args.sites_only)} file(s) changed")
        return
    from chapter2_art import outdoor, painter

    text_table = load_room_text()
    all_rooms = [resolve_room_text(room, text_table) for room in rooms.all_rooms()]
    canvases, ch1, fps = sprites_and_footprints()
    (OUT / "rooms").mkdir(parents=True, exist_ok=True)
    (OUT / "props").mkdir(parents=True, exist_ok=True)
    SCENES.mkdir(parents=True, exist_ok=True)
    manifest = {"source": "godot_csharp/tools/build_chapter2_scenes.py", "rooms": {}, "props": {}}
    sprite_paths, sizes = {}, {}
    for name, can in canvases.items():
        path = OUT / "props" / f"{name}.png"
        can.save(path)
        sprite_paths[name] = f"res://ShareAsset/Internal/Props/Chapter2/props/{name}.png"
        sizes[name] = (can.w, can.h)
        manifest["props"][name] = {"size": [can.w, can.h], "footprint": fps.get(name), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    for name, can in ch1.items():
        if name not in sprite_paths:
            sprite_paths[name] = f"{CH1}/{name}.png"
            sizes[name] = (can.w, can.h)
    regions, spawn_region, outdoor_sprites = outdoor.build(sizes, fps)
    for name, can in outdoor_sprites.items():
        can.save(OUT / "props" / f"{name}.png")
        sprite_paths[name] = f"res://ShareAsset/Internal/Props/Chapter2/props/{name}.png"
        sizes[name] = (can.w, can.h)
    for room in all_rooms:
        for e in room["exits"]:
            if e["target"] == "campus":
                e["target"] = spawn_region[e["spawn"]]
        room["furniture"] = resolve(room["furniture"], fps)
        missing = {f["sprite"] for f in room["furniture"]} - set(sprite_paths)
        assert not missing, (room["key"], missing)
        arch, anchors = painter.paint(room)
        arch.save(OUT / "rooms" / f"{room['key']}.png")
        (SCENES / f"{room['key']}.tscn").write_text(
            tscn(room, f"res://ShareAsset/Internal/Props/Chapter2/rooms/{room['key']}.png", sprite_paths, sizes), encoding="utf-8")
        manifest["rooms"][room["key"]] = {"title": room["title"], "cells": [len(room["rows"][0]), len(room["rows"])],
                                          "exits": room["exits"], "spawns": room["spawns"], "sites": room.get("sites", [])}
        print(room["key"], arch.w, arch.h, len(room["furniture"]))
    for room in regions:
        room["architecture"].save(OUT / "rooms" / f"{room['key']}.png")
        (SCENES / f"{room['key']}.tscn").write_text(
            tscn(room, f"res://ShareAsset/Internal/Props/Chapter2/rooms/{room['key']}.png", sprite_paths, sizes), encoding="utf-8")
        manifest["rooms"][room["key"]] = {"title": room["title"], "size_px": room["size_px"], "exits": room["exits"],
                                          "spawns": room["spawns"], "sites": room["sites"]}
        print(room["key"], *room["size_px"], len(room["furniture"]), len(room["solids_px"]), "solids")
    # link check: every exit's target room and spawn exist
    spawns = {k: set(v["spawns"]) for k, v in manifest["rooms"].items()}
    bad = [(k, e["name"], e["target"], e["spawn"]) for k, v in manifest["rooms"].items() for e in v["exits"]
           if e["target"] not in spawns or e["spawn"] not in spawns[e["target"]]]
    assert not bad, bad
    (OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    print("ok", len(manifest["rooms"]), "rooms", len(canvases), "chapter-2 sprites")


if __name__ == "__main__":
    main()
