@tool
extends HBoxContainer
## 重演手稿：左页设定变量，右页逐件对照现场痕迹。完全由数据驱动，不持有宿主引用。
## 运行时：宿主调用 show_data(data) 并监听信号；编辑器里由 Editor Preview 字段拼出同样的 Dictionary 走同一渲染路径。
##
## show_data({
##   title:String, hint:String,
##   questions:[{question:String, options:[String], mark:String, fresh:bool}],
##   vars:[int]  (每题当前所选选项序号，-1 为未设),
##   last_run_vars:[int]  (上一次重演时的设定),
##   result:{full_match:bool, findings:[{title, status:"match"|"conflict"|"unvisited", text, card_id}]}
## })
const Paper := preload("res://scenes/UI/Components/Paper.gd")

signal vars_changed(vars: Array)
signal run_requested(vars: Array, skip: bool)
signal open_card(card_id: String)
signal close_requested

@export var unset_hint: String = "还有变量没有设定。"
@export var stale_hint: String = "变量已改动：下面是上一次重演的结果，已过期。"
@export var status_labels: Dictionary = {"match": "[color=match]吻合[/color]", "conflict": "[color=seal]冲突[/color]", "unvisited": "[color=muted]未查[/color]"}

@export_group("Editor Preview")
@export var default_title: String = "重演推演":
	set(value):
		default_title = value
		_update_preview()
@export var default_hint: String = "设定变量后，可与现场留下的痕迹对照。":
	set(value):
		default_hint = value
		_update_preview()
@export var preview_questions: Array[Dictionary] = [{"question": "示例变量设定", "options": ["选项 A", "选项 B"], "mark": "", "fresh": false}]:
	set(value):
		preview_questions = value
		_update_preview()
@export var preview_vars: Array[int] = []:
	set(value):
		preview_vars = value
		_update_preview()
@export var preview_last_run_vars: Array[int] = []:
	set(value):
		preview_last_run_vars = value
		_update_preview()
@export var preview_full_match := false:
	set(value):
		preview_full_match = value
		_update_preview()
## 每项：{title, status: match|conflict|unvisited, text, card_id}
@export var preview_findings: Array[Dictionary] = []:
	set(value):
		preview_findings = value
		_update_preview()

var selection: Array = []
var last_run_vars: Array = []
var option_buttons: Array = []
var run_buttons: Array = []
var _data: Dictionary = {}
const NUMERALS := ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十"]
## 对照状态到印戳墨色：冲突用印红，相容用相容色，未查用淡墨。
const STAMP_TONES := {"match": "match", "conflict": "seal", "unvisited": "muted"}
@onready var results_box: VBoxContainer = $RightPage/Scroll/Column/Results
@onready var ledger: Control = $RightPage/Scroll/Column/Ledger
@onready var tally: Control = $LeftPage/Scroll/Column/Tally
@onready var stale_label: RichTextLabel = $RightPage/Scroll/Column/Stale

func _ready() -> void:
	var actions := $LeftPage/Scroll/Column/Actions
	run_buttons = [actions.get_node("RunPlayback"), actions.get_node("RunSkip")]
	_connect_button(run_buttons[0], func(): _run(false))
	_connect_button(run_buttons[1], func(): _run(true))
	_connect_button(actions.get_node("Close"), func(): close_requested.emit())
	if Engine.is_editor_hint():
		_update_preview()
	else:
		_render()

func show_data(data: Dictionary) -> void:
	_data = data
	if is_node_ready():
		_render()

func vars() -> Array:
	return selection.duplicate()

func _connect_button(button: Button, action: Callable) -> void:
	if Engine.is_editor_hint():
		return
	button.pressed.connect(func(): Paper.Sound.sfx("ui_click", -4.0))
	button.pressed.connect(action)

func _update_preview() -> void:
	if not is_node_ready() or not Engine.is_editor_hint():
		return
	var result := {}
	if not preview_findings.is_empty():
		result = {"full_match": preview_full_match, "findings": preview_findings}
	_data = {
		"title": default_title, "hint": default_hint,
		"questions": preview_questions,
		"vars": preview_vars, "last_run_vars": preview_last_run_vars,
		"result": result,
	}
	_render()

func _render() -> void:
	var questions: Array = _data.get("questions", [])
	selection = (_data.get("vars", []) as Array).duplicate()
	selection.resize(questions.size())
	for index in questions.size():
		var options: Array = questions[index].get("options", [])
		if selection[index] == null or int(selection[index]) < 0 or int(selection[index]) >= options.size():
			selection[index] = -1
	last_run_vars = (_data.get("last_run_vars", []) as Array).duplicate()
	last_run_vars.resize(questions.size())
	for index in questions.size():
		if last_run_vars[index] == null:
			last_run_vars[index] = -1
	$LeftPage/Scroll/Column/Title.text = str(_data.get("title", default_title))
	$LeftPage/Scroll/Column/Hint.text = str(_data.get("hint", default_hint))
	_build_questions(questions)
	_refresh()

func _build_questions(questions: Array) -> void:
	var column := $LeftPage/Scroll/Column/Questions
	for child in column.get_children():
		column.remove_child(child)
		child.queue_free()
	option_buttons.clear()
	for index in questions.size():
		var variable: Dictionary = questions[index]
		var question: HBoxContainer = $Templates/Question.duplicate()
		question.visible = true
		column.add_child(question)
		var mark := str(variable.get("mark", ""))
		var fresh := "　[color=muted]（新）[/color]" if bool(variable.get("fresh", false)) else ""
		question.get_node("Numeral").text = NUMERALS[index] if index < NUMERALS.size() else str(index + 1)
		question.get_node("Body/Prompt").text = Paper.story_text("%s%s%s" % [variable.get("question", ""), mark, fresh])
		var row: VBoxContainer = question.get_node("Body/Options")
		var template: Button = row.get_node("Option")
		var buttons := []
		var options: Array = variable.get("options", [])
		for option in options.size():
			var button: Button = template.duplicate()
			button.visible = true
			button.text = str(options[option])
			button.serial = Paper.roman(option + 1)
			row.add_child(button)
			_connect_button(button, _choose.bind(index, option))
			buttons.append(button)
		option_buttons.append(buttons)

func _choose(index: int, option: int) -> void:
	selection[index] = option
	vars_changed.emit(selection.duplicate())
	_refresh()

func _refresh() -> void:
	var answered := 0
	for index in option_buttons.size():
		if selection[index] != -1: answered += 1
		for option in option_buttons[index].size():
			option_buttons[index][option].set_pressed_no_signal(selection[index] == option)
			option_buttons[index][option].queue_redraw()
	tally.total = option_buttons.size()
	tally.filled = answered
	tally.visible = option_buttons.size() > 0
	var ready := not selection.is_empty() and not selection.has(-1)
	for b in run_buttons:
		b.disabled = not ready
	for child in results_box.get_children():
		results_box.remove_child(child)
		child.queue_free()
	var result: Dictionary = _data.get("result", {})
	ledger.visible = result.is_empty()
	if result.is_empty():
		var empty: RichTextLabel = $Templates/EmptyResult.duplicate()
		empty.visible = true
		results_box.add_child(empty)
		stale_label.text = "" if ready else unset_hint
		return
	var stale: bool = last_run_vars != selection
	stale_label.text = stale_hint if stale else ""
	if bool(result.get("full_match", false)) and not stale:
		var match_label: RichTextLabel = $Templates/FullMatch.duplicate()
		match_label.visible = true
		results_box.add_child(match_label)
	for finding in result.get("findings", []):
		var status := str(finding.get("status", "unvisited"))
		var chip := RegEx.create_from_string("\\[/?[a-z_]+(=[^\\]]*)?\\]").sub(str(status_labels.get(status, status)), "", true)
		var title := str(finding.get("title", finding.get("name", "")))
		var row: VBoxContainer = $Templates/Finding.duplicate()
		row.visible = true
		results_box.add_child(row)
		var stamp := Paper.stamp(chip, STAMP_TONES.get(status, "muted"))
		row.get_node("Head").add_child(stamp)
		row.get_node("Head").move_child(stamp, 0)
		stamp.modulate.a = 0.55 if stale else 1.0
		var head: RichTextLabel = row.get_node("Head/Heading")
		head.text = Paper.story_text(title)
		head.self_modulate.a = 0.55 if stale else 1.0
		var detail: RichTextLabel = row.get_node("Detail")
		detail.visible = status != "match"
		detail.text = Paper.story_text(str(finding.get("text", "")))
		detail.self_modulate.a = 0.5 if stale else 1.0
		var card_id := str(finding.get("card_id", ""))
		var open: Button = row.get_node("Head/OpenCard")
		open.visible = status != "unvisited" and card_id != ""
		_connect_button(open, func(): open_card.emit(card_id))

func _run(skip: bool) -> void:
	if selection.is_empty() or selection.has(-1):
		return
	run_requested.emit(selection.duplicate(), skip)
